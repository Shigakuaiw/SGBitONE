# Bit Browser Tab Fix

- Fixed tab close interaction: drag-and-drop attaches only to the tab selection/title area, not to the entire tab including the close button.
- Increased the close button hit target to 44×44 points.
- Existing tab switching, drag reordering, model close and new-tab fallback preserved.
- Based on BitBrowser-LiquidKeyboard.
- Source patch and ZIP structure checked, but iPad/macOS Swift Playgrounds compilation and actual input behavior have not been tested.
