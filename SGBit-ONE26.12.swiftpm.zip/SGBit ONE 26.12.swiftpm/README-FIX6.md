# Bit Browser Fix 6
- iPad navigation: manually controlled sidebar toggle; tapping it no longer changes the active feature.
- File manager: navigate folders including Documents/Downloads, import, preview via QuickLook, share/export, rename, delete, create folders.
- Password vault and networking implementations are unchanged.
- ShazamKit error 202 is not addressed in this patch.
- Not verified by compiling in Apple Swift Playgrounds/Xcode.
