# SGBit ONE 26.9.2 — PasswordVaultビルド修正

## 修正
- `PasswordVault.swift` の `ForEach` を明示的な `[ONELogin]` の値ベースの列挙に変更。
- ログイン行のUIを `ONEPasswordListRow` に分離し、SwiftUIが`Binding`用のオーバーロードを誤って推論しにくい構造に変更。
- 以前の保管庫、壁紙、PIN設定、ブラウザ等の保存形式は変更なし。

## 検証
- Swiftのパーサーによる構文チェック・ZIP整合性チェックは可能。
- AppleのSwiftUI SDKを使ったiPadOSビルド・実機確認はこの環境では未実施。
