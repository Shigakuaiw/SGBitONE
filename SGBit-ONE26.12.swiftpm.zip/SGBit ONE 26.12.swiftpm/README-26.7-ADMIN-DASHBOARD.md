# SGBit ONE 26.7 — Web管理者ダッシュボード

## 設置
1. Cloudflare Workers に `AdminUpdateServer/worker.js` をデプロイ。
2. KV namespace を作り `UPDATES_KV` という名前でバインド。
3. Worker Secret `ADMIN_TOKEN` に16文字以上の推測困難なランダム文字列を登録（端末アプリへ埋め込まない）。
4. PCのブラウザで `https://YOUR-WORKER.workers.dev/admin` を開く。
5. トークンを入力し、タイトル/バージョン/更新内容/任意の設定パッチを指定。「配信する」で公開。
6. SGBit ONEのアップデート画面に `https://YOUR-WORKER.workers.dev/updates` を指定し確認。

## セキュリティ
- 管理画面を開くこと自体は認証不要（フォームの表示だけ）。更新の閲覧（管理者用）と配信にはBearerトークンが必須。
- トークンはブラウザのメモリ内だけで保持し、cookie/localStorage/sessionStorageには保存しない。管理画面を閉じれば消える。
- HTTPS、Worker Secret、KV bindingが必要。共有端末での操作に注意。
- `/updates`は公開エンドポイント。KVの更新は短時間の伝播遅延があり得る。
- サーバー経由でSwift等の実行コードは送らない。許可したテーマ関連の設定値だけを配信し、利用者が確認して適用。
- アプリ本体の更新は従来通りの配布・インストールが必要。リモートでアプリ自体を上書きする機能ではありません。
- `dashboard.html` はUI参照用。実際のWorkerにはHTMLが `worker.js` に内包されているため、`worker.js` だけのデプロイで動作します。

## URL
- `GET /admin`: 管理ダッシュボード
- `GET /admin/current`: Bearer認証付き現在の配信JSON
- `POST /admin/publish`: Bearer認証付きマニフェスト配信
- `GET /updates`: アプリが読み取る公開配信情報

## ビルド
Swift構文の完全なiPad実機ビルドはこの環境では未検証です。26.6の既存機能を維持し、アプリ側のバージョン表示を26.7に変更しています。
