# Chappy AI sidebar integration
- Adds AI（チャッピー） directly above ブラウザ on iPad sidebar.
- ChatGPT website is opened in an isolated SwiftUI section using WKWebView.
- Same session object is kept in ContentView StateObject during section changes.
- iPhone tab added as チャッピー.
- Back, reload and Safari fallback controls.
- Does NOT require any OpenAI API key. Authentication and availability inside WKWebView depend on ChatGPT's website.
- No custom AI backend or password interception.
- Bundle identifier unchanged. No iPad Swift Playgrounds build test was possible in this environment.
