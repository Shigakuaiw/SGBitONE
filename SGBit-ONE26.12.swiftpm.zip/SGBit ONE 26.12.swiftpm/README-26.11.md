# SGBit ONE 26.11 — SGBit Music

- 音楽機能の表示名を「SGBit Music」に変更
- プレイリスト作成・名前変更・削除
- 曲の追加・プレイリストからの削除
- プレイリスト単位の連続再生と前後スキップ
- 保存先: アプリのDocuments/sgbit-music-playlists.json
- 曲自体は複製せず、Documentsからの相対パスを保存。

注意: ファイル名変更や移動をするとプレイリストの参照が外れることがあります。
Swift Playgrounds実機ビルドは未検証です。
