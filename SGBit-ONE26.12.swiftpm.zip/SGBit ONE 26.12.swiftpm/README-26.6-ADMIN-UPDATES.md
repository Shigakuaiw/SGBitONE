# SGBit ONE 26.6 — 管理者アップデート配信

## 対応範囲
- サイドバー・ホーム・タブの「アップデート」で、管理者サーバーのHTTPS URLを登録
- 公開された更新マニフェスト(JSON)の取得・内容表示
- 利用者の確認後、テーマ等の設定パッチを適用（本体コードの遠隔実行は不可）
- 新版アプリのHTTPS配布リンクを表示（自動インストールではありません）

## Cloudflare Workers 管理者側の準備
1. Cloudflare Workersに `AdminUpdateServer/worker.js` をデプロイする。
2. KV namespaceを作成して、Workerに `UPDATES_KV` というbindingで割り当てる。
3. Worker Secret `ADMIN_TOKEN` に長くランダムな秘密の文字列を登録。**iPad側には絶対に配布しない。**
4. PCなど管理者環境から次のようにPOSTして配信（`sample-manifest.json` は例）。

```bash
curl -X POST 'https://YOUR-WORKER.workers.dev/admin/publish' \
  -H 'Authorization: Bearer YOUR_ADMIN_TOKEN' \
  -H 'Content-Type: application/json' \
  --data-binary @AdminUpdateServer/sample-manifest.json
```

5. iPad側「アップデート」に `https://YOUR-WORKER.workers.dev/updates` を登録し「アップデートを確認」。

## 安全性と制約
- 更新を許可する範囲はテーマの `darkTheme`, `accent`, `panelOpacity`, `cornerRadius` のみ。
- 送られたSwiftや任意スクリプトは実行しません。
- 管理者認証はWorker上で行い、クライアント側には秘密を埋め込みません。
- URLのHTTPS接続だけでは管理者の真正性を保証しません。信頼できるURLだけ登録してください。
- 本体更新はAppleに認められた通常の配布手段で新バージョンを導入してください。
- **Swift Playgrounds/iPad実機でのビルド検証は未実施。**
