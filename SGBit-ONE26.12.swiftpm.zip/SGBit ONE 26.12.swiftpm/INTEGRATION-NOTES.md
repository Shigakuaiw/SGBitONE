# Gaku Hub 統合版

元の RelayBrowser のソースコードと機能を保持し、ブラウザ、ファイル、音楽、Shazam認識の4タブを追加しています。

- `Sources/ContentView.swift` の元のブラウザ画面は `RelayBrowserHome` に名前変更。
- `Sources/HubContentView.swift` が新しいタブ画面。
- `Sources/GakuHubFeatures.swift` にファイル取り込み、ローカル音楽再生、ShazamKit認識を追加。
- ファイルタブで取り込んだ音声が音楽タブに表示されます。ブラウザのダウンロードはDocuments/Downloadsに保存されるため、ファイルタブの最上位にDownloadsフォルダとして表示されます。現段階ではサブフォルダ内の閲覧は未実装です。

## 注意
iPadのSwift Playgrounds上でビルド・実行は未検証です。ShazamKitの利用には対応する署名・権限・インターネット接続が必要で、Swift Playgroundsの機能制限により実行できない場合があります。元のブラウザの特殊なネットワーク機能も実機検証が必要です。
