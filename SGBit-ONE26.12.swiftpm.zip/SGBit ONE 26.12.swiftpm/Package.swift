// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "SGBitONEProject",
    defaultLocalization: "ja",
    platforms: [.iOS("17.0")],
    products: [
        .iOSApplication(
            name: "SGBit ONE 26.12.0",
            targets: ["AppModule"],
            bundleIdentifier: "net.ogatomo.RelayBrowser",
            displayVersion: "26.12.0",
            bundleVersion: "26120000",
            supportedDeviceFamilies: [.pad, .phone],
            supportedInterfaceOrientations: [.portrait, .landscapeLeft, .landscapeRight],
            capabilities: [.incomingNetworkConnections(), .outgoingNetworkConnections()],
            additionalInfoPlistContentFilePath: "Config/HostInfo.plist"
        )
    ],
    targets: [.executableTarget(name: "AppModule", path: "Sources", resources: [.process("Resources")])]
)
