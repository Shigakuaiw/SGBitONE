# RelayBrowser 2026-10-20 r6

ZIPを展開してRelayBrowser.swiftpmをSwift Playgroundsで開き、再生します。新規プロジェクトはSources/App.swiftの1本だけに全17実装と@mainを収録しています。「…」末尾の設定で2026-10-20 r6、Appバージョン0.3.0(6)を確認します。URL横のキーアイコンからアプリ内キーボードを開けます。漢字はかな→変換→候補で単語ごとに確定します。

既存Appを維持して更新する場合は、別配布のRelayBrowser-one-file-20261020-r6.zipを使い、元の@mainを残してまとめ版ContentView.swiftへ置換します。新規用App.swift・既存のApp入口・旧分割ソースを一緒に追加しないでください。

新規App識別子はnet.ogatomo.RelayBrowser。既存Appと異なる場合、以前のCookie/localStorage等は引き継ぎません。HTTP/標準編集メニュー言語/LANアクセスの用途説明はPackage.swiftから生成設定へ接続済みです。元々あるInfo.plistの編集は不要です。

最低iOS17。必要定義の収録、結合一致、入口数、ターゲットと設定の接続をWindowsで検査しています。Apple SDKの型チェック・Playgroundsビルド・キーボード改善の実機確認は未実施です。

ホームはhttps://google.com。EnterでURL/検索、歯車で設定、…で各ツール。PINは初期値OFFですが、有効時は連続10回誤るとサイトデータ・履歴・復元情報・ダウンロード元URLを自動削除します。ブックマークと保存ファイルは残り、削除後も正しいPINが必要です。

入力の修正・比較手順はルートのdocs/KEYBOARD.mdを参照。設定から「入力の診断」を開けます。既存の分割版には3本だけのキーボード修正ZIPを使い、全体の構成を変える必要はありません。
