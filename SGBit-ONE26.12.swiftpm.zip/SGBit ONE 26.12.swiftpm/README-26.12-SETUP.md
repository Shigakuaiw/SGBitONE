# SGBit ONE 26.12.0 — Setup redesign

- Welcome with 8 rotating languages, upward swipe to begin.
- Language, region, network, appearance/accent/background, account, backup, terms, ready.
- White setup UI with blue capsule Next button and standard SwiftUI green toggles.
- Network AdGuard switch binds to active BrowserPreferences. Tracking-protection toggle saves a preference only (not an active filtering engine).
- Theme previews include animated automatic preview; selected theme applied to home. System automatic mode is connected to preferredColorScheme and updates the saved custom-theme flag when system appearance changes.
- Terms top-left Decline returns Welcome, top-right Agree advances to final swipe.
- Language selection is persisted; the greeting carousel has 8 languages, but full app-wide translations are not yet included.
- Wallpaper preset is wired to the home fallback background when no custom image is selected; existing image wallpapers take priority.
- R2 end-to-end encrypted backups and live Worker APIs require Apple-device testing.
- Linux cannot build an AppleProductTypes/iOS SwiftUI app.
