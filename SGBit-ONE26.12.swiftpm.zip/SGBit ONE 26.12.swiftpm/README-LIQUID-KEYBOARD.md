# Bit Browser – Liquid Keyboard

Swift Playgrounds 内で使える独自 JIS キーボード (`BrowserKeyboardPanel`) の外観を、暗色半透明の Liquid Glass 風に更新しました。iPadOS 26 以降は `glassEffect` を使用し、それ以前の iPadOS 17–25 では半透明の代替デザインを使用します。

- **従来の文字入力処理、日本語変換、キー配列、URL欄・ページ内入力の連携は維持**しています。
- ブラウザのキーボードボタンから表示する「アプリ内キーボード」が変更対象です。iPadOS純正キーボードやWebサイトが呼び出すシステムキーボードの外観は変更できません。
- 既存のWebKitやKeychainの処理は変更していません。
- 未ビルド・実機未検証です。
