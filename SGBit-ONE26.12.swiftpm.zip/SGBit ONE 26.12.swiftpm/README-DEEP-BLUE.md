# Deep Blue sidebar theme
- Mac App Storeのサイドバーを参考にした濃いブルーのアクセント
- 選択中のサイドバー項目を深いネイビーブルーでハイライト
- 非選択アイコンに落ち着いたApple風ブルーを使用
- 左サイドバー背景をダークネイビーに統一
- 「設定」ボタンは従来どおり最下部に固定
- 設定画面のボタンやアクセントもブルーに統一
- Keychainの保存方式・既存データ・Bundle IDは変更なし
- Swift Playgrounds/macOS/iPadOSでのビルドとUIテストは未実施
