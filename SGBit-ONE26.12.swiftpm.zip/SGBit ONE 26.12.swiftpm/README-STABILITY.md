# Bit Browser — Settings / Touch Stability

- Settings grouped into General / Home / Appearance / Keyboard / Security / Site Data / Advanced with icon labels.
- Larger 44pt navigation targets in browser chrome; tap-target overlaps reduced.
- Removed extra simultaneous tap recognizer from URL field so it can take focus normally.
- Preserved tab, download, vault and settings data/storage model.

Note: Swift Playgrounds build and runtime need verification on the user's iPad/Mac.
