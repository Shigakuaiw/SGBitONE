# 同梱データ

r10はGoogle MozcのOSS単語辞書の抽出データをResources/mozc-dictionary.jsonへ同梱します。Mozc変換エンジン、AzooKey、外部Swift Packageは含みません。出典/ハッシュはMozc-Dictionary-source.json、著作権/ライセンス全文はMozc-Dictionary.txtです。Resourcesにも同じ告知を入れ、設定から閲覧できます。IPAdic/沖縄辞書の告知も維持しています。
