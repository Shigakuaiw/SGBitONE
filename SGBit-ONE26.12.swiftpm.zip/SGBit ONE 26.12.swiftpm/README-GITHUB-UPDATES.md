# SGBit ONE 26.11.1119.000

GitHub Releases update checking via public GitHub API.
Repository: https://github.com/Shigakuaiw/SGBitONE
Checks latest published stable release, displays release notes, and opens .swiftpm.zip asset URL for download. No GitHub token is stored.
App installation remains manual through Swift Playgrounds. Existing Cloudflare data-only patches are retained.
