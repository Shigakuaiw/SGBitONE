# SGBit ONE 26.11.1119.003 — Browser UI update

- Firefox-inspired desktop tab strip and address field (including private-tab purple accent).
- Adaptive compact two-row bottom toolbar for view widths below 600 points.
- Tab overview with normal/private filtering, close/new/select and best-effort WebKit preview snapshots.
- Simple DevTools: expression evaluation (Console) and HTML source (Elements); not full Network inspector.
- Browser's custom keyboard is opt-in in Settings, disabled by default.
- Enables WKWebView inspection with Safari developer tools on supported OS versions.

Not implemented in this build: independently managed multiwindow browser sessions, full Network inspector, tab drag between windows. Existing app screens (including lock screen) intentionally preserved.

Swift syntax parse checked on Linux, but actual iPadOS Swift Playgrounds build/runtime not verified.
