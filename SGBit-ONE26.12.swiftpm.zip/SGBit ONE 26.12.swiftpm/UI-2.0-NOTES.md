# Bit Browser 2.0 — UI refresh

- iPhone compact: 3 main tabs (Browser, Music, More). More contains Files, Shazam, Password Vault.
- iPad regular width: collapsible sidebar with five destinations.
- Sidebar uses native system material; existing browser toolbar/tab creation logic is untouched.
- No changes to Keychain identifiers, bundle ID, network relay, music engine, or ShazamKit logic.
- This is a navigation redesign, not a full Liquid Glass implementation. Native iOS 26 glass effects can be added once deployment and toolchain compatibility are checked.
- Not compiled or tested on a device. Test in Swift Playgrounds, especially iPad split view and password vault access.
