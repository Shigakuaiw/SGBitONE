import SwiftUI
import Foundation
import UniformTypeIdentifiers

// Streaming ZIP (stored entries). Avoids loading large audio files into RAM.
// Archive is NOT encrypted; the password vault file inside remains encrypted.
private enum ONEZipError: LocalizedError {
    case tooLarge, path, noSpace
    var errorDescription: String? {
        switch self {
        case .tooLarge: return "バックアップできるファイル数の上限を超えました。"
        case .path: return "バックアップできないファイルがありました。"
        case .noSpace: return "端末の空き容量が不足しています。"
        }
    }
}

private struct ONEZipEntry {
    let url: URL
    let path: String
    let size: UInt64
    let crc: UInt32
    let offset: UInt64
}

private enum ONEZipWriter {
    private static func le16(_ n: UInt16) -> Data { var v = n.littleEndian; return withUnsafeBytes(of: &v) { Data($0) } }
    private static func le32(_ n: UInt32) -> Data { var v = n.littleEndian; return withUnsafeBytes(of: &v) { Data($0) } }
    private static func le64(_ n: UInt64) -> Data { var v = n.littleEndian; return withUnsafeBytes(of: &v) { Data($0) } }
    private static func write(_ handle: FileHandle, _ data: Data) throws { try handle.write(contentsOf: data) }
    private static func crc32(_ url: URL) throws -> UInt32 {
        let h = try FileHandle(forReadingFrom: url)
        defer { try? h.close() }
        var crc: UInt32 = 0xFFFF_FFFF
        while true {
            guard let bytes = try h.read(upToCount: 65536), !bytes.isEmpty else { break }
            for byte in bytes {
                crc ^= UInt32(byte)
                for _ in 0..<8 { crc = (crc >> 1) ^ ((crc & 1) != 0 ? 0xEDB8_8320 : 0) }
            }
        }
        return crc ^ 0xFFFF_FFFF
    }
    static func create(files: [(URL, String)], destination: URL) throws {
        let fm = FileManager.default
        let total = files.reduce(Int64(0)) { result, pair in
            let size = ((try? fm.attributesOfItem(atPath: pair.0.path)[.size]) as? NSNumber)?.int64Value ?? 0
            return result + size
        }
        let available = (try? destination.deletingLastPathComponent().resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]))?.volumeAvailableCapacityForImportantUsage ?? Int64.max
        if total + 10_000_000 > available { throw ONEZipError.noSpace }
        if files.count > 60000 { throw ONEZipError.tooLarge }
        fm.createFile(atPath: destination.path, contents: nil)
        let out = try FileHandle(forWritingTo: destination)
        defer { try? out.close() }
        var entries: [ONEZipEntry] = []
        var offset: UInt64 = 0
        do {
            for (file, path) in files {
                let bytes = Data(path.utf8)
                if bytes.count > Int(UInt16.max) { throw ONEZipError.path }
                let length = ((try fm.attributesOfItem(atPath: file.path)[.size]) as? NSNumber)?.uint64Value ?? 0
                let crc = try crc32(file)
                let localExtra = le16(0x0001) + le16(16) + le64(length) + le64(length)
                let local = le32(0x04034b50) + le16(45) + le16(0x0800) + le16(0) + le16(0) + le16(0) + le32(crc) + le32(UInt32.max) + le32(UInt32.max) + le16(UInt16(bytes.count)) + le16(UInt16(localExtra.count))
                try write(out, local); try write(out, bytes); try write(out, localExtra)
                let input = try FileHandle(forReadingFrom: file)
                defer { try? input.close() }
                while true {
                    guard let chunk = try input.read(upToCount: 65536), !chunk.isEmpty else { break }
                    try write(out, chunk)
                }
                entries.append(ONEZipEntry(url: file, path: path, size: length, crc: crc, offset: offset))
                offset += UInt64(local.count + bytes.count + localExtra.count) + length
            }
            let directoryStart = offset
            for entry in entries {
                let bytes = Data(entry.path.utf8)
                let centralExtra = le16(0x0001) + le16(24) + le64(entry.size) + le64(entry.size) + le64(entry.offset)
                let central = le32(0x02014b50) + le16(45) + le16(45) + le16(0x0800) + le16(0) + le16(0) + le16(0) + le32(entry.crc) + le32(UInt32.max) + le32(UInt32.max) + le16(UInt16(bytes.count)) + le16(UInt16(centralExtra.count)) + le16(0) + le16(0) + le16(0) + le32(0) + le32(UInt32.max)
                try write(out, central); try write(out, bytes); try write(out, centralExtra)
                offset += UInt64(central.count + bytes.count + centralExtra.count)
            }
            let zip64Start = offset
            let zip64End = le32(0x06064b50) + le64(44) + le16(45) + le16(45) + le32(0) + le32(0) + le64(UInt64(entries.count)) + le64(UInt64(entries.count)) + le64(offset-directoryStart) + le64(directoryStart)
            try write(out, zip64End)
            let locator = le32(0x07064b50) + le32(0) + le64(zip64Start) + le32(1)
            try write(out, locator)
            let end = le32(0x06054b50) + le16(0) + le16(0) + le16(UInt16(entries.count)) + le16(UInt16(entries.count)) + le32(UInt32.max) + le32(UInt32.max) + le16(0)
            try write(out, end)
        } catch {
            try? fm.removeItem(at: destination)
            throw error
        }
    }
}

@MainActor
final class ONEBackupManager: ObservableObject {
    @Published var generating = false
    @Published var output: URL?
    @Published var status = ""
    static let shared = ONEBackupManager()
    private init() {}

    func export() {
        guard !generating else { return }
        generating = true
        status = "バックアップを作成しています…"
        output = nil
        Task {
            do {
                let fm = FileManager.default
                let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
                let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
                let temp = fm.temporaryDirectory
                let destination = temp.appendingPathComponent("SGBitONE-FullBackup-\(Int(Date().timeIntervalSince1970)).zip")
                var inputs: [(URL, String)] = []
                for (root, prefix) in [(docs, "Documents"), (support, "ApplicationSupport")] {
                    if let iterator = fm.enumerator(at: root, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles]) {
                        for case let url as URL in iterator {
                            guard (try? url.resourceValues(forKeys: [.isRegularFileKey]))?.isRegularFile == true else { continue }
                            let path = url.path.replacingOccurrences(of: root.path + "/", with: "")
                            // ZIP entry names must be relative and normalized.
                            if path.contains("..") || path.hasPrefix("/") { continue }
                            inputs.append((url, prefix + "/" + path))
                        }
                    }
                }
                // Only app preferences, not system defaults or authorization credentials.
                let defaults = UserDefaults.standard.dictionaryRepresentation().filter { entry in
                    (entry.key.hasPrefix("bb.") || entry.key.hasPrefix("sgbit.")) &&
                    !entry.key.contains("Verifier") && !entry.key.contains("token")
                }
                let compatible = defaults.filter { PropertyListSerialization.propertyList($0.value, isValidFor: .xml) }
                let plist = try PropertyListSerialization.data(fromPropertyList: compatible, format: .xml, options: 0)
                let prefsFile = temp.appendingPathComponent("SGBitONE-Preferences-\(UUID().uuidString).plist")
                try plist.write(to: prefsFile, options: .atomic)
                inputs.append((prefsFile, "Preferences.plist"))
                // File IO is heavy; perform it off the main actor.
                try await Task.detached(priority: .userInitiated) {
                    try ONEZipWriter.create(files: inputs, destination: destination)
                }.value
                try? fm.removeItem(at: prefsFile)
                output = destination
                status = "ZIPができました。「ファイルに保存」を押してください。"
            } catch {
                status = "バックアップ失敗：\(error.localizedDescription)"
            }
            generating = false
        }
    }
}

private struct ONEBackupExporter: UIViewControllerRepresentable {
    let file: URL
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        UIDocumentPickerViewController(forExporting: [file], asCopy: true)
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
}

@available(iOS 17.0, *)
struct ONEBackupView: View {
    @StateObject private var backupManager = ONEBackupManager.shared
    @AppStorage("sgbit.backup.enabled") private var enabled = false
    @AppStorage("sgbit.backup.frequency") private var frequency = "manual"
    @State private var exporting = false
    var body: some View {
        Form {
            Section("完全バックアップ") {
                Toggle("バックアップを有効にする", isOn: $enabled)
                Picker("バックアップ頻度（希望）", selection: $frequency) {
                    Text("手動").tag("manual"); Text("毎日").tag("daily"); Text("毎週").tag("weekly")
                }
                Button("バックアップZIPを作成") { backupManager.export() }
                    .disabled(backupManager.generating)
                if backupManager.generating { ProgressView("処理中") }
                Text(backupManager.status).font(.footnote)
                if backupManager.output != nil {
                    Button("ファイルに保存") { exporting = true }.buttonStyle(.borderedProminent)
                }
            }
            Section("含まれるデータ") {
                Text("音楽、プレイリスト、ダウンロード、ブックマーク、履歴、壁紙、パスワード保管庫（暗号化ファイル）、アプリの設定など。")
                Text("ZIP自体は暗号化されません。第三者へ共有しないでください。iOSのキーチェーン、WebKitのCookie、ログインセッションは含まれません。大容量のファイルはZIP64形式で保存します。")
                    .font(.footnote).foregroundStyle(.secondary)
                Text("この版はZIPの書き出しに対応。ZIPからの自動復元と定期バックアップは未実装です。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .navigationTitle("バックアップ")
        .sheet(isPresented: $exporting) {
            if let output = backupManager.output { ONEBackupExporter(file: output) }
        }
        .onChange(of: enabled) { _, value in Task { await ONEAccount.shared.updateBackup(enabled: value, frequency: frequency) } }
        .onChange(of: frequency) { _, value in Task { await ONEAccount.shared.updateBackup(enabled: enabled, frequency: value) } }
    }
}
