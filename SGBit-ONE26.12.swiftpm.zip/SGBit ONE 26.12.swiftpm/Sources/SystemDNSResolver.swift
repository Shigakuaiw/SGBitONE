import Foundation
#if canImport(Darwin)
import Darwin

enum BrowserSystemDNSFailure: Error { case lookup(Int32), noAddresses }

struct SystemDNSResolver: BrowserHostResolver {
    func resolve(_ host: String) async throws -> [String] {
        try Task.checkCancellation()
        let result: [String] = try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .utility).async {
                do { continuation.resume(returning: try Self.lookup(host)) }
                catch { continuation.resume(throwing: error) }
            }
        }
        try Task.checkCancellation()
        return result
    }

    static func lookup(_ host: String) throws -> [String] {
        var hints = addrinfo()
        hints.ai_family = AF_UNSPEC
        hints.ai_socktype = SOCK_STREAM
        hints.ai_flags = AI_ADDRCONFIG
        var result: UnsafeMutablePointer<addrinfo>?
        let code = getaddrinfo(host, nil, &hints, &result)
        guard code == 0 else { throw BrowserSystemDNSFailure.lookup(code) }
        defer { if let result { freeaddrinfo(result) } }
        var addresses: [String] = []
        var node = result
        while let current = node, addresses.count < 16 {
            defer { node = current.pointee.ai_next }
            guard current.pointee.ai_family == AF_INET || current.pointee.ai_family == AF_INET6 else { continue }
            var name = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            let capacity = socklen_t(name.count)
            guard getnameinfo(current.pointee.ai_addr, current.pointee.ai_addrlen,
                              &name, capacity, nil, 0, NI_NUMERICHOST) == 0 else { continue }
            let address = String(cString: name)
            if !addresses.contains(address) { addresses.append(address) }
        }
        guard !addresses.isEmpty else { throw BrowserSystemDNSFailure.noAddresses }
        return addresses
    }
}
#endif
