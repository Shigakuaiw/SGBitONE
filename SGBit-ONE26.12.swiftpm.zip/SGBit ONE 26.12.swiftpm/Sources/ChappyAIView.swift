import SwiftUI
import WebKit

// ChatGPT is OpenAI's service. This is only a browser view,
// not a custom AI engine or an OpenAI API client.
@MainActor
final class ChappyWebSession: NSObject, ObservableObject, WKNavigationDelegate {
    static let chatURL = URL(string: "https://chatgpt.com/")!
    let webView: WKWebView

    @Published private(set) var loading = false
    @Published private(set) var canGoBack = false
    @Published private(set) var errorMessage: String?

    private var didLoad = false

    override init() {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        self.webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
    }

    func openIfNeeded() {
        guard !didLoad else { return }
        didLoad = true
        webView.load(URLRequest(url: Self.chatURL))
    }

    func reload() {
        errorMessage = nil
        if webView.url == nil {
            webView.load(URLRequest(url: Self.chatURL))
        } else {
            webView.reload()
        }
    }

    func back() {
        if webView.canGoBack { webView.goBack() }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        loading = true
        errorMessage = nil
        canGoBack = webView.canGoBack
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        loading = false
        canGoBack = webView.canGoBack
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        loading = false
        canGoBack = webView.canGoBack
        errorMessage = error.localizedDescription
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        loading = false
        canGoBack = webView.canGoBack
        errorMessage = error.localizedDescription
    }
}

@MainActor
private struct ChappyWebContainer: UIViewRepresentable {
    let webView: WKWebView

    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

@MainActor
struct ChappyAIView: View {
    @ObservedObject var session: ChappyWebSession

    private let blue = Color(red: 0.20, green: 0.47, blue: 0.96)

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                Image(systemName: "sparkles")
                    .foregroundStyle(blue)
                    .font(.title3)
                VStack(alignment: .leading, spacing: 2) {
                    Text("チャッピー")
                        .font(.headline)
                    Text("ChatGPTをアプリ内で開く")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 4)
                Button(action: session.back) {
                    Image(systemName: "chevron.left")
                        .frame(width: 44, height: 44)
                }
                .disabled(!session.canGoBack)
                .accessibilityLabel("戻る")
                Button(action: session.reload) {
                    Image(systemName: "arrow.clockwise")
                        .frame(width: 44, height: 44)
                }
                .accessibilityLabel("再読み込み")
                Link(destination: ChappyWebSession.chatURL) {
                    Image(systemName: "arrow.up.right.square")
                        .frame(width: 44, height: 44)
                }
                .accessibilityLabel("SafariでChatGPTを開く")
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 16)
            .frame(height: 64)
            .background(Color(red: 0.075, green: 0.088, blue: 0.12))

            if session.loading {
                ProgressView().tint(blue)
            }

            if let error = session.errorMessage {
                HStack {
                    Image(systemName: "exclamationmark.triangle")
                    Text("ページを読み込めません: \\(error)")
                        .lineLimit(2)
                    Spacer(minLength: 0)
                    Link("Safariで開く", destination: ChappyWebSession.chatURL)
                }
                .font(.caption)
                .padding(10)
                .background(blue.opacity(0.12))
            }

            ChappyWebContainer(webView: session.webView)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(Color(red: 0.03, green: 0.04, blue: 0.06))
        .onAppear { session.openIfNeeded() }
    }
}
