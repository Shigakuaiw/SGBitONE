
import SwiftUI

@MainActor
struct BrowserStartPage: View {
    @ObservedObject var browser: RelayBrowserModel
    @ObservedObject var library: BrowserLibrary
    @AppStorage("bb.theme.dark") private var darkTheme = true
    private var textColor: Color { darkTheme ? .white : Color(red: 0.10, green: 0.14, blue: 0.22) }
    private var cardColor: Color { darkTheme ? .white.opacity(0.08) : .black.opacity(0.045) }
    private var subtleCardColor: Color { darkTheme ? Color.white.opacity(0.06) : Color.black.opacity(0.035) }
    private var outlineColor: Color { darkTheme ? .white.opacity(0.10) : .black.opacity(0.09) }
    let focusAddress: () -> Void
    let open: (URL) -> Void

    private let columns = [
        GridItem(.adaptive(minimum: 92, maximum: 120), spacing: 18)
    ]

    private var bookmarkItems: [BrowserBookmark] { Array(library.bookmarks.prefix(24)) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                header
                quickSearch
                favoritesSection
                if !library.history.isEmpty {
                    recentSection
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 22)
            .padding(.bottom, 48)
            .frame(maxWidth: 920, alignment: .leading)
            .frame(maxWidth: .infinity, alignment: .top)
        }
        .background { ONEWallpaperBackground(area: .browser) }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("新しいタブ")
                .font(.system(size: 34, weight: .bold, design: .rounded))
                .foregroundStyle(textColor)
            Text("Safariみたいに、お気に入りからすぐ開けます。")
                .font(.subheadline)
                .foregroundStyle(textColor.opacity(0.74))
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(cardColor, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .stroke(outlineColor, lineWidth: 1)
        }
    }

    private var quickSearch: some View {
        Button(action: focusAddress) {
            HStack(spacing: 12) {
                Image(systemName: "magnifyingglass")
                    .font(.headline)
                Text("検索 / Webサイト名入力")
                    .font(.headline)
                Spacer(minLength: 0)
                Image(systemName: "mic")
                    .font(.headline)
                    .opacity(0.8)
            }
            .foregroundStyle(textColor.opacity(0.88))
            .padding(.horizontal, 18)
            .padding(.vertical, 16)
            .background(.ultraThinMaterial, in: Capsule())
            .overlay {
                Capsule().stroke(outlineColor, lineWidth: 1)
            }
        }
        .buttonStyle(.plain)
    }

    private var favoritesSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionTitle("お気に入り", systemImage: "star.fill")
            if bookmarkItems.isEmpty {
                emptyFavorites
            } else {
                LazyVGrid(columns: columns, alignment: .leading, spacing: 18) {
                    ForEach(bookmarkItems) { entry in
                        FavoriteTile(entry: entry) { open(entry.url) }
                    }
                }
            }
        }
    }

    private var emptyFavorites: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("まだお気に入りがありません")
                .font(.headline)
                .foregroundStyle(textColor)
            Text("サイトを開いてからメニューの「ブックマークに追加」を押すと、ここにSafariみたいに並びます。")
                .font(.subheadline)
                .foregroundStyle(textColor.opacity(0.72))
            Button("URL欄を開く", action: focusAddress)
                .buttonStyle(.borderedProminent)
                .tint(.blue)
        }
        .padding(18)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(subtleCardColor, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(outlineColor, lineWidth: 1)
        }
    }

    private var recentSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            sectionTitle("最近見た項目", systemImage: "clock")
            VStack(spacing: 10) {
                ForEach(Array(library.history.prefix(6))) { entry in
                    Button(action: { open(entry.url) }) {
                        HStack(spacing: 12) {
                            StartPageGlyph(title: entry.title, host: entry.url.host)
                                .frame(width: 34, height: 34)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(entry.title)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(textColor)
                                    .lineLimit(1)
                                Text(entry.url.host ?? entry.url.absoluteString)
                                    .font(.caption)
                                    .foregroundStyle(textColor.opacity(0.62))
                                    .lineLimit(1)
                            }
                            Spacer(minLength: 0)
                            Image(systemName: "chevron.right")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(textColor.opacity(0.45))
                        }
                        .padding(.horizontal, 14)
                        .padding(.vertical, 12)
                        .background(subtleCardColor, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func sectionTitle(_ title: String, systemImage: String) -> some View {
        Label(title, systemImage: systemImage)
            .font(.title3.weight(.bold))
            .foregroundStyle(textColor)
    }
}

private struct FavoriteTile: View {
    @AppStorage("bb.theme.dark") private var darkTheme = true
    private var textColor: Color { darkTheme ? .white : Color(red: 0.10, green: 0.14, blue: 0.22) }
    private var subtleCardColor: Color { darkTheme ? Color.white.opacity(0.06) : Color.black.opacity(0.035) }
    private var outlineColor: Color { darkTheme ? Color.white.opacity(0.10) : Color.black.opacity(0.09) }
    let entry: BrowserBookmark
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 10) {
                StartPageGlyph(title: entry.title, host: entry.url.host)
                    .frame(width: 66, height: 66)
                Text(entry.title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(textColor)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .frame(maxWidth: .infinity)
                Text(entry.url.host ?? "")
                    .font(.caption)
                    .foregroundStyle(textColor.opacity(0.58))
                    .lineLimit(1)
                    .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 14)
            .frame(maxWidth: .infinity, minHeight: 136, alignment: .top)
            .background(subtleCardColor, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(outlineColor, lineWidth: 1)
            }
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button("開く", action: action)
            Link(destination: entry.url) { Label("URLを確認", systemImage: "link") }
        }
    }
}

private struct StartPageGlyph: View {
    let title: String
    let host: String?

    private var accent: Color {
        let key = (host ?? title).lowercased()
        let palette: [Color] = [.blue, .cyan, .teal, .indigo, .purple, .mint]
        let value = abs(key.hashValue) % palette.count
        return palette[value]
    }

    private var letter: String {
        if let host, let scalar = host.unicodeScalars.first(where: { CharacterSet.alphanumerics.contains($0) }) {
            return String(Character(scalar)).uppercased()
        }
        return String(title.prefix(1)).uppercased()
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(.white.opacity(0.92))
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(accent.opacity(0.16))
            Text(letter)
                .font(.system(size: 28, weight: .bold, design: .rounded))
                .foregroundStyle(accent)
        }
    }
}
