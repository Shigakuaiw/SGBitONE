import SwiftUI
import WebKit
import Combine

struct BrowserDownloadRecord: Codable, Identifiable {
    enum State: String, Codable { case downloading, completed, cancelled, failed }
    enum Location: String, Codable { case documents }
    var id = UUID()
    var filename = "download"
    var source: String?
    var isPrivate = false
    var received: Int64 = 0
    var total: Int64 = 0
    var state = State.downloading
    var message = ""
    var date = Date()
    var location: Location?
}

@MainActor
final class BrowserDownloads: NSObject, ObservableObject, WKDownloadDelegate {
    typealias AuthenticationHandler = (URLAuthenticationChallenge, @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) -> Void
    @Published private(set) var records: [BrowserDownloadRecord] = []
    @Published private(set) var error = ""
    private let directory: URL
    private let legacyDirectory: URL
    private let indexFile: URL
    private var downloads: [UUID: WKDownload] = [:]
    private var identifiers: [ObjectIdentifier: UUID] = [:]
    private var observations: [UUID: AnyCancellable] = [:]
    private var authenticationHandlers: [UUID: AuthenticationHandler] = [:]
    private var writable = true

    init(directory: URL? = nil, legacyDirectory: URL? = nil) {
        let manager = FileManager.default
        self.directory = directory ?? manager.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Downloads", isDirectory: true)
        self.legacyDirectory = legacyDirectory ?? directory ?? manager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Downloads", isDirectory: true)
        // Keep the index and legacy files private; only new payloads go into Documents.
        indexFile = self.legacyDirectory.appendingPathComponent("index.json")
        super.init()
        do {
            try manager.createDirectory(at: self.directory, withIntermediateDirectories: true)
            try manager.createDirectory(at: self.legacyDirectory, withIntermediateDirectories: true)
            if FileManager.default.fileExists(atPath: indexFile.path) {
                records = try JSONDecoder().decode([BrowserDownloadRecord].self, from: Data(contentsOf: indexFile))
                for index in records.indices where records[index].state == .downloading {
                    records[index].state = .failed
                    records[index].message = "Appの終了で中断しました。元のページから再試行してください"
                }
            }
        } catch { writable = false; self.error = "ダウンロード一覧を読み込めません" }
    }

    var activeCount: Int { records.filter { $0.state == .downloading }.count }

    static func progressFraction(_ records: [BrowserDownloadRecord]) -> Double? {
        let active = records.filter { $0.state == .downloading }
        guard !active.isEmpty, active.allSatisfy({ $0.total > 0 }) else { return nil }
        let total = active.reduce(0.0) { $0 + Double($1.total) }
        let received = active.reduce(0.0) { $0 + Double(min($1.total, max(0, $1.received))) }
        return received / total
    }

    var progressFraction: Double? { Self.progressFraction(records) }

    var progressDescription: String {
        if activeCount > 0 {
            if let progressFraction { return "\(activeCount)件をダウンロード中、\(Int(progressFraction * 100))%" }
            return "\(activeCount)件をダウンロード中、サイズ不明"
        }
        guard let state = records.first?.state else { return "ダウンロード一覧" }
        switch state {
        case .completed: return "ダウンロード完了"
        case .failed: return "ダウンロード失敗"
        case .cancelled: return "キャンセル済み"
        default: return "ダウンロード一覧"
        }
    }

    private func folderURL(_ record: BrowserDownloadRecord) throws -> URL {
        guard record.filename == Self.safeFilename(record.filename) else { throw CocoaError(.fileReadInvalidFileName) }
        let base = record.location == .documents ? directory : legacyDirectory
        if let values = try? base.resourceValues(forKeys: [.isSymbolicLinkKey]), values.isSymbolicLink == true {
            throw CocoaError(.fileReadInvalidFileName)
        }
        let folder = base.appendingPathComponent(record.id.uuidString, isDirectory: true)
        let resolved = folder.resolvingSymlinksInPath().standardizedFileURL
        guard resolved.path == base.resolvingSymlinksInPath().appendingPathComponent(record.id.uuidString, isDirectory: true).standardizedFileURL.path else {
            throw CocoaError(.fileReadInvalidFileName)
        }
        return folder
    }

    private func payloadURL(_ record: BrowserDownloadRecord) throws -> URL {
        let folder = try folderURL(record)
        let file = folder.appendingPathComponent(record.filename)
        guard file.resolvingSymlinksInPath().standardizedFileURL.path
            == folder.resolvingSymlinksInPath().appendingPathComponent(record.filename).standardizedFileURL.path else {
            throw CocoaError(.fileReadInvalidFileName)
        }
        return file
    }

    static func safeFilename(_ proposed: String) -> String {
        let value = proposed.replacingOccurrences(of: "\\", with: "/").components(separatedBy: "/").last ?? ""
        var clean = String(value.filter { !$0.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains) }.prefix(120))
        while clean.utf8.count > 180 { clean.removeLast() }
        return clean.isEmpty || clean == "." || clean == ".." ? "download" : clean
    }

    private func save() throws {
        guard writable else { throw CocoaError(.fileWriteNoPermission) }
        try JSONEncoder().encode(records).write(to: indexFile, options: .atomic)
    }

    func attach(_ download: WKDownload, isPrivate: Bool, authentication: AuthenticationHandler? = nil) {
        let record = BrowserDownloadRecord(source: isPrivate ? nil : download.originalRequest?.url.flatMap {
            BrowserAddress.webURL($0.absoluteString)?.absoluteString
        }, isPrivate: isPrivate, location: .documents)
        identifiers[ObjectIdentifier(download)] = record.id
        downloads[record.id] = download
        authenticationHandlers[record.id] = authentication
        records.insert(record, at: 0)
        download.delegate = self
        observations[record.id] = download.progress.publisher(for: \.completedUnitCount)
            .throttle(for: .milliseconds(250), scheduler: RunLoop.main, latest: true)
            .sink { [weak self, weak download] _ in
                Task { @MainActor in
                    guard let self, let download,
                          let index = self.records.firstIndex(where: { $0.id == record.id }) else { return }
                    self.records[index].received = download.progress.completedUnitCount
                    self.records[index].total = download.progress.totalUnitCount
                }
            }
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        guard let id = identifiers[ObjectIdentifier(download)], let index = records.firstIndex(where: { $0.id == id }) else {
            completionHandler(nil); return
        }
        records[index].filename = Self.safeFilename(suggestedFilename)
        records[index].total = max(0, response.expectedContentLength)
        do {
            let folder = try folderURL(records[index])
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let file = try payloadURL(records[index])
            try save()
            completionHandler(file)
        } catch {
            self.error = "保存先を用意できません: \(error.localizedDescription)"
            finish(id, state: .failed, message: self.error)
            completionHandler(nil)
        }
    }

    func downloadDidFinish(_ download: WKDownload) {
        guard let id = identifiers[ObjectIdentifier(download)] else { return }
        finish(id, state: .completed, message: "保存完了")
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        guard let id = identifiers[ObjectIdentifier(download)] else { return }
        finish(id, state: .failed, message: error.localizedDescription)
    }

    func download(_ download: WKDownload, didReceive challenge: URLAuthenticationChallenge,
                  completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        guard let id = identifiers[ObjectIdentifier(download)], let authenticate = authenticationHandlers[id] else {
            completionHandler(.performDefaultHandling, nil); return
        }
        authenticate(challenge) { [weak self] disposition, credential in
            guard self?.downloads[id] === download else { completionHandler(.cancelAuthenticationChallenge, nil); return }
            completionHandler(disposition, credential)
        }
    }

    func download(_ download: WKDownload, willPerformHTTPRedirection response: HTTPURLResponse,
                  newRequest request: URLRequest, decisionHandler: @escaping (WKDownload.RedirectPolicy) -> Void) {
        decisionHandler(request.url.flatMap { BrowserAddress.webURL($0.absoluteString) } != nil ? .allow : .cancel)
    }

    private func finish(_ id: UUID, state: BrowserDownloadRecord.State, message: String) {
        guard let index = records.firstIndex(where: { $0.id == id }) else { return }
        if let download = downloads.removeValue(forKey: id) { identifiers.removeValue(forKey: ObjectIdentifier(download)) }
        observations.removeValue(forKey: id)
        authenticationHandlers.removeValue(forKey: id)
        records[index].state = state
        records[index].message = records[index].isPrivate && state == .failed ? "ダウンロードに失敗しました" : message
        if state == .completed {
            if let url = fileURL(records[index]), let size = try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize {
                records[index].received = Int64(size)
            } else {
                records[index].state = .failed
                records[index].message = "ダウンロード終了後に保存ファイルを確認できません"
            }
        }
        do { try save() } catch { self.error = "一覧を保存できません" }
    }

    func cancel(_ id: UUID) {
        let download = downloads[id]
        finish(id, state: .cancelled, message: "キャンセルしました")
        download?.cancel(nil)
    }

    func cancelAll() { for id in Array(downloads.keys) { cancel(id) } }

    func forgetSources() throws {
        for index in records.indices { records[index].source = nil; records[index].message = "" }
        writable = true
        try save()
    }

    func fileURL(_ record: BrowserDownloadRecord) -> URL? {
        guard record.state == .completed, record.filename == Self.safeFilename(record.filename) else { return nil }
        guard let url = try? payloadURL(record),
              let values = try? url.resourceValues(forKeys: [.isRegularFileKey]), values.isRegularFile == true else { return nil }
        return url
    }

    func remove(_ id: UUID) {
        guard let record = records.first(where: { $0.id == id }) else { return }
        if downloads[id] != nil { cancel(id) }
        do {
            let folder = try folderURL(record)
            let file = try payloadURL(record)
            if FileManager.default.fileExists(atPath: file.path) { try FileManager.default.removeItem(at: file) }
            if FileManager.default.fileExists(atPath: folder.path), try FileManager.default.contentsOfDirectory(atPath: folder.path).isEmpty {
                try FileManager.default.removeItem(at: folder)
            }
            records.removeAll { $0.id == id }
            try save()
        } catch { self.error = "削除できません: \(error.localizedDescription)" }
    }
}
