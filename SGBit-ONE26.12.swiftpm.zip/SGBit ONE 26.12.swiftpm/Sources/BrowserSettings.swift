import SwiftUI

@available(iOS 17.0, *)
@MainActor
struct BrowserSettings: View {
    @ObservedObject var browser: RelayBrowserModel
    var onDone: (() -> Void)? = nil
    @EnvironmentObject private var preferences: BrowserPreferences
    @EnvironmentObject private var security: BrowserSecurity
    @Environment(\.dismiss) private var dismiss
    private let accentBlue = Color(red: 0.20, green: 0.47, blue: 0.96)
    @AppStorage("bb.browser.customKeyboard") private var customKeyboardEnabled = false
    @State private var homeDraft = ""
    @StateObject private var homeInput = BrowserTextInput()
    @State private var confirmDeletion = false
    @State private var deleteAll = false
    @State private var deletionHost: String?
    @State private var buildTapCount = 0
    @State private var showAdminOptions = false

    private var intro: some View {
        HStack(spacing: 15) {
            Image(systemName: "globe.americas.fill")
                .font(.system(size: 29))
                .foregroundStyle(.white)
                .frame(width: 58, height: 58)
                .background(accentBlue.gradient, in: RoundedRectangle(cornerRadius: 16))
            VStack(alignment: .leading, spacing: 4) {
                Text("SGBit ONE 26.9").font(.title2.bold())
                Text("ブラウザの動作とプライバシーを管理")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 8)
        .listRowBackground(Color.clear)
    }

    private var generalSection: some View {
        Section("一般") {
            NavigationLink {
                BrowserInputDiagnostics()
            } label: {
                Label("入力の診断", systemImage: "keyboard")
            }
            NavigationLink {
                ScrollView {
                    Text(BrowserDictionary.licenseNotice)
                        .font(.caption).textSelection(.enabled).padding()
                }.navigationTitle("辞書ライセンス")
            } label: {
                Label("辞書ライセンス", systemImage: "text.book.closed")
            }
        }
    }

    private var homeSection: some View {
        Section {
            BrowserURLField(text: $homeDraft, input: homeInput) {
                _ = browser.saveHomeAddress(homeDraft)
            }
            .frame(height: 44)
            .accessibilityLabel("ホームページURL")
            Button {
                homeInput.resign()
                if browser.saveHomeAddress(homeDraft) { homeDraft = browser.homeAddress }
            } label: {
                Label("このURLをホームページに設定", systemImage: "checkmark.circle")
            }
            Button {
                homeInput.resign()
                homeDraft = RelayBrowserModel.defaultHomeAddress
                _ = browser.saveHomeAddress(homeDraft)
            } label: {
                Label("Googleに戻す", systemImage: "arrow.uturn.backward")
            }
        } header: { Label("ホームページ", systemImage: "house") }
    }

    private var appearanceSection: some View {
        Section {
            Toggle("ブックマークバーを表示", isOn: $preferences.state.showBookmarksBar)
            Toggle("通常タブを次回起動時に復元", isOn: $preferences.state.restoreTabs)
            Toggle("閲覧履歴を残さない", isOn: Binding(
                get: { !preferences.state.keepHistory },
                set: { preferences.state.keepHistory = !$0 }
            ))
        } header: { Label("表示と履歴", systemImage: "eye") }
        footer: {
            Text("閲覧履歴を残さない場合もCookieは残ります。プライベートタブは復元されません。")
        }
    }

    private var oneSettingsSection: some View {
        Section("SGBit ONE") {
            NavigationLink { ONEOSCustomizationSettings() } label: { Label("ロック画面とOS風UI", systemImage: "lock.iphone") }
            NavigationLink { ONEWallpaperSettings() } label: { Label("壁紙", systemImage: "photo.fill") }
            NavigationLink { ThemeEditorScreen() } label: { Label("テーマと外観", systemImage: "paintpalette.fill") }
            NavigationLink { ONEBackupView() } label: { Label("バックアップ", systemImage: "externaldrive.fill") }
            NavigationLink { ONEAccountSettings() } label: { Label("アカウント", systemImage: "person.crop.circle") }
            NavigationLink { ONEUpdatesScreen() } label: { Label("ソフトウェアアップデート", systemImage: "arrow.down.circle.fill") }
        }
    }

    private var keyboardSection: some View {
        Section {
            Toggle("SGBit独自キーボードを使用", isOn: $customKeyboardEnabled)
            Picker("キーサイズ", selection: $preferences.state.keyboardSize) {
                ForEach(BrowserKeyboardSize.allCases, id: \.self) { size in
                    Text(size.title).tag(size)
                }
            }
            .pickerStyle(.segmented)
            .disabled(!customKeyboardEnabled)
        } header: { Label("キーボード", systemImage: "keyboard") }
        footer: { Text("初期状態ではiPadOS標準キーボードを使用します。独自キーボードは必要なときだけオンにできます。") }
    }

    private var privacySection: some View {
        Section {
            NavigationLink {
                BrowserPINSettings(security: security)
            } label: {
                Label(security.enabled ? "PINロック：有効" : "PINロックを設定", systemImage: "lock")
            }
            NavigationLink {
                PasswordVaultView()
            } label: {
                Label("SGBit Passwords", systemImage: "key.horizontal")
            }
            Toggle("AdGuard DNS（DoH）", isOn: $preferences.state.adGuardDNS)
        } header: { Label("プライバシーとセキュリティ", systemImage: "shield.lefthalf.filled") }
        footer: {
            Text("DNSによる広告ブロックはすべての広告を防ぐものではありません。設定変更時には接続を切り直します。")
        }
    }

    private var dataSection: some View {
        Section {
            Button(role: .destructive) {
                deletionHost = browser.selectedTab?.webView.url?.host
                deleteAll = false
                confirmDeletion = true
            } label: {
                Label("現在のサイトのデータを削除", systemImage: "trash")
            }
            .disabled(browser.selectedTab?.webView.url?.host == nil || browser.isClearingData)
            Button(role: .destructive) {
                deleteAll = true
                confirmDeletion = true
            } label: {
                Label("すべてのサイトデータを削除", systemImage: "trash.slash")
            }
            .disabled(browser.isClearingData)
        } header: { Label("サイトデータ", systemImage: "externaldrive") }
        footer: {
            Text("Cookie・キャッシュなどを削除します。操作は取り消せず、関連するタブも閉じます。")
        }
    }

    private var advancedSection: some View {
        Section("詳細設定") {
            Toggle("通信状況バーを表示", isOn: $preferences.state.debugStatusBar)
            if !browser.settingsMessage.isEmpty {
                Text(browser.settingsMessage)
                    .font(.caption).accessibilityAddTraits(.updatesFrequently)
            }
            Text("編集メニューはOS標準の言語設定に従います。")
                .font(.caption).foregroundStyle(.secondary)
            Text("アプリの言語: \(Bundle.main.preferredLocalizations.joined(separator: ", "))")
                .font(.caption).foregroundStyle(.secondary)
            Button {
                buildTapCount += 1
                if buildTapCount >= 7 {
                    buildTapCount = 0
                    showAdminOptions = true
                }
            } label: {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("ビルドコード").foregroundStyle(.primary)
                        Text("2690").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("ビルドコード 2680。7回タップで管理者オプション")
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                intro
                generalSection
                oneSettingsSection
                homeSection
                appearanceSection
                keyboardSection
                privacySection
                dataSection
                advancedSection
            }
            .formStyle(.grouped)
            .tint(accentBlue)
            .navigationTitle("設定")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完了") { if let onDone { onDone() } else { dismiss() } }.disabled(browser.isClearingData)
                }
            }
            .onAppear { homeDraft = browser.homeAddress }
            .sheet(isPresented: $showAdminOptions) {
                ONEAdminOptionsScreen()
            }
            .interactiveDismissDisabled(browser.isClearingData)
            .confirmationDialog("Cookieとサイトデータを削除しますか？", isPresented: $confirmDeletion,
                                titleVisibility: .visible) {
                Button("削除", role: .destructive) {
                    guard deleteAll || deletionHost != nil else { return }
                    let host = deleteAll ? nil : deletionHost
                    Task { await browser.clearSiteData(host: host) }
                }
                Button("キャンセル", role: .cancel) {}
            } message: {
                Text(deleteAll ? "すべてのタブを閉じ、全サイトのCookie・localStorage・キャッシュ等を削除します。元に戻せません。" : "\(deletionHost ?? "")と関連サイトのタブを閉じ、保存データを削除します。元に戻せません。")
            }
        }
    }
}
