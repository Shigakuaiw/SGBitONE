import Foundation
#if canImport(Darwin) && canImport(Network)
import Darwin
import Network

// All state and callbacks belong to the relay's serial queue.
final class RelayDirectTCP: @unchecked Sendable {
    let host: String
    let port: UInt16
    private let queue: DispatchQueue
    private let network: NWConnection?
    var transportDescription: String { network == nil ? "直接TCP（BSDソケット）" : "TCP（Network.framework）" }
    private var descriptor: Int32 = -1
    private var started = false
    private var closed = false
    private var connected = false
    private var readEnded = false
    private var writeEnded = false
    private var readSource: DispatchSourceRead?
    private var writeSource: DispatchSourceWrite?
    private var activeSources = 0
    private var reader: ((Data?, Bool, NWError?) -> Void)?
    private var readLimit = 0
    private struct Write {
        let data: Data
        var offset = 0
        let final: Bool
        let completion: (NWError?) -> Void
    }
    private var writer: Write?
    var stateUpdateHandler: ((NWConnection.State) -> Void)?

    init(host: String, port: UInt16, queue: DispatchQueue) {
        self.host = host; self.port = port; self.queue = queue
        if !host.utf8.contains(0), !Self.isLocalAddress(host), port != 0, IPv4Address(host) != nil || IPv6Address(host) != nil {
            let parameters = NWParameters.tcp
            parameters.preferNoProxies = true
            network = NWConnection(host: NWEndpoint.Host(host), port: NWEndpoint.Port(rawValue: port)!, using: parameters)
        } else { network = nil }
    }

    static func isLocalAddress(_ host: String) -> Bool {
        if let address = IPv4Address(host) {
            let bytes = Array(address.rawValue)
            return bytes[0] == 10 || bytes[0] == 127 ||
                (bytes[0] == 172 && (16...31).contains(bytes[1])) ||
                (bytes[0] == 192 && bytes[1] == 168) || (bytes[0] == 169 && bytes[1] == 254)
        }
        if let address = IPv6Address(host) {
            let bytes = Array(address.rawValue)
            if bytes.prefix(15).allSatisfy({ $0 == 0 }) && bytes[15] == 1 { return true }
            // IPv4-mapped IPv6 keeps the same routing choice as its IPv4 address.
            if bytes.prefix(10).allSatisfy({ $0 == 0 }), bytes[10] == 255, bytes[11] == 255 {
                return isLocalAddress(bytes.suffix(4).map { String($0) }.joined(separator: "."))
            }
            return bytes[0] & 0xfe == 0xfc || (bytes[0] == 0xfe && bytes[1] & 0xc0 == 0x80)
        }
        return false
    }

    func inspectRoute(queue: DispatchQueue, completion: @escaping (RelayUpstreamRoute?) -> Void) {
        if let network {
            network.requestEstablishmentReport(queue: queue) { report in
                guard let report else { completion(nil); return }
                var endpoint: String?
                if case .hostPort(let host, let port)? = report.proxyEndpoint { endpoint = "\(host):\(port.rawValue)" }
                completion(RelayUpstreamRoute(configured: report.proxyConfigured, used: report.usedProxy, endpoint: endpoint))
            }
        } else {
            completion(matchesDestination() ? RelayUpstreamRoute(configured: nil, used: false, endpoint: nil) : nil)
        }
    }

    func start() {
        guard !started, !closed else { return }
        started = true
        if let network {
            network.stateUpdateHandler = { [weak self] state in self?.stateUpdateHandler?(state) }
            network.start(queue: queue)
            return
        }
        var hints = addrinfo()
        hints.ai_flags = AI_NUMERICHOST | AI_NUMERICSERV
        hints.ai_family = AF_UNSPEC
        hints.ai_socktype = SOCK_STREAM
        hints.ai_protocol = Int32(IPPROTO_TCP)
        var result: UnsafeMutablePointer<addrinfo>?
        guard port != 0, !host.utf8.contains(0), IPv4Address(host) != nil || IPv6Address(host) != nil,
              getaddrinfo(host, String(port), &hints, &result) == 0, let result else { fail(EINVAL); return }
        defer { freeaddrinfo(result) }
        let address = result.pointee
        descriptor = Darwin.socket(address.ai_family, address.ai_socktype, address.ai_protocol)
        guard descriptor >= 0 else { fail(errno); return }
        let flags = fcntl(descriptor, F_GETFL, 0)
        guard flags >= 0 else { fail(errno); return }
        let descriptorFlags = fcntl(descriptor, F_GETFD, 0)
        var noSignal: Int32 = 1
        guard descriptorFlags >= 0,
              fcntl(descriptor, F_SETFL, flags | O_NONBLOCK) == 0,
              fcntl(descriptor, F_SETFD, descriptorFlags | FD_CLOEXEC) == 0,
              setsockopt(descriptor, SOL_SOCKET, SO_NOSIGPIPE, &noSignal, socklen_t(MemoryLayout<Int32>.size)) == 0 else { fail(errno); return }
        let status = Darwin.connect(descriptor, address.ai_addr, address.ai_addrlen)
        if status == 0 { didConnect() }
        else if errno == EINPROGRESS { waitForWrite() }
        else { fail(errno) }
    }

    // getpeername identifies the socket endpoint, not VPNs or transparent network filtering.
    func matchesDestination() -> Bool {
        guard connected, !closed else { return false }
        var address = sockaddr_storage()
        var length = socklen_t(MemoryLayout<sockaddr_storage>.size)
        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
        var service = [CChar](repeating: 0, count: Int(NI_MAXSERV))
        let status = withUnsafeMutablePointer(to: &address) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) { socketAddress -> Int32 in
                guard Darwin.getpeername(descriptor, socketAddress, &length) == 0 else { return -1 }
                return getnameinfo(socketAddress, length, &hostname, socklen_t(NI_MAXHOST), &service, socklen_t(NI_MAXSERV), NI_NUMERICHOST | NI_NUMERICSERV)
            }
        }
        guard status == 0, UInt16(String(cString: service)) == port else { return false }
        let actual = String(cString: hostname)
        if let expected = IPv4Address(host) { return IPv4Address(actual)?.rawValue == expected.rawValue }
        if let expected = IPv6Address(host) { return IPv6Address(actual)?.rawValue == expected.rawValue }
        return false
    }

    func receive(maximumLength: Int, completion: @escaping (Data?, Bool, NWError?) -> Void) {
        guard !closed else { completion(nil, false, .posix(.ECANCELED)); return }
        if let network {
            network.receive(minimumIncompleteLength: 1, maximumLength: maximumLength) { data, _, complete, error in completion(data, complete, error) }
            return
        }
        guard connected, !closed, reader == nil, (1...65536).contains(maximumLength) else {
            completion(nil, false, .posix(.EINVAL)); return
        }
        if readEnded { completion(nil, true, nil); return }
        reader = completion; readLimit = maximumLength
        readReady()
    }

    private func readReady() {
        guard !closed, let completion = reader else { return }
        var bytes = [UInt8](repeating: 0, count: readLimit)
        var count: Int
        repeat {
            count = bytes.withUnsafeMutableBytes { Darwin.recv(descriptor, $0.baseAddress, $0.count, 0) }
        } while count < 0 && errno == EINTR
        if count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) {
            if readSource == nil {
                let source = DispatchSource.makeReadSource(fileDescriptor: descriptor, queue: queue)
                activeSources += 1
                source.setEventHandler { [weak self] in self?.readReady() }
                source.setCancelHandler { [self] in sourceReleased() }
                readSource = source; source.resume()
            }
            return
        }
        let error: NWError? = count < 0 ? .posix(POSIXErrorCode(rawValue: errno) ?? .EIO) : nil
        reader = nil
        readSource?.cancel(); readSource = nil
        if count == 0 { readEnded = true }
        completion(count > 0 ? Data(bytes.prefix(count)) : nil, count == 0, error)
    }

    func send(_ data: Data?, final: Bool = false, completion: @escaping (NWError?) -> Void) {
        guard !closed else { completion(.posix(.ECANCELED)); return }
        if let network {
            network.send(content: data, contentContext: final ? .finalMessage : .defaultMessage, isComplete: true, completion: .contentProcessed(completion))
            return
        }
        guard connected, !closed, !writeEnded, writer == nil, (data?.count ?? 0) <= 65536 else {
            completion(.posix(.EINVAL)); return
        }
        writer = Write(data: data ?? Data(), final: final, completion: completion)
        writeReady()
    }

    private func writeReady() {
        guard !closed else { return }
        if !connected {
            var error: Int32 = 0
            var length = socklen_t(MemoryLayout<Int32>.size)
            guard getsockopt(descriptor, SOL_SOCKET, SO_ERROR, &error, &length) == 0 else { fail(errno); return }
            guard error == 0 else { fail(error); return }
            didConnect()
            return
        }
        guard var pending = writer else { return }
        while pending.offset < pending.data.count {
            let count = pending.data.withUnsafeBytes { bytes in
                Darwin.send(descriptor, bytes.baseAddress!.advanced(by: pending.offset), bytes.count - pending.offset, 0)
            }
            if count > 0 { pending.offset += count; continue }
            if count < 0 && errno == EINTR { continue }
            if count < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) {
                writer = pending; waitForWrite(); return
            }
            let error = NWError.posix(count == 0 ? .EPIPE : POSIXErrorCode(rawValue: errno) ?? .EIO)
            writer = nil; stopWriteSource()
            pending.completion(error)
            return
        }
        var error: NWError?
        if pending.final {
            var status: Int32
            repeat { status = Darwin.shutdown(descriptor, Int32(SHUT_WR)) } while status < 0 && errno == EINTR
            if status != 0 { error = .posix(POSIXErrorCode(rawValue: errno) ?? .EIO) }
            else { writeEnded = true }
        }
        writer = nil; stopWriteSource()
        pending.completion(error)
    }

    private func didConnect() {
        connected = true
        stopWriteSource()
        stateUpdateHandler?(.ready)
    }

    private func waitForWrite() {
        guard writeSource == nil, !closed else { return }
        let source = DispatchSource.makeWriteSource(fileDescriptor: descriptor, queue: queue)
        activeSources += 1
        source.setEventHandler { [weak self] in self?.writeReady() }
        source.setCancelHandler { [self] in sourceReleased() }
        writeSource = source; source.resume()
    }

    private func stopWriteSource() { writeSource?.cancel(); writeSource = nil }
    private func sourceReleased() { activeSources -= 1; closeDescriptorIfUnused() }
    private func closeDescriptorIfUnused() {
        // Cancellation is asynchronous; keep the descriptor alive until every source releases it.
        guard closed, activeSources == 0, descriptor >= 0 else { return }
        Darwin.close(descriptor); descriptor = -1
    }
    private func closeResources() {
        closed = true
        network?.stateUpdateHandler = nil
        network?.cancel()
        reader = nil; writer = nil
        readSource?.cancel(); readSource = nil
        stopWriteSource()
        closeDescriptorIfUnused()
    }
    private func fail(_ code: Int32) {
        guard !closed else { return }
        closeResources()
        stateUpdateHandler?(.failed(.posix(POSIXErrorCode(rawValue: code) ?? .EIO)))
    }
    func cancel() {
        guard !closed else { return }
        closeResources()
        stateUpdateHandler?(.cancelled)
    }
}
#endif
