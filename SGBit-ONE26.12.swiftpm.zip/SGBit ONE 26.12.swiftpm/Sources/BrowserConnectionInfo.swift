import SwiftUI
import WebKit
import Security
import CryptoKit

enum BrowserConnectionState: Equatable {
    case empty, loading, http, secure, mixed, unavailable, failed

    static func classify(url: URL?, loading: Bool, failed: Bool, committed: Bool,
                         hasTrust: Bool, onlySecureContent: Bool) -> Self {
        if failed { return .failed }
        if loading { return .loading }
        guard committed, let scheme = url?.scheme?.lowercased() else { return .empty }
        if scheme == "http" { return .http }
        guard scheme == "https" else { return .empty }
        guard hasTrust else { return .unavailable }
        return onlySecureContent ? .secure : .mixed
    }
    var title: String {
        switch self {
        case .empty: return "接続情報はありません"
        case .loading: return "接続を確認中"
        case .http: return "HTTP：暗号化されていません"
        case .secure: return "HTTPS：暗号化された接続"
        case .mixed: return "HTTPS：暗号化されていない要素を含みます"
        case .unavailable: return "HTTPS：証明書情報を取得できません"
        case .failed: return "接続を確認できませんでした"
        }
    }
    var icon: String {
        switch self {
        case .secure: return "lock.fill"
        case .http: return "lock.open"
        case .mixed, .failed: return "exclamationmark.shield"
        default: return "lock.slash"
        }
    }
}

struct BrowserCertificateInfo: Identifiable {
    let id: Int
    let subject: String
    let serial: String
    let sha256: String
    let validFrom: Date?
    let validUntil: Date?

    init(_ certificate: SecCertificate, index: Int) {
        id = index
        subject = (SecCertificateCopySubjectSummary(certificate) as String?) ?? "名前を取得できません"
        let data = SecCertificateCopyData(certificate) as Data
        sha256 = Self.hex(Data(SHA256.hash(data: data)))
        serial = SecCertificateCopySerialNumberData(certificate, nil).map { Self.hex($0 as Data) } ?? "取得できません"
        if #available(iOS 18.0, *) {
            validFrom = SecCertificateCopyNotValidBeforeDate(certificate).map { $0 as Date }
            validUntil = SecCertificateCopyNotValidAfterDate(certificate).map { $0 as Date }
        } else { validFrom = nil; validUntil = nil }
    }
    private static func hex(_ data: Data) -> String {
        data.map { String(format: "%02X", $0) }.joined(separator: ":")
    }
}

@MainActor
struct BrowserConnectionView: View {
    @ObservedObject var tab: BrowserTab
    @Environment(\.dismiss) private var dismiss

    private var certificates: [BrowserCertificateInfo] {
        guard tab.connectionState == .secure || tab.connectionState == .mixed,
              let trust = tab.webView.serverTrust,
              let chain = SecTrustCopyCertificateChain(trust) as? [SecCertificate] else { return [] }
        return chain.enumerated().map { BrowserCertificateInfo($0.element, index: $0.offset) }
    }

    var body: some View {
        NavigationStack {
            List {
                Section("接続") {
                    Label(tab.connectionState.title, systemImage: tab.connectionState.icon)
                    if let url = tab.connectionURL, let host = url.host {
                        Text(BrowserDialogRequest.origin(scheme: url.scheme ?? "", host: host, port: url.port ?? 0))
                            .textSelection(.enabled)
                    }
                    if tab.connectionState == .secure {
                        Text("WebKitの標準検証を通過したページです。端末が信頼する証明書が使われます。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                ForEach(certificates) { item in certificateSection(item) }
                if certificates.isEmpty {
                    Section { Text("この接続で表示できる証明書はありません。").foregroundStyle(.secondary) }
                }
            }
            .navigationTitle("接続と証明書")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() } } }
        }.privacySensitive()
    }

    private func certificateSection(_ item: BrowserCertificateInfo) -> some View {
        Section(item.id == 0 ? "サーバー証明書" : "証明書チェーン \(item.id + 1)") {
            Text(item.subject).textSelection(.enabled)
            LabeledContent("シリアル番号") { Text(item.serial).textSelection(.enabled) }
            if let from = item.validFrom { LabeledContent("有効期間の開始") { Text(from.formatted(date: .numeric, time: .standard)) } }
            if let until = item.validUntil { LabeledContent("有効期限") { Text(until.formatted(date: .numeric, time: .standard)) } }
            VStack(alignment: .leading, spacing: 4) {
                Text("SHA-256指紋").font(.caption)
                Text(item.sha256).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
            }
        }
    }
}
