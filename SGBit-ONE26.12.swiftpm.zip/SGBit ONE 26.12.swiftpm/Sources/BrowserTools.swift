import SwiftUI

@available(iOS 17.0, *)
@MainActor
struct BrowserLibraryView: View {
    @ObservedObject var browser: RelayBrowserModel
    @ObservedObject var library: BrowserLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var historySelected = false
    @State private var confirmClear = false

    var body: some View {
        NavigationStack {
            List {
                Picker("一覧", selection: $historySelected) {
                    Text("ブックマーク").tag(false)
                    Text("履歴").tag(true)
                }.pickerStyle(.segmented)
                if !library.error.isEmpty { Text(library.error).foregroundStyle(.red) }
                if historySelected {
                    ForEach(library.history) { entry in
                        Button { browser.open(entry.url); dismiss() } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(entry.title).lineLimit(1)
                                Text(entry.url.absoluteString).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                Text(entry.date, style: .date).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                    }
                    if library.history.isEmpty { Text("履歴はありません").foregroundStyle(.secondary) }
                    Button("履歴をすべて削除", role: .destructive) { confirmClear = true }
                } else {
                    Button("このページを追加", systemImage: "star") { browser.addCurrentBookmark() }
                        .disabled(browser.selectedTab?.webView.url == nil)
                    ForEach(library.bookmarks) { entry in
                        Button { browser.open(entry.url); dismiss() } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(entry.title).lineLimit(1)
                                Text(entry.url.absoluteString).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                        }
                        .swipeActions { Button("削除", role: .destructive) { library.removeBookmark(entry.id) } }
                    }
                }
            }
            .navigationTitle("ブックマーク・履歴")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() } } }
            .confirmationDialog("履歴をすべて削除しますか？", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("履歴を削除", role: .destructive) { library.clearHistory() }
                Button("キャンセル", role: .cancel) {}
            } message: { Text("元に戻せません。Cookieやブックマークは保持します。") }
        }
    }
}

@available(iOS 17.0, *)
@MainActor
struct BrowserDownloadToolbarButton: View {
    @ObservedObject var downloads: BrowserDownloads
    let open: () -> Void

    var body: some View {
        if !downloads.records.isEmpty {
            Button(action: open) {
                glyph.frame(width: 44, height: 44)
            }
            .accessibilityLabel("ダウンロード状況を開く")
            .accessibilityValue(downloads.progressDescription)
        }
    }

    private var glyph: some View {
        ZStack {
            if downloads.activeCount > 0 {
                Circle().stroke(Color.secondary.opacity(0.25), lineWidth: 2)
                if let fraction = downloads.progressFraction {
                    Circle().trim(from: 0, to: CGFloat(fraction))
                        .stroke(Color.accentColor, style: StrokeStyle(lineWidth: 2, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                } else { ProgressView().controlSize(.small) }
                Image(systemName: "arrow.down").font(.system(size: 11, weight: .semibold))
            } else {
                Image(systemName: downloads.records.first?.state == .failed ? "exclamationmark.circle" : "arrow.down.circle")
                    .font(.system(size: 24))
            }
        }
        .frame(width: 24, height: 24)
        .overlay(alignment: .topTrailing) {
            if downloads.activeCount > 1 {
                Text("\(downloads.activeCount)").font(.system(size: 9, weight: .semibold))
                    .padding(2).background(.background, in: Circle()).offset(x: 6, y: -6)
            }
        }
    }
}

@available(iOS 17.0, *)
@MainActor
struct BrowserDownloadsView: View {
    @ObservedObject var downloads: BrowserDownloads
    @Environment(\.dismiss) private var dismiss
    @State private var deletion: UUID?
    @State private var confirmDelete = false

    var body: some View {
        NavigationStack {
            List {
                Text("新規保存先：ファイル → このiPad内／このiPhone内 → このApp → Downloads。保存ファイルはAppのPINロック対象外です。")
                    .font(.caption).foregroundStyle(.secondary)
                if !downloads.error.isEmpty { Text(downloads.error).foregroundStyle(.red) }
                if downloads.records.isEmpty { Text("ダウンロードはありません").foregroundStyle(.secondary) }
                ForEach(downloads.records) { record in
                    VStack(alignment: .leading, spacing: 7) {
                        Label(record.filename, systemImage: record.isPrivate ? "eye.slash" : "doc").lineLimit(2)
                        if record.state == .downloading {
                            if record.total > 0 { ProgressView(value: Double(record.received), total: Double(max(record.total, record.received))) }
                            else { ProgressView() }
                            Text("\(bytes(record.received)) / \(record.total > 0 ? bytes(record.total) : "不明")").font(.caption)
                            Button("キャンセル", role: .destructive) { downloads.cancel(record.id) }
                        } else {
                            Text(record.message.isEmpty ? stateName(record.state) : record.message).font(.caption).foregroundStyle(.secondary)
                            if let file = downloads.fileURL(record) { ShareLink("共有・“ファイル”に保存", item: file) }
                            else if record.state == .completed { Text("保存ファイルが見つかりません").font(.caption).foregroundStyle(.red) }
                        }
                    }
                    .swipeActions {
                        Button("削除", role: .destructive) { deletion = record.id; confirmDelete = true }
                    }
                }
            }
            .navigationTitle("ダウンロード")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() } } }
            .confirmationDialog("保存ファイルと一覧を削除しますか？", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("削除", role: .destructive) { if let deletion { downloads.remove(deletion) } }
                Button("キャンセル", role: .cancel) {}
            } message: { Text("処理中のダウンロードは中断します。元に戻せません。共有先に保存したコピーは残ります。") }
        }
    }

    private func stateName(_ state: BrowserDownloadRecord.State) -> String {
        switch state {
        case .downloading: return "ダウンロード中"
        case .completed: return "保存完了"
        case .cancelled: return "キャンセル済み"
        case .failed: return "失敗・中断"
        }
    }
}

@available(iOS 17.0, *)
@MainActor
struct BrowserMonitorView: View {
    @ObservedObject var browser: RelayBrowserModel
    @ObservedObject var monitor: BrowserNetworkMonitor
    @Environment(\.dismiss) private var dismiss
    @State private var confirmClear = false

    var body: some View {
        NavigationStack {
            List {
                Section("このAppのSOCKS中継") {
                    LabeledContent("接続中 / 累計", value: "\(monitor.snapshot.active) / \(monitor.snapshot.total)")
                    LabeledContent("送信 / 受信", value: "\(bytes(monitor.snapshot.sent)) / \(bytes(monitor.snapshot.received))")
                    LabeledContent("エラー", value: "\(monitor.snapshot.errors)")
                    Text("TCPの転送量です。TLSの内容やURLのパスは記録しません。DoH・faviconの通信も含みます。")
                        .font(.caption).foregroundStyle(.secondary)
                    Button("接続を切断して記録をクリア", role: .destructive) { confirmClear = true }
                }
                Section("接続先（終了済みは最大200件）") {
                    ForEach(monitor.snapshot.connections) { row in
                        VStack(alignment: .leading, spacing: 4) {
                            Label(row.host.isEmpty ? "接続先未確定" : "\(row.host):\(row.port)", systemImage: row.isPrivate ? "eye.slash" : "network")
                                .font(.callout).textSelection(.enabled)
                            Text("\(row.state) · ↑\(bytes(row.sent)) ↓\(bytes(row.received))").font(.caption).foregroundStyle(.secondary)
                            Text("OSプロキシ: \(row.usedProxy.map { $0 ? "使用" : "未使用" } ?? "未確認") / 設定: \(row.proxyConfigured.map { $0 ? "あり" : "なし" } ?? "未確認")")
                                .font(.caption).foregroundStyle(.secondary)
                            if let transport = row.transport { Text("上流: \(transport)").font(.caption) }
                            if let endpoint = row.proxyEndpoint { Text("Proxy: \(endpoint)").font(.caption).textSelection(.enabled) }
                            if let error = row.error { Text(error).font(.caption).foregroundStyle(.red) }
                        }
                    }
                }
            }
            .navigationTitle("通信モニター")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完了") { dismiss() } } }
            .confirmationDialog("現在の接続も切断しますか？", isPresented: $confirmClear, titleVisibility: .visible) {
                Button("切断してクリア", role: .destructive) { browser.clearMonitor() }
                Button("キャンセル", role: .cancel) {}
            } message: { Text("読み込み中のページやダウンロードが中断する場合があります。必要なら再読み込みしてください。") }
        }
    }
}

private func bytes(_ count: Int64) -> String { ByteCountFormatter.string(fromByteCount: max(0, count), countStyle: .file) }

@available(iOS 17.0, *)
@MainActor
struct BrowserPINSettings: View {
    @ObservedObject var security: BrowserSecurity
    @Environment(\.scenePhase) private var scenePhase
    @State private var pin = ""
    @State private var confirmation = ""
    @State private var message = ""
    @State private var editingConfirmation = false

    private var selectedPIN: Binding<String> {
        Binding(get: { editingConfirmation ? confirmation : pin }, set: {
            if editingConfirmation { confirmation = $0 } else { pin = $0 }
        })
    }

    private func save() {
        if security.enabled {
            _ = security.disable(using: pin)
            pin = ""
            message = security.message
        } else if pin != confirmation {
            message = "PINが一致しません"
            confirmation = ""; editingConfirmation = true
        } else {
            if security.configure(pin) { pin = ""; confirmation = ""; editingConfirmation = false }
            message = security.message
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack(spacing: 13) {
                    Image(systemName: "lock.shield.fill")
                        .font(.system(size: 27, weight: .medium))
                        .foregroundStyle(.white)
                        .frame(width: 60, height: 60)
                        .background(Color(red: 0.20, green: 0.47, blue: 0.96).gradient, in: RoundedRectangle(cornerRadius: 19))
                    VStack(alignment: .leading, spacing: 4) {
                        Text("PINロック").font(.title2.bold())
                        Text("4桁のPINでブラウザを保護")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                    Spacer()
                }

                VStack(spacing: 12) {
                    BrowserPINEntry(label: security.enabled ? "現在のPIN（数字4桁）" : "新しいPIN（数字4桁）",
                                    pin: pin, active: !editingConfirmation) { editingConfirmation = false }
                    if !security.enabled {
                        BrowserPINEntry(label: "PINをもう一度入力", pin: confirmation, active: editingConfirmation) { editingConfirmation = true }
                    }
                }

                if !message.isEmpty {
                    Label(message, systemImage: "info.circle")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 4)
                }
                Text("有効にすると起動時とバックグラウンドからの復帰時にロックします。連続10回間違えると、全タブ・Cookie・サイトデータ・履歴・タブ復元情報・ダウンロード元URLを自動削除します。ブックマークと保存ファイルは残ります。削除は元に戻せません。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 5)
            }
            .frame(maxWidth: 620)
            .frame(maxWidth: .infinity)
            .padding(20)
        }
        .safeAreaInset(edge: .bottom) {
            BrowserPINPad(pin: selectedPIN, submitTitle: security.enabled ? "PINロックを無効にする" : "PINロックを有効にする",
                          enabled: BrowserSecurity.valid(pin) && (security.enabled || BrowserSecurity.valid(confirmation)) && !security.locked,
                          submit: save)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .frame(maxWidth: .infinity)
                .background(.ultraThinMaterial)
        }
        .background {
            LinearGradient(colors: [Color(red: 0.10, green: 0.17, blue: 0.30).opacity(0.55), Color(.systemBackground)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
        }
        .onChange(of: pin) { _, value in
            if !security.enabled, value.count == 4, confirmation.isEmpty { editingConfirmation = true }
        }
        .onChange(of: scenePhase) { _, phase in if phase != .active { pin = ""; confirmation = ""; editingConfirmation = false } }
        .onDisappear { pin = ""; confirmation = "" }
        .navigationTitle("PINロック")
    }

}

@available(iOS 17.0, *)
@MainActor
struct BrowserLockView: View {
    @ObservedObject var browser: RelayBrowserModel
    @ObservedObject var security: BrowserSecurity
    @Environment(\.scenePhase) private var scenePhase
    @State private var pin = ""

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 8) {
                ScrollView {
                    VStack(spacing: 12) {
                        Image(systemName: "lock.fill").font(.largeTitle).accessibilityHidden(true)
                        Text("SGBit ONEをロック中").font(.title2)
                        if !security.wipePending { BrowserPINEntry(label: "PIN（数字4桁）", pin: pin).frame(maxWidth: 320) }
                        Text(security.message).font(.callout).multilineTextAlignment(.center)
                        if security.wipePending {
                            if browser.isClearingData { ProgressView("サイトデータを削除中") }
                            else { Button("削除を再試行") { Task { await browser.performSecurityWipe() } } }
                        }
                    }.frame(maxWidth: .infinity)
                }
                if !security.wipePending {
                    BrowserPINPad(pin: $pin, submitTitle: "ロック解除", enabled: BrowserSecurity.valid(pin),
                                  keyHeight: min(60, max(48, (geometry.size.height - 180) / 5))) {
                        _ = security.unlock(pin); pin = ""
                    }
                }
            }.padding(12)
        }
        .onChange(of: scenePhase) { _, phase in if phase != .active { pin = "" } }
        .onDisappear { pin = "" }
        .background(.background).privacySensitive()
    }
}
