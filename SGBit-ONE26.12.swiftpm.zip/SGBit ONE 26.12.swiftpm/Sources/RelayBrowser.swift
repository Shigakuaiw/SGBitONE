import SwiftUI

@main
struct BitBrowserApp: App {
    var body: some Scene {
        WindowGroup {
            if #available(iOS 17.0, *) {
                ContentView()
            } else {
                Text("iOS / iPadOS 17以降が必要です")
            }
        }
    }
}
