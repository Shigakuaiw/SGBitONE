import Foundation

struct RelayConnectionSnapshot: Identifiable, Sendable {
    let id: UUID
    var started = Date()
    var host = ""
    var port: UInt16 = 0
    var state = "認証中"
    var sent: Int64 = 0
    var received: Int64 = 0
    var closed = false
    var error: String?
    var isPrivate = false
    var proxyConfigured: Bool?
    var usedProxy: Bool?
    var proxyEndpoint: String?
    var transport: String?
}

struct RelayMonitorSnapshot: Sendable {
    var connections: [RelayConnectionSnapshot]
    var active: Int
    var total: Int
    var sent: Int64
    var received: Int64
    var errors: Int
}

#if canImport(Combine)
import Combine

@MainActor
final class BrowserNetworkMonitor: ObservableObject {
    @Published private(set) var snapshot = RelayMonitorSnapshot(connections: [], active: 0, total: 0, sent: 0, received: 0, errors: 0)
    func update(_ value: RelayMonitorSnapshot) { snapshot = value }
    func hidePrivateRecords() { snapshot.connections.removeAll(where: \.isPrivate) }
    func clear() { snapshot = .init(connections: [], active: 0, total: 0, sent: 0, received: 0, errors: 0) }
}
#endif
