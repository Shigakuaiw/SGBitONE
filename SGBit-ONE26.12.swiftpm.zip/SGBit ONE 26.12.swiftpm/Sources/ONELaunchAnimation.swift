import SwiftUI

/// A brief, non-interactive launch animation. Never bypasses ONEAppLock.
@available(iOS 17.0, *)
struct ONELaunchAnimation: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var appeared = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.025, green: 0.07, blue: 0.16),
                         Color(red: 0.045, green: 0.18, blue: 0.31),
                         Color(red: 0.01, green: 0.04, blue: 0.12)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            Circle()
                .fill(Color.cyan.opacity(0.18))
                .frame(width: 300, height: 300)
                .blur(radius: 80)
                .offset(x: 100, y: -140)
                .accessibilityHidden(true)

            VStack(spacing: 20) {
                Image(systemName: "square.stack.3d.up.fill")
                    .font(.system(size: 66, weight: .ultraLight))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(.white, .cyan)
                    .frame(width: 118, height: 118)
                    .background(.white.opacity(0.11), in: RoundedRectangle(cornerRadius: 30))
                    .overlay {
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(.white.opacity(0.22), lineWidth: 1)
                    }
                Text("SGBit ONE")
                    .font(.system(size: 34, weight: .semibold, design: .rounded))
                    .tracking(1.1)
                Text("26.12")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.white.opacity(0.65))
            }
            .foregroundStyle(.white)
            .scaleEffect(reduceMotion ? 1 : (appeared ? 1 : 0.88))
            .opacity(appeared ? 1 : 0)
        }
        .onAppear {
            if reduceMotion { appeared = true }
            else {
                withAnimation(.spring(response: 0.62, dampingFraction: 0.82)) {
                    appeared = true
                }
            }
        }
        .accessibilityElement(children: .combine)
        .accessibilityLabel("SGBit ONE を起動しています")
    }
}
