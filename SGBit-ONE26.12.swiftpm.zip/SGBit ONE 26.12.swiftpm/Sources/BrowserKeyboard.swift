import SwiftUI
import UIKit

enum BrowserKeyboardTarget: String { case address = "URL欄", page = "ページ内", none = "入力欄をタップしてください" }

@MainActor
struct BrowserKeyboardPanel: View {
    @EnvironmentObject private var preferences: BrowserPreferences
    let target: BrowserKeyboardTarget
    let contextID: Int
    let status: String
    let secure: Bool
    let send: (String, String, @escaping (Bool) -> Void) -> Void
    let close: () -> Void
    var keyboardSize: BrowserKeyboardSize = .minimum
    var fixedTargetLabel: String? = nil
    @StateObject private var composition = BrowserComposition()
    private var japanese: Bool { preferences.japaneseInput }
    @State private var shiftState = BrowserShiftState()
    @State private var caps = false
    @State private var selectedCandidate = 0
    @State private var modeIndicatorVisible = false
    @State private var committing = false
    @State private var localMessage = ""

    private func command(_ operation: String, _ text: String = "") { send(operation, text) { _ in } }
    private func type(_ value: String) {
        if japanese || !composition.text.isEmpty {
            if !composition.insert(value, roman: japanese) { localMessage = "未確定は128文字まで。先に確定してください" }
        } else { command("insert", value) }
        shiftState.didType()
    }
    private func edit(_ operation: String) {
        if composition.text.isEmpty { command(operation) } else { composition.edit(operation) }
    }
    private func commit(_ value: String) {
        guard !value.isEmpty else { return }
        committing = true
        send("insert", value) { success in
            committing = false
            if success { composition.clear() }
            else { localMessage = "確定できませんでした。入力先を確認してください" }
        }
    }
    private func toggleMode() {
        preferences.japaneseInput.toggle()
    }
    private func convert() {
        if !composition.choosingCandidate || composition.candidates.isEmpty { composition.convert() }
        else if !composition.converting { selectedCandidate = (selectedCandidate + 1) % composition.candidates.count }
    }
    private func press(_ value: String) {
        localMessage = ""
        if value != "shift" { shiftState.interruptTapSequence() }
        switch value {
        case "shift": shiftState.tap(at: Date.timeIntervalSinceReferenceDate)
        case "halfFull": toggleMode()
        case "caps": caps.toggle()
        case "delete", "left", "right": edit(value)
        case "enter":
            if composition.text.isEmpty {
                command(shiftState.active ? "lineBreak" : "enter")
                shiftState.didType()
            }
            else if !composition.choosingCandidate {
                composition.finishReading()
                commit(composition.text)
            } else if !composition.converting {
                composition.finishReading()
                let index = selectedCandidate
                commit(index < composition.candidates.count ? composition.candidates[index] : composition.text)
            }
        case "space":
            if composition.text.isEmpty { command("insert", " ") } else { convert() }
        // shortcut: Tab inserts a tab character; field navigation needs a separate page operation.
        case "tab": type("\t")
        case "selectAll": command("selectAll")
        case "paste":
            if let value = UIPasteboard.general.string {
                if !composition.text.isEmpty {
                    if !composition.insert(value, roman: false) { localMessage = "未確定は128文字まで。先に確定してください" }
                } else if value.utf16.count <= 8192 { command("insert", value) }
                else { localMessage = "貼り付けは8192文字までです" }
            }
        default:
            let letter = value.first?.isLetter == true
            type(BrowserKeyboardLayout.label(value, upper: letter ? shiftState.active != caps : shiftState.active))
        }
    }
    private func keyTitle(_ value: String) -> String {
        switch value {
        case "delete": return "⌫"
        case "tab": return "⇥"
        case "caps": return caps ? "⇪ ●" : "⇪"
        case "shift": return shiftState.locked ? "⇧ 固定" : shiftState.active ? "⇧ ●" : "⇧"
        case "halfFull": return "半角\n全角"
        case "enter": return composition.text.isEmpty ? (shiftState.active ? "改行 ↵" : "↵") : "確定 ↵"
        case "space": return composition.text.isEmpty ? "Space" : "変換"
        case "left": return "←"
        case "right": return "→"
        case "paste": return "貼付"
        case "selectAll": return "全選択"
        default: return BrowserKeyboardLayout.label(value, upper: value.first?.isLetter == true ? shiftState.active != caps : shiftState.active)
        }
    }
    private func accessibility(_ value: String) -> String {
        switch value {
        case "delete": return "Backspace 一文字削除"
        case "shift": return shiftState.locked ? "Shift固定中、タップで解除" : "Shift、2回続けてタップで固定"
        case "halfFull": return "半角全角、日本語とABCを切り替え"
        case "caps": return "Caps Lock"
        case "tab": return "タブ文字を挿入"
        case "enter": return composition.text.isEmpty ? (shiftState.active ? "Shift Enter、改行" : "Enter、送信キーを通知") : "未確定の入力を確定"
        case "space": return composition.text.isEmpty ? "スペース" : "漢字変換候補"
        case "left": return "カーソルを左へ"
        case "right": return "カーソルを右へ"
        default: return keyTitle(value)
        }
    }


    var body: some View {
        GeometryReader { geometry in
            panelContent(size: geometry.size)
        }
        .overlay { modeIndicator }
        .task(id: japanese) {
            modeIndicatorVisible = true
            do { try await Task.sleep(nanoseconds: 750_000_000) } catch { return }
            guard !Task.isCancelled else { return }
            modeIndicatorVisible = false
        }
        .onChange(of: composition.candidates) { _, _ in selectedCandidate = 0 }
        .onChange(of: target) { _, _ in composition.clear(); localMessage = "" }
        .onChange(of: contextID) { _, _ in if target == .page { composition.clear(); localMessage = "" } }
        .onDisappear { composition.clear() }
        .onChange(of: japanese) { _, _ in shiftState = BrowserShiftState(); caps = false; localMessage = "" }
    }

    @ViewBuilder
    private var modeIndicator: some View {
        if modeIndicatorVisible {
            Text(japanese ? "あ" : "A")
                .font(.system(size: 46, weight: .medium))
                .foregroundStyle(Color.white)
                .frame(width: 84, height: 84)
                .background(Color.black.opacity(0.72))
                .allowsHitTesting(false).accessibilityHidden(true)
        }
    }

    // Separate opaque return types bound SwiftUI type inference in Playgrounds.
    private func panelContent(size: CGSize) -> some View {
        let gap: CGFloat = BrowserKeyboardLayout.gap
        let headerHeight: CGFloat = 3 * 28
        let rowHeight: CGFloat = max(0, (size.height - 12 - headerHeight - 7 * gap) / 5)
        let rowWidth: CGFloat = max(0, size.width - 12)
        return VStack(spacing: gap) {
            targetRow
            compositionRow
            candidateRow
            ForEach(BrowserKeyboardLayout.rows.indices, id: \.self) { index in
                keyRow(BrowserKeyboardLayout.rows[index], width: rowWidth, height: rowHeight)
                    .disabled(target == .none)
            }
        }
        .buttonStyle(.plain)
        .foregroundStyle(.white)
        .padding(10)
        .background {
            keyboardBackground
        }
        .disabled(committing).privacySensitive()
    }

    private var targetRow: some View {
        HStack(spacing: BrowserKeyboardLayout.gap) {
            Text("入力先：\(fixedTargetLabel ?? target.rawValue)")
                .font(.caption).lineLimit(1).frame(maxWidth: 190, alignment: .leading)
            Spacer(minLength: 0)
            modeButton
            Button(action: close) {
                Image(systemName: "keyboard.chevron.compact.down").frame(width: 32)
            }.accessibilityLabel("アプリ内キーボードを閉じる")
        }
        .padding(.horizontal, 8)
        .frame(height: 28)
    }

    private var modeButton: some View {
        let title: String = japanese ? "日本語" : "ABC"
        let mode: String = japanese ? "日本語ローマ字" : "ABC"
        return Button(title) {
            toggleMode()
        }.accessibilityLabel("入力モード: \(mode)、タップで切り替え")
    }

    private var compositionDisplay: String {
        if !localMessage.isEmpty { return localMessage }
        if !composition.conversionMessage.isEmpty { return composition.conversionMessage }
        if composition.text.isEmpty { return status }
        if secure { return String(repeating: "●", count: composition.text.count) }
        let before = String(composition.text.prefix(composition.cursor))
        let after = String(composition.text.dropFirst(composition.cursor))
        return before + "│" + after
    }

    private var compositionAccessibility: String {
        if !localMessage.isEmpty { return localMessage }
        if !composition.conversionMessage.isEmpty { return composition.conversionMessage }
        if secure { return "未確定のパスワード \(composition.text.count)文字" }
        if composition.text.isEmpty { return status }
        return "未確定: \(composition.text)"
    }

    private var compositionRow: some View {
        HStack(spacing: BrowserKeyboardLayout.gap) {
            Text(compositionDisplay)
                .lineLimit(1).truncationMode(.middle)
                .frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityLabel(compositionAccessibility)
            Button("消去") { composition.clear(); localMessage = "" }
                .disabled(composition.text.isEmpty)
        }
        .font(.caption)
        .padding(.horizontal, 10)
        .background(Color.white.opacity(0.07), in: Capsule())
        .frame(height: 28)
    }

    private var candidateRow: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: true) {
                HStack(spacing: 12) {
                    if composition.candidates.isEmpty { candidatePlaceholder }
                    ForEach(Array(composition.candidates.enumerated()), id: \.offset) { item in
                        candidateButton(index: item.offset, value: item.element, highlighted: item.offset == selectedCandidate && composition.choosingCandidate)
                            .id(item.offset)
                    }
                }
            }
            .onChange(of: selectedCandidate) { _, index in proxy.scrollTo(index, anchor: .center) }
            .onChange(of: composition.candidates) { _, _ in proxy.scrollTo(0, anchor: .leading) }
        }.frame(height: 28)
    }

    private func candidateButton(index: Int, value: String, highlighted: Bool) -> some View {
        let reading = composition.text
        let title: String = secure ? "候補 \(index + 1)" : value
        let color: Color = highlighted ? Color.cyan : Color.white
        return Button {
            guard composition.text == reading, composition.candidates.indices.contains(index), composition.candidates[index] == value else { return }
            commit(value)
        } label: {
            Text(title).font(.callout).lineLimit(1).fixedSize(horizontal: true, vertical: false)
                .padding(.horizontal, 6).frame(height: 28)
        }.foregroundStyle(color).accessibilityAddTraits(highlighted ? .isSelected : [])
    }

    private var candidatePlaceholder: some View {
        let title = composition.converting ? "辞書を検索中…" : japanese ? "入力すると変換候補を表示" : "JIS QWERTY"
        return Text(title).font(.caption2).foregroundStyle(.white.opacity(0.65)).frame(height: 28)
    }

    private func keyRow(_ row: [BrowserKeyboardKey], width: CGFloat, height: CGFloat) -> some View {
        let side: CGFloat? = keyboardSize == .standard ? height : nil
        let widths: [CGFloat] = BrowserKeyboardLayout.widths(for: row, available: width, squareSide: side)
        return HStack(spacing: BrowserKeyboardLayout.gap) {
            ForEach(row.indices, id: \.self) { index in
                keyButton(row[index], width: widths[index], height: height)
            }
        }.frame(height: height)
            .zIndex(row.contains(where: { $0.value == "enter" }) ? 1 : 0)
    }

    @ViewBuilder
    private func keyButton(_ key: BrowserKeyboardKey, width: CGFloat, height: CGFloat) -> some View {
        if key.value == "enterTail" {
            Color.clear.frame(width: width, height: height).allowsHitTesting(false).accessibilityHidden(true)
        } else if key.value == "enter" {
            Color.clear.frame(width: width, height: height)
                .overlay(alignment: .topTrailing) { enterButton(width: width, rowHeight: height) }
        } else {
            Button { press(key.value) } label: {
                keyFace(key.value, width: width, height: height)
            }
            .disabled(key.value == "selectAll" && !composition.text.isEmpty)
            .accessibilityLabel(accessibility(key.value))
        }
    }

    private func enterButton(width: CGFloat, rowHeight: CGFloat) -> some View {
        let inset: CGFloat = keyboardSize == .standard ? (rowHeight + BrowserKeyboardLayout.gap) / 4 : width / 6
        let shape = BrowserJISEnterShape(shoulder: rowHeight + BrowserKeyboardLayout.gap, inset: inset)
        let height: CGFloat = rowHeight * 2 + BrowserKeyboardLayout.gap
        return Button { press("enter") } label: {
            Text(keyTitle("enter")).font(.system(size: min(17, max(11, rowHeight * 0.4))))
                .lineLimit(1).minimumScaleFactor(0.5).padding(.leading, inset)
                .frame(width: width, height: height)
                .background(Color.cyan.opacity(0.30), in: shape)
                .overlay(shape.stroke(Color.white.opacity(0.20), lineWidth: 0.7))
                .contentShape(shape)
        }.accessibilityLabel(accessibility("enter"))
    }

    // Only the in-app keyboard is customisable. iPadOS's system keyboard
    // and the keyboard presented by WKWebView remain controlled by iPadOS.
    @ViewBuilder
    private var keyboardBackground: some View {
        let shape = RoundedRectangle(cornerRadius: 22, style: .continuous)
        if #available(iOS 26.0, *) {
            shape.fill(Color(red: 0.07, green: 0.09, blue: 0.13).opacity(0.9))
                .glassEffect(.regular, in: shape)
        } else {
            shape.fill(.ultraThinMaterial)
                .overlay(shape.fill(Color.black.opacity(0.73)))
        }
    }

    @ViewBuilder
    private func keyBackground(for value: String) -> some View {
        let shape = RoundedRectangle(cornerRadius: 11, style: .continuous)
        let isSpecial = ["shift", "caps", "delete", "halfFull", "paste", "selectAll", "left", "right", "tab"].contains(value)
        let tint = isSpecial ? Color(red: 0.19, green: 0.25, blue: 0.34) : Color(red: 0.25, green: 0.29, blue: 0.36)
        if #available(iOS 26.0, *) {
            shape.fill(tint.opacity(0.60))
                .glassEffect(.regular, in: shape)
                .overlay(shape.stroke(Color.white.opacity(0.19), lineWidth: 0.5))
        } else {
            shape.fill(tint.opacity(0.86))
                .overlay(shape.stroke(Color.white.opacity(0.16), lineWidth: 0.5))
        }
    }

    private func keyFace(_ value: String, width: CGFloat, height: CGFloat) -> some View {
        let fontSize: CGFloat = min(17, max(11, height * 0.4))
        return Text(keyTitle(value)).font(.system(size: fontSize))
            .lineLimit(value == "halfFull" ? 2 : 1).minimumScaleFactor(0.5)
            .frame(width: width, height: height)
            .background {
                keyBackground(for: value)
            }
            .contentShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
    }
}

private struct BrowserJISEnterShape: Shape {
    let shoulder: CGFloat
    let inset: CGFloat
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addLines([
            CGPoint(x: 0, y: 0), CGPoint(x: rect.width, y: 0),
            CGPoint(x: rect.width, y: rect.height), CGPoint(x: inset, y: rect.height),
            CGPoint(x: inset, y: shoulder), CGPoint(x: 0, y: shoulder)
        ])
        path.closeSubpath()
        return path
    }
}
