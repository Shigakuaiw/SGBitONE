import SwiftUI
import WebKit

// Bit Browser 2.0: adaptive navigation. Existing feature implementations remain unchanged.
@available(iOS 17.0, *)
private enum HubSection: String, CaseIterable, Identifiable {
    case home = "ホーム"
    case ai = "AI（チャッピー）"
    case apps = "アプリ"
    case browser = "ブラウザ"
    case music = "SGBit Music"
    case recognition = "音楽認識"
    case files = "ファイル"
    case passwords = "パスワード"
    case settings = "設定"
    case remote = "RDP"

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .home: return "square.grid.3x3.fill"
        case .ai: return "sparkles"
        case .apps: return "square.grid.2x2.fill"
        case .browser: return "globe"
        case .music: return "music.note.list"
        case .recognition: return "waveform"
        case .files: return "folder"
        case .passwords: return "key.fill"
        case .settings: return "gearshape.fill"
        case .remote: return "desktopcomputer"
        }
    }
}

@available(iOS 17.0, *)
struct ContentView: View {
    // Deep blue accent inspired by Apple's sidebar design.
    @AppStorage("bb.theme.accent") private var accentName = "blue"
    @AppStorage("bb.theme.dark") private var darkTheme = false
    @AppStorage("sgbit.theme.automatic") private var automaticTheme = false
    @Environment(\.colorScheme) private var systemColorScheme
    @AppStorage("bb.theme.opacity") private var panelOpacity = 0.94
    @AppStorage("bb.theme.corner") private var cornerRadius = 21.0
    private var accentBlue: Color { BitTheme.color(accentName) }
    private var selectedBlue: Color { darkTheme ? accentBlue.opacity(0.52) : accentBlue }
    private var sidebarTextColor: Color { darkTheme ? .white : Color(red: 0.12, green: 0.16, blue: 0.23) }
    private var sidebarBackground: Color { (darkTheme ? Color(red: 0.075, green: 0.088, blue: 0.12) : Color(red: 0.91, green: 0.93, blue: 0.97)).opacity(panelOpacity) }
    @Environment(\.horizontalSizeClass) private var sizeClass
    @State private var selection: HubSection = .home
    @State private var sidebarVisible = true
    @StateObject private var browser = RelayBrowserModel()
    @StateObject private var aiSession = ChappyWebSession()
    @StateObject private var appLock = ONEAppLock()
    @Environment(\.scenePhase) private var scenePhase
    @State private var showingLaunchAnimation = true
    @AppStorage("sgbit.setup.complete") private var setupComplete = false
    @ObservedObject private var oneAccount = ONEAccount.shared
    @State private var launchRecorded = false

    var body: some View {
        ZStack {
            Group {
                if sizeClass == .regular { tabletLayout }
                else { phoneLayout }
            }
            if setupComplete && appLock.unlocked && !showingLaunchAnimation {
                ONEControlCenterOverlay(
                    openHome: { selection = .home },
                    openBrowser: { selection = .browser },
                    openSettings: { selection = .settings },
                    lockApp: { appLock.lock() }
                )
                .zIndex(850)
            }
            if !setupComplete {
                ONESetupView(browserPreferences: browser.preferences).zIndex(3000)
            }
            if setupComplete && oneAccount.blocked {
                VStack(spacing: 8) {
                    Label("このアカウントのオンライン機能は制限されています", systemImage: "person.crop.circle.badge.xmark")
                    Text("保存済みの音楽・ファイルは利用できます").font(.caption)
                }
                .padding(12).frame(maxWidth: .infinity)
                .background(.orange.opacity(0.2))
                .frame(maxHeight: .infinity, alignment: .top)
                .zIndex(400)
            }
            if setupComplete && !appLock.unlocked {
                ONELockScreen(lock: appLock)
                    .zIndex(1000)
            }
            if setupComplete && showingLaunchAnimation {
                ONELaunchAnimation()
                    .transition(.opacity)
                    .zIndex(2000)
            }
        }
        .task {
            await oneAccount.refresh()
            if oneAccount.signedIn && !oneAccount.blocked && !launchRecorded { await oneAccount.recordLaunch(); launchRecorded = true }
            // The splash is only cosmetic; the lock screen remains underneath it.
            try? await Task.sleep(for: .milliseconds(950))
            withAnimation(.easeInOut(duration: 0.42)) {
                showingLaunchAnimation = false
            }
        }
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .background { appLock.lock(); ONEPasswordStore.shared.lock(); launchRecorded = false }
            if newPhase == .active { Task { await oneAccount.refresh(); if oneAccount.signedIn && !oneAccount.blocked && !launchRecorded { await oneAccount.recordLaunch(); launchRecorded = true } } }
        }
        .onChange(of: setupComplete) { _, done in if done { Task { await oneAccount.recordLaunch(); launchRecorded = true } } }
        .tint(accentBlue)
        .preferredColorScheme(automaticTheme ? nil : (darkTheme ? .dark : .light))
        .onChange(of: systemColorScheme) { _, newValue in
            if automaticTheme { darkTheme = (newValue == .dark) }
        }
    }

    private var phoneLayout: some View {
        TabView(selection: $selection) {
            finderHome
                .tabItem { Label("ホーム", systemImage: "square.grid.3x3.fill") }
                .tag(HubSection.home)
            ChappyAIView(session: aiSession)
                .tabItem { Label("チャッピー", systemImage: "sparkles") }
                .tag(HubSection.ai)
            ONEAppsScreen(openChappy: { selection = .ai }, openWebsite: { url in
                browser.open(url)
                selection = .browser
            })
                .tabItem { Label("アプリ", systemImage: "square.grid.2x2.fill") }
                .tag(HubSection.apps)
            RelayBrowserHome(browser: browser)
                .tabItem { Label("ブラウザ", systemImage: "globe") }
                .tag(HubSection.browser)
            MusicScreen()
                .tabItem { Label("SGBit Music", systemImage: "music.note") }
                .tag(HubSection.music)
            RecognitionScreen()
                .tabItem { Label("音楽認識", systemImage: "waveform") }
                .tag(HubSection.recognition)
            FilesScreen()
                .tabItem { Label("ファイル", systemImage: "folder") }
                .tag(HubSection.files)
            PasswordVaultView()
                .tabItem { Label("パスワード", systemImage: "key.fill") }
                .tag(HubSection.passwords)
            RemoteDesktopScreen()
                .tabItem { Label("RDP", systemImage: "desktopcomputer") }
                .tag(HubSection.remote)
            BrowserSettings(browser: browser, onDone: { selection = .home })
                .environmentObject(browser.preferences)
                .environmentObject(browser.security)
                .tabItem { Label("設定", systemImage: "gearshape.fill") }
                .tag(HubSection.settings)
        }
    }

    // Finder-style launcher. Sidebar navigation and existing screens stay intact.
    private var finderHome: some View {
        GeometryReader { geometry in
            let columns = [GridItem(.adaptive(minimum: geometry.size.width < 500 ? 110 : 145), spacing: 22)]
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 7) {
                        Text("SGBit ONE 26.11")
                            .font(.largeTitle.bold())
                            .shadow(color: .black.opacity(0.45), radius: 10)
                        Text("機能を選択")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.top, 22)
                    .padding(12)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
                    Button { appLock.lock() } label: {
                        Label("SGBit ONEをロック", systemImage: "lock.fill")
                            .font(.subheadline.weight(.medium))
                    }
                    .buttonStyle(.bordered)
                    LazyVGrid(columns: columns, alignment: .leading, spacing: 28) {
                        ForEach(HubSection.allCases.filter { $0 != .home }) { section in
                            Button {
                                selection = section
                            } label: {
                                VStack(spacing: 11) {
                                    Image(systemName: section.symbol)
                                        .font(.system(size: 36, weight: .medium))
                                        .foregroundStyle(.white)
                                        .frame(width: 86, height: 86)
                                        .background(
                                            LinearGradient(
                                                colors: [accentBlue.opacity(0.98), accentBlue.opacity(0.48)],
                                                startPoint: .topLeading, endPoint: .bottomTrailing
                                            ),
                                            in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                                        )
                                        .shadow(color: accentBlue.opacity(0.20), radius: 10, y: 5)
                                    Text(section.rawValue)
                                        .font(.system(size: 13, weight: .medium))
                                        .foregroundStyle(.primary)
                                        .lineLimit(2)
                                        .multilineTextAlignment(.center)
                                }
                                .frame(maxWidth: .infinity)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("\(section.rawValue)を開く")
                        }
                    }
                }
                .padding(.horizontal, 26)
                .padding(.bottom, 30)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background { ONEWallpaperBackground(area: .home) }
        }
    }

    // The entire row (including empty space) is a single large hit target.
    // Keep all gestures off the row container; each row owns its own action.
    private func sidebarRow(for section: HubSection) -> some View {
        let isSelected = selection == section
        return Button(action: {
            selection = section
        }) {
            HStack(spacing: 14) {
                Image(systemName: section.symbol)
                    .font(.system(size: 19, weight: .medium))
                    .foregroundStyle(isSelected ? Color.white : accentBlue)
                    .frame(width: 26, height: 30)
                Text(section.rawValue)
                    .font(.system(size: 16, weight: isSelected ? .semibold : .regular))
                    .lineLimit(1)
                Spacer(minLength: 0)
            }
            .foregroundStyle(isSelected ? Color.white : sidebarTextColor)
            .symbolRenderingMode(.hierarchical)
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity, minHeight: 56, alignment: .leading)
            .background {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(isSelected ? selectedBlue : Color.clear)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity, minHeight: 56)
        .contentShape(Rectangle())
        .accessibilityLabel(section.rawValue)
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }

    // Keep the sidebar toggle outside all conditional branches and above the
    // browser/web view, so mouse clicks and touch gestures hit the same control.
    private var tabletLayout: some View {
        HStack(spacing: 0) {
            if sidebarVisible {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Button { selection = .home } label: {
                            Text("SGBit ONE 26.11")
                                .font(.headline)
                                .foregroundStyle(sidebarTextColor)
                        }
                        .buttonStyle(.plain)
                        .padding(.leading, 46)
                        Spacer()
                    }
                    .frame(height: 52)
                    .padding(.horizontal, 12)

                    ScrollView {
                        LazyVStack(spacing: 6) {
                            ForEach(HubSection.allCases.filter { $0 != .settings && $0 != .home }) { section in
                                sidebarRow(for: section)
                            }
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                    }
                    .scrollIndicators(.hidden)

                    Spacer(minLength: 0)
                    Divider()
                        .overlay(sidebarTextColor.opacity(0.12))
                        .padding(.horizontal, 14)
                    sidebarRow(for: .settings)
                        .padding(.horizontal, 10)
                        .padding(.bottom, 12)
                }
                .frame(width: 216)
                .background(sidebarBackground)
                Divider()
            }
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    // Always clickable in the desktop/tablet layout, even with sidebar closed.
                    Button { selection = .home } label: {
                        Label("ホーム", systemImage: "house.fill")
                    }
                    .buttonStyle(.bordered)
                    Spacer(minLength: 8)
                    Text(selection.rawValue).font(.subheadline.weight(.semibold))
                    Spacer(minLength: 8)
                    Button { appLock.lock() } label: {
                        Image(systemName: "lock.fill")
                    }
                    .buttonStyle(.bordered)
                    .accessibilityLabel("SGBit ONEをロック")
                }
                .padding(.leading, 56)
                .padding(.trailing, 12)
                .frame(height: 52)
                .background(Color(uiColor: .secondarySystemBackground))
                Group {
                    switch selection {
                    case .home: finderHome
                    case .ai: ChappyAIView(session: aiSession)
                    case .apps: ONEAppsScreen(openChappy: { selection = .ai }, openWebsite: { url in
                        browser.open(url)
                        selection = .browser
                    })
                    case .browser: RelayBrowserHome(browser: browser)
                    case .music: MusicScreen()
                    case .recognition: RecognitionScreen()
                    case .files: FilesScreen()
                    case .passwords: PasswordVaultView()
                    case .remote: RemoteDesktopScreen()
                    case .settings:
                        BrowserSettings(browser: browser, onDone: { selection = .browser })
                            .environmentObject(browser.preferences)
                            .environmentObject(browser.security)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(Color(uiColor: .systemBackground))
        .overlay(alignment: .topLeading) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    sidebarVisible.toggle()
                }
            } label: {
                Image(systemName: sidebarVisible ? "sidebar.left" : "sidebar.right")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundStyle(accentBlue)
                    .frame(width: 44, height: 44)
                    .background(Color(uiColor: .tertiarySystemBackground),
                                in: RoundedRectangle(cornerRadius: 12))
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel(sidebarVisible ? "サイドバーを閉じる" : "サイドバーを開く")
            .padding(.leading, 8)
            .padding(.top, 4)
            .zIndex(100)
        }
    }
}
