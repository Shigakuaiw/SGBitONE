import Foundation

struct BrowserRomanDraft {
    private var characters: [Character] = []
    private var position = 0
    private var pending = ""
    private var doubledN = false
    private var visiblePending: String { doubledN ? "" : pending }
    var text: String { String(characters.prefix(position)) + visiblePending + String(characters.dropFirst(position)) }
    var cursor: Int { position + visiblePending.count }

    private static let syllables = """
    a あ i い u う e え o お
    ka か ki き ku く ke け ko こ ga が gi ぎ gu ぐ ge げ go ご
    sa さ si し shi し su す se せ so そ za ざ zi じ ji じ zu ず ze ぜ zo ぞ
    ta た ti ち chi ち tu つ tsu つ te て to と da だ di ぢ du づ de で do ど
    na な ni に nu ぬ ne ね no の ha は hi ひ hu ふ fu ふ he へ ho ほ
    ba ば bi び bu ぶ be べ bo ぼ pa ぱ pi ぴ pu ぷ pe ぺ po ぽ
    ma ま mi み mu む me め mo も ya や yu ゆ yo よ ra ら ri り ru る re れ ro ろ wa わ wo を wi うぃ we うぇ wu う
    kya きゃ kyi きぃ kyu きゅ kye きぇ kyo きょ gya ぎゃ gyi ぎぃ gyu ぎゅ gye ぎぇ gyo ぎょ
    sya しゃ syi しぃ syu しゅ sye しぇ syo しょ sha しゃ shu しゅ she しぇ sho しょ
    zya じゃ zyi じぃ zyu じゅ zye じぇ zyo じょ ja じゃ ju じゅ je じぇ jo じょ jya じゃ jyu じゅ jyo じょ
    tya ちゃ tyi ちぃ tyu ちゅ tye ちぇ tyo ちょ cha ちゃ chu ちゅ che ちぇ cho ちょ cya ちゃ cyu ちゅ cyo ちょ
    dya ぢゃ dyu ぢゅ dyo ぢょ nya にゃ nyi にぃ nyu にゅ nye にぇ nyo にょ
    hya ひゃ hyu ひゅ hyo ひょ bya びゃ byu びゅ byo びょ pya ぴゃ pyu ぴゅ pyo ぴょ
    mya みゃ myu みゅ myo みょ rya りゃ ryu りゅ ryo りょ
    fa ふぁ fi ふぃ fe ふぇ fo ふぉ fya ふゃ fyu ふゅ fyo ふょ
    va ゔぁ vi ゔぃ vu ゔ ve ゔぇ vo ゔぉ vya ゔゃ vyu ゔゅ vyo ゔょ
    tsa つぁ tsi つぃ tse つぇ tso つぉ thi てぃ thu てゅ the てぇ tho てょ dhi でぃ dhu でゅ dhe でぇ dho でょ
    kwa くぁ kwi くぃ kwu くぅ kwe くぇ kwo くぉ qa くぁ qi くぃ qu く qe くぇ qo くぉ gwa ぐぁ
    xa ぁ xi ぃ xu ぅ xe ぇ xo ぉ la ぁ li ぃ lu ぅ le ぇ lo ぉ
    xya ゃ xyu ゅ xyo ょ lya ゃ lyu ゅ lyo ょ xtu っ xtsu っ ltu っ ltsu っ xwa ゎ lwa ゎ xka ゕ xke ゖ lka ゕ lke ゖ
    xn ん n' ん ye いぇ tcha っちゃ tchi っち tchu っちゅ tche っちぇ tcho っちょ
    """
    private static let kana: [String: String] = {
        let words = syllables.split(whereSeparator: \.isWhitespace).map(String.init)
        precondition(words.count.isMultiple(of: 2))
        return Dictionary(uniqueKeysWithValues: stride(from: 0, to: words.count, by: 2).map { (words[$0], words[$0 + 1]) })
    }()
    private static let prefixes = Set(kana.keys.flatMap { word in (1..<word.count).map { String(word.prefix($0)) } })

    @discardableResult
    mutating func insert(_ value: String, roman: Bool = true) -> Bool {
        guard value.count <= 512 else { return false }
        var next = self
        if !roman { next.finishReading() }
        for character in roman ? value.lowercased() : value {
            if roman { next.type(character) } else { next.emit(String(character)) }
            guard next.text.count <= 128 else { return false }
        }
        self = next
        return true
    }

    private mutating func emit(_ value: String) {
        characters.insert(contentsOf: value, at: position)
        position += value.count
    }

    private mutating func type(_ character: Character) {
        if doubledN {
            doubledN = false
            if character == "'" { pending = ""; return }
            if !"aeiouyn".contains(character) { pending = "" }
        }
        if !(character.isASCII && character.isLetter) && character != "'" {
            finishReading()
            emit(["-": "ー", ",": "、", ".": "。", "[": "「", "]": "」"][String(character)] ?? String(character))
            return
        }
        pending.append(character)
        while !pending.isEmpty {
            if pending == "nn" { emit("ん"); pending = "n"; doubledN = true; return }
            if let value = Self.kana[pending] { emit(value); pending = ""; return }
            if Self.prefixes.contains(pending) { return }
            let letters = Array(pending)
            if letters.count > 1, letters[0] == "n", !"aeiouy'".contains(letters[1]) {
                emit("ん"); pending.removeFirst()
            } else if letters.count > 1, letters[0] == letters[1], !"aeioun".contains(letters[0]) {
                emit("っ"); pending.removeFirst()
            } else { emit(String(pending.removeFirst())) }
        }
    }

    mutating func finishReading() {
        if !doubledN { emit(pending == "n" ? "ん" : pending) }
        pending = ""; doubledN = false
    }

    mutating func edit(_ operation: String) {
        if operation == "delete", !pending.isEmpty {
            if doubledN {
                pending = ""; doubledN = false
                if position > 0 { characters.remove(at: position - 1); position -= 1 }
            } else { pending.removeLast() }
            return
        }
        finishReading()
        switch operation {
        case "delete": if position > 0 { characters.remove(at: position - 1); position -= 1 }
        case "left": position = max(0, position - 1)
        case "right": position = min(characters.count, position + 1)
        default: break
        }
    }
}

#if canImport(Combine)
import Combine

@MainActor
final class BrowserComposition: ObservableObject {
    @Published private var draft = BrowserRomanDraft()
    @Published private(set) var candidates: [String] = []
    @Published private(set) var converting = false
    @Published private(set) var conversionMessage = ""
    @Published private(set) var choosingCandidate = false
    private var conversionTask: Task<Void, Never>?
    private var generation = 0
    private let lookup: @Sendable (String) async throws -> [String]
    var text: String { draft.text }
    var cursor: Int { draft.cursor }

    init(lookup: @escaping @Sendable (String) async throws -> [String] = {
        try await BrowserDictionary.shared.candidates(for: $0)
    }) { self.lookup = lookup }

    private func cancelConversion() {
        generation += 1
        conversionTask?.cancel(); conversionTask = nil
        converting = false; conversionMessage = ""
    }

    @discardableResult func insert(_ value: String, roman: Bool = true) -> Bool {
        let accepted = draft.insert(value, roman: roman)
        if accepted { choosingCandidate = false; updateCandidates(debounce: true) }
        return accepted
    }
    func edit(_ operation: String) { draft.edit(operation); choosingCandidate = false; updateCandidates(debounce: true) }
    func finishReading() { draft.finishReading() }
    func convert() {
        draft.finishReading()
        choosingCandidate = true
        updateCandidates(debounce: false)
    }
    private func updateCandidates(debounce: Bool) {
        cancelConversion()
        candidates = []
        var snapshot = draft
        snapshot.finishReading()
        let reading = snapshot.text
        guard !reading.isEmpty else { return }
        let request = generation
        let lookup = lookup
        converting = true
        conversionTask = Task { [weak self] in
            let words: [String]
            let message: String
            do {
                if debounce { try await Task.sleep(nanoseconds: 80_000_000) }
                try Task.checkCancellation()
                words = try await lookup(reading); message = ""
            }
            catch { words = []; message = "辞書を読み込めません。Resources一式を確認してください" }
            guard !Task.isCancelled, let self, self.generation == request else { return }
            let kana = reading.applyingTransform(.hiraganaToKatakana, reverse: false) ?? reading
            var result: [String] = []
            for value in words + [reading, kana] where !value.isEmpty && !result.contains(value) {
                result.append(value)
            }
            self.candidates = result
            self.converting = false
            self.conversionMessage = message
            self.conversionTask = nil
        }
    }
    func clear() { cancelConversion(); draft = BrowserRomanDraft(); candidates = []; choosingCandidate = false }
}
#endif
