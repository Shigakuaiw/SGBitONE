import Foundation

protocol BrowserHostResolver: Sendable {
    func resolve(_ host: String) async throws -> [String]
}

enum AdGuardDNSConfiguration {
    static let host = "dns.adguard-dns.com"
    static let endpoint = URL(string: "https://dns.adguard-dns.com/dns-query")!
    static let bootstrap = "94.140.14.14"
}

enum BrowserDNSFailure: Error { case malformed, rejected, blocked }

struct BrowserDNSMessage {
    struct Answer { var addresses: [String]; var ttl: UInt32 }

    static func query(host: String, type: UInt16, id: UInt16) throws -> Data {
        let host = host.hasSuffix(".") ? String(host.dropLast()) : host
        let labels = host.lowercased().split(separator: ".", omittingEmptySubsequences: false)
        guard !labels.isEmpty, host.utf8.count <= 253 else { throw BrowserDNSFailure.malformed }
        var bytes: [UInt8] = [UInt8(id >> 8), UInt8(id & 255), 1, 0, 0, 1, 0, 0, 0, 0, 0, 0]
        for label in labels {
            let value = Array(label.utf8)
            guard (1...63).contains(value.count), value.allSatisfy({
                (97...122).contains($0) || (48...57).contains($0) || $0 == 45 || $0 == 95
            }) else { throw BrowserDNSFailure.malformed }
            bytes.append(UInt8(value.count)); bytes += value
        }
        bytes += [0, UInt8(type >> 8), UInt8(type & 255), 0, 1]
        return Data(bytes)
    }

    static func answer(_ data: Data, host: String, type: UInt16, id: UInt16) throws -> Answer {
        let bytes = Array(data)
        func u16(_ offset: Int) throws -> UInt16 {
            guard offset >= 0, offset + 2 <= bytes.count else { throw BrowserDNSFailure.malformed }
            return (UInt16(bytes[offset]) << 8) | UInt16(bytes[offset + 1])
        }
        func name(_ offset: inout Int) throws -> String {
            var cursor = offset, labels: [String] = [], visited: Set<Int> = [], jumped = false
            while true {
                guard cursor < bytes.count, visited.insert(cursor).inserted, visited.count <= 128 else { throw BrowserDNSFailure.malformed }
                let length = Int(bytes[cursor])
                if length & 0xc0 == 0xc0 {
                    guard cursor + 1 < bytes.count else { throw BrowserDNSFailure.malformed }
                    if !jumped { offset = cursor + 2; jumped = true }
                    cursor = ((length & 0x3f) << 8) | Int(bytes[cursor + 1])
                } else {
                    guard length <= 63, cursor + 1 + length <= bytes.count else { throw BrowserDNSFailure.malformed }
                    cursor += 1
                    if length == 0 { if !jumped { offset = cursor }; break }
                    guard bytes[cursor..<(cursor + length)].allSatisfy({ $0 < 128 }) else { throw BrowserDNSFailure.malformed }
                    labels.append(String(decoding: bytes[cursor..<(cursor + length)], as: UTF8.self))
                    cursor += length
                }
            }
            let value = labels.joined(separator: ".").lowercased()
            guard value.utf8.count <= 253 else { throw BrowserDNSFailure.malformed }
            return value
        }
        guard bytes.count >= 12, bytes.count <= 65535, try u16(0) == id else { throw BrowserDNSFailure.malformed }
        let flags = try u16(2)
        guard flags & 0x8000 != 0, flags & 0x7a00 == 0, try u16(4) == 1 else { throw BrowserDNSFailure.malformed }
        let code = flags & 15
        if code == 3 { throw BrowserDNSFailure.blocked }
        guard code == 0 else { throw BrowserDNSFailure.rejected }
        let count = Int(try u16(6))
        guard count <= 256 else { throw BrowserDNSFailure.malformed }
        var offset = 12
        let expected = host.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
        guard try name(&offset) == expected, try u16(offset) == type, try u16(offset + 2) == 1 else { throw BrowserDNSFailure.malformed }
        offset += 4
        var aliases: [String: String] = [:]
        var records: [(String, String, UInt32)] = []
        var ttl = UInt32.max
        for _ in 0..<count {
            let owner = try name(&offset)
            let kind = try u16(offset), family = try u16(offset + 2)
            let seconds = (UInt32(try u16(offset + 4)) << 16) | UInt32(try u16(offset + 6))
            let length = Int(try u16(offset + 8))
            offset += 10
            guard offset + length <= bytes.count else { throw BrowserDNSFailure.malformed }
            if family == 1 {
                ttl = min(ttl, seconds)
                if kind == 5 {
                    var end = offset
                    aliases[owner] = try name(&end)
                    guard end == offset + length else { throw BrowserDNSFailure.malformed }
                } else if kind == type && kind == 1 && length == 4 {
                    records.append((owner, bytes[offset..<(offset + 4)].map(String.init).joined(separator: "."), seconds))
                } else if kind == type && kind == 28 && length == 16 {
                    let address = stride(from: offset, to: offset + 16, by: 2).map {
                        String((UInt16(bytes[$0]) << 8) | UInt16(bytes[$0 + 1]), radix: 16)
                    }.joined(separator: ":")
                    records.append((owner, address, seconds))
                }
            }
            offset += length
        }
        var permitted: Set<String> = [expected], current = expected
        for _ in 0..<16 {
            guard let next = aliases[current], permitted.insert(next).inserted else { break }
            current = next
        }
        let addresses = records.filter { permitted.contains($0.0) && $0.1 != "0.0.0.0" && $0.1 != "0:0:0:0:0:0:0:0" }.map { $0.1 }
        return Answer(addresses: addresses, ttl: ttl == .max ? 0 : min(ttl, 300))
    }
}

#if canImport(Network)
actor AdGuardDNSResolver: BrowserHostResolver {
    private let session: URLSession
    private var cache: [String: (Date, [String])] = [:]
    init(session: URLSession) { self.session = session }
    func clearCache() { cache.removeAll() }

    func resolve(_ host: String) async throws -> [String] {
        let key = host.lowercased()
        if let entry = cache[key], entry.0 > Date() { return entry.1 }
        async let ipv4 = lookup(host, type: 1)
        async let ipv6 = lookup(host, type: 28)
        let (v4, v6) = try await (ipv4, ipv6)
        try Task.checkCancellation()
        let addresses = v4.addresses + v6.addresses
        guard !addresses.isEmpty else { throw BrowserDNSFailure.blocked }
        if cache.count >= 256 { cache.removeAll() }
        let ttl = [v4, v6].filter { !$0.addresses.isEmpty }.map(\.ttl).min() ?? 0
        if ttl > 0 { cache[key] = (Date().addingTimeInterval(TimeInterval(ttl)), addresses) }
        return addresses
    }

    private func lookup(_ host: String, type: UInt16) async throws -> BrowserDNSMessage.Answer {
        let id = UInt16.random(in: .min ... .max)
        var request = URLRequest(url: AdGuardDNSConfiguration.endpoint)
        request.httpMethod = "POST"
        request.setValue("application/dns-message", forHTTPHeaderField: "Content-Type")
        request.setValue("application/dns-message", forHTTPHeaderField: "Accept")
        request.httpBody = try BrowserDNSMessage.query(host: host, type: type, id: id)
        let (bytes, response) = try await session.bytes(for: request)
        defer { bytes.task.cancel() }
        guard let response = response as? HTTPURLResponse, response.statusCode == 200,
              response.mimeType == "application/dns-message", response.expectedContentLength <= 65535 else { throw BrowserDNSFailure.rejected }
        var data = Data()
        for try await byte in bytes {
            try Task.checkCancellation()
            guard data.count < 65535 else { throw BrowserDNSFailure.malformed }
            data.append(byte)
        }
        return try BrowserDNSMessage.answer(data, host: host, type: type, id: id)
    }
}
#endif
