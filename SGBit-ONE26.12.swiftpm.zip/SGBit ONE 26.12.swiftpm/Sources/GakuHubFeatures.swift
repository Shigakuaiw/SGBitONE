import SwiftUI
import AVFoundation
import ShazamKit
import UniformTypeIdentifiers
import QuickLook

@MainActor final class Library: ObservableObject {
    static let shared = Library()
    @Published private(set) var files: [URL] = []
    @Published private(set) var revision: Int = 0
    @Published var lastError: String?
    let folder: URL
    private init() {
        folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        refresh()
    }
    func contents(of directory: URL) -> [URL] {
        (try? FileManager.default.contentsOfDirectory(
            at: directory, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles]))?
            .sorted { a, b in
                let ad = (try? a.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
                let bd = (try? b.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
                return ad == bd ? a.lastPathComponent.localizedStandardCompare(b.lastPathComponent) == .orderedAscending : ad
            } ?? []
    }
    func refresh() { files = contents(of: folder); revision &+= 1 }
    private func perform(_ action: () throws -> Void) {
        do { try action(); lastError = nil; refresh() }
        catch { lastError = error.localizedDescription }
    }
    func add(_ url: URL, to folder: URL? = nil) {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        perform {
            let parent = folder ?? self.folder
            var target = parent.appendingPathComponent(url.lastPathComponent)
            if FileManager.default.fileExists(atPath: target.path) {
                target = parent.appendingPathComponent(UUID().uuidString.prefix(6) + "-" + url.lastPathComponent)
            }
            try FileManager.default.copyItem(at: url, to: target)
        }
    }
    func allMusicFiles(in directory: URL? = nil) -> [URL] {
        let root = directory ?? folder
        var result: [URL] = []
        for url in contents(of: root) {
            let directory = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            if directory { result.append(contentsOf: allMusicFiles(in: url)) }
            else if ["mp3", "m4a", "wav", "aac", "caf", "aiff"].contains(url.pathExtension.lowercased()) { result.append(url) }
        }
        return result
    }
    func createFolder(_ name: String, in parent: URL) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed != ".", trimmed != "..", !trimmed.contains("/") else {
            lastError = "フォルダ名を確認してください"; return
        }
        perform { try FileManager.default.createDirectory(at: parent.appendingPathComponent(trimmed), withIntermediateDirectories: false) }
    }
    func rename(_ url: URL, to name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed != ".", trimmed != "..", !trimmed.contains("/") else {
            lastError = "名前を確認してください"; return
        }
        perform {
            let target = url.deletingLastPathComponent().appendingPathComponent(trimmed)
            if FileManager.default.fileExists(atPath: target.path) { throw CocoaError(.fileWriteFileExists) }
            try FileManager.default.moveItem(at: url, to: target)
        }
    }
    func delete(_ url: URL) { perform { try FileManager.default.removeItem(at: url) } }
}

struct FilesScreen: View {
    @ObservedObject private var library = Library.shared
    @State private var currentFolder: URL = Library.shared.folder
    @State private var importing = false
    @State private var previewURL: URL?
    @State private var creatingFolder = false
    @State private var newFolderName = ""
    @State private var renameTarget: URL?
    @State private var renamedText = ""
    @State private var source = 0

    private var visibleFiles: [URL] {
        _ = library.revision
        return library.contents(of: currentFolder)
    }
    private func isFolder(_ url: URL) -> Bool {
        (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("ファイルの場所", selection: $source) {
                    Text("この端末").tag(0)
                    Text("クラウド (R2)").tag(1)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .padding(.top, 8)
                if source == 1 {
                    ONECloudFilesView()
                } else {
            List {
                if currentFolder != library.folder {
                    Button {
                        currentFolder = currentFolder.deletingLastPathComponent()
                    } label: { Label("上のフォルダへ", systemImage: "arrow.up.left") }
                } else {
                    Section {
                        Label("Webから保存したファイルは「Downloads」に入ります", systemImage: "arrow.down.circle")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                if visibleFiles.isEmpty {
                    ContentUnavailableView("ファイルがありません", systemImage: "folder", description: Text("＋からファイルやフォルダを追加できます"))
                }
                ForEach(visibleFiles, id: \.self) { file in
                    HStack(spacing: 12) {
                        Button {
                            if isFolder(file) { currentFolder = file }
                            else { previewURL = file }
                        } label: {
                            Label(file.lastPathComponent, systemImage: isFolder(file) ? "folder.fill" : "doc.fill")
                                .lineLimit(2)
                        }
                        .buttonStyle(.plain)
                        Spacer(minLength: 4)
                        if !isFolder(file) {
                            ShareLink(item: file) { Image(systemName: "square.and.arrow.up") }
                                .accessibilityLabel("共有: \(file.lastPathComponent)")
                        }
                    }
                    .contextMenu {
                        Button("名前を変更", systemImage: "pencil") {
                            renameTarget = file
                            renamedText = file.lastPathComponent
                        }
                        if !isFolder(file) {
                            ShareLink(item: file) { Label("共有・書き出し", systemImage: "square.and.arrow.up") }
                        }
                        Button(role: .destructive) { library.delete(file) } label: { Label("削除", systemImage: "trash") }
                    }
                }
                .onDelete { offsets in
                    let targets = offsets.map { visibleFiles[$0] }
                    for url in targets { library.delete(url) }
                }
            }
                }
            }
            .navigationTitle(source == 1 ? "クラウドファイル" : (currentFolder == library.folder ? "ファイル" : currentFolder.lastPathComponent))
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    if source == 0 {
                    Menu {
                        Button("ファイルを読み込む", systemImage: "square.and.arrow.down") { importing = true }
                        Button("新しいフォルダ", systemImage: "folder.badge.plus") { newFolderName = ""; creatingFolder = true }
                    } label: { Image(systemName: "plus") }
                    }
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
                switch result {
                case .success(let urls): urls.forEach { library.add($0, to: currentFolder) }
                case .failure(let error): library.lastError = error.localizedDescription
                }
            }
            .quickLookPreview($previewURL)
            .alert("新しいフォルダ", isPresented: $creatingFolder) {
                TextField("フォルダ名", text: $newFolderName)
                Button("作成") { library.createFolder(newFolderName, in: currentFolder) }
                Button("キャンセル", role: .cancel) {}
            }
            .alert("名前を変更", isPresented: Binding(
                get: { renameTarget != nil },
                set: { if !$0 { renameTarget = nil } }
            )) {
                TextField("ファイル名", text: $renamedText)
                Button("変更") { if let url = renameTarget { library.rename(url, to: renamedText) }; renameTarget = nil }
                Button("キャンセル", role: .cancel) { renameTarget = nil }
            }
            .alert("ファイル操作エラー", isPresented: Binding(
                get: { library.lastError != nil },
                set: { if !$0 { library.lastError = nil } }
            )) {
                Button("OK") { library.lastError = nil }
            } message: {
                Text(library.lastError ?? "")
            }
            .onAppear {
                library.refresh()
                if !FileManager.default.fileExists(atPath: currentFolder.path) { currentFolder = library.folder }
            }
        }
    }
}

@MainActor final class AudioPlayerModel: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published private(set) var playing: URL?
    @Published private(set) var isPlaying = false
    @Published private(set) var artwork: UIImage?
    @Published private(set) var artist = ""
    @Published private(set) var title = ""
    @Published var errorMessage: String?

    private var player: AVAudioPlayer?
    private var queue: [URL] = []

    func updateQueue(_ tracks: [URL]) {
        queue = tracks
    }

    func play(_ url: URL) {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback)
            try AVAudioSession.sharedInstance().setActive(true)
            let next = try AVAudioPlayer(contentsOf: url)
            next.delegate = self
            next.prepareToPlay()
            guard next.play() else { errorMessage = "この曲を再生できません"; return }
            player?.stop()
            player = next
            playing = url
            isPlaying = true
            errorMessage = nil
            title = url.deletingPathExtension().lastPathComponent
            artist = ""
            artwork = nil
            loadMetadata(for: url)
        } catch {
            errorMessage = "再生できません: \(error.localizedDescription)"
        }
    }

    private func loadMetadata(for url: URL) {
        Task {
            let asset = AVURLAsset(url: url)
            guard let metadata = try? await asset.load(.commonMetadata), playing == url else { return }
            if let name = metadata.first(where: { $0.commonKey == .commonKeyTitle })?.stringValue, !name.isEmpty { title = name }
            if let name = metadata.first(where: { $0.commonKey == .commonKeyArtist })?.stringValue { artist = name }
            if let data = metadata.first(where: { $0.commonKey == .commonKeyArtwork })?.dataValue {
                artwork = UIImage(data: data)
            }
        }
    }

    func toggle() {
        guard let player else { return }
        if player.isPlaying {
            player.pause()
            isPlaying = false
        } else {
            isPlaying = player.play()
        }
    }

    func next() { advance(by: 1) }
    func previous() {
        if let player, player.currentTime > 3 {
            player.currentTime = 0
            return
        }
        advance(by: -1)
    }

    private func advance(by offset: Int) {
        guard !queue.isEmpty else { return }
        let index = playing.flatMap { queue.firstIndex(of: $0) } ?? (offset > 0 ? -1 : 0)
        let destination = (index + offset + queue.count) % queue.count
        play(queue[destination])
    }

    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        Task { @MainActor [weak self] in self?.next() }
    }
}

// SGBit Music playlists store only paths relative to the app's Documents directory.
struct SGBitPlaylist: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var songs: [String] = []
}

@MainActor final class SGBitPlaylistStore: ObservableObject {
    @Published private(set) var playlists: [SGBitPlaylist] = []
    private let storageURL = Library.shared.folder.appendingPathComponent("sgbit-music-playlists.json")

    init() {
        if let data = try? Data(contentsOf: storageURL),
           let value = try? JSONDecoder().decode([SGBitPlaylist].self, from: data) {
            playlists = value
        }
    }
    private func save() {
        guard let data = try? JSONEncoder().encode(playlists) else { return }
        try? data.write(to: storageURL, options: .atomic)
    }
    func create(_ name: String) {
        let cleaned = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return }
        playlists.append(SGBitPlaylist(name: cleaned))
        save()
    }
    func rename(_ id: UUID, to name: String) {
        let cleaned = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty, let index = playlists.firstIndex(where: { $0.id == id }) else { return }
        playlists[index].name = cleaned
        save()
    }
    func remove(_ id: UUID) { playlists.removeAll { $0.id == id }; save() }
    func add(_ song: URL, to id: UUID) {
        guard let index = playlists.firstIndex(where: { $0.id == id }),
              let relative = relativePath(song) else { return }
        if !playlists[index].songs.contains(relative) { playlists[index].songs.append(relative); save() }
    }
    func removeSong(_ song: URL, from id: UUID) {
        guard let index = playlists.firstIndex(where: { $0.id == id }),
              let relative = relativePath(song) else { return }
        playlists[index].songs.removeAll { $0 == relative }
        save()
    }
    func songs(in playlist: SGBitPlaylist, available: [URL]) -> [URL] {
        let indexed = Dictionary(available.compactMap { url -> (String, URL)? in
            guard let relative = relativePath(url) else { return nil }
            return (relative, url)
        }, uniquingKeysWith: { first, _ in first })
        return playlist.songs.compactMap { indexed[$0] }
    }
    private func relativePath(_ song: URL) -> String? {
        let root = Library.shared.folder.standardizedFileURL.path + "/"
        let full = song.standardizedFileURL.path
        guard full.hasPrefix(root) else { return nil }
        return String(full.dropFirst(root.count))
    }
}

struct MusicScreen: View {
    @ObservedObject private var library = Library.shared
    @StateObject private var audio = AudioPlayerModel()
    @StateObject private var playlists = SGBitPlaylistStore()
    @State private var selectedPlaylistID: UUID?
    @State private var showingCreate = false
    @State private var newName = ""
    @State private var editingPlaylistID: UUID?
    @State private var showingRename = false
    @State private var showingAddSongs = false

    private var tracks: [URL] {
        _ = library.revision
        return library.allMusicFiles()
    }
    private var selectedPlaylist: SGBitPlaylist? {
        playlists.playlists.first { $0.id == selectedPlaylistID }
    }
    private var visibleTracks: [URL] {
        guard let selectedPlaylist else { return tracks }
        return playlists.songs(in: selectedPlaylist, available: tracks)
    }
    private var artworkPlaceholder: some View {
        Image(systemName: "music.note")
            .font(.title2)
            .frame(width: 52, height: 52)
            .background(.quaternary, in: RoundedRectangle(cornerRadius: 10))
    }

    var body: some View {
        NavigationStack {
            List {
                Section("ライブラリ") {
                    Button {
                        selectedPlaylistID = nil
                    } label: {
                        Label("すべての曲（\(tracks.count)）", systemImage: "music.note.list")
                            .foregroundStyle(selectedPlaylistID == nil ? Color.accentColor : Color.primary)
                    }
                }
                Section("プレイリスト") {
                    ForEach(playlists.playlists) { playlist in
                        Button {
                            selectedPlaylistID = playlist.id
                        } label: {
                            HStack {
                                Label(playlist.name, systemImage: "music.note.list")
                                    .foregroundStyle(selectedPlaylistID == playlist.id ? Color.accentColor : Color.primary)
                                Spacer()
                                Text("\(playlists.songs(in: playlist, available: tracks).count)曲")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        .contextMenu {
                            Button("名前を変更", systemImage: "pencil") {
                                editingPlaylistID = playlist.id
                                newName = playlist.name
                                showingRename = true
                            }
                            Button("削除", systemImage: "trash", role: .destructive) {
                                playlists.remove(playlist.id)
                                if selectedPlaylistID == playlist.id { selectedPlaylistID = nil }
                            }
                        }
                    }
                    Button { newName = ""; showingCreate = true } label: {
                        Label("新しいプレイリスト", systemImage: "plus.circle.fill")
                    }
                }
                Section(selectedPlaylist?.name ?? "すべての曲") {
                    if visibleTracks.isEmpty {
                        Text(selectedPlaylist == nil ? "音楽がありません。ファイルから曲を取り込んでください。" : "曲がありません。「曲を追加」から選んでください。")
                            .foregroundStyle(.secondary)
                    }
                    ForEach(visibleTracks, id: \.self) { url in
                        HStack(spacing: 10) {
                            Button {
                                audio.updateQueue(visibleTracks)
                                audio.play(url)
                            } label: {
                                HStack {
                                    Image(systemName: "music.note").foregroundStyle(.secondary)
                                    Text(url.deletingPathExtension().lastPathComponent).lineLimit(1)
                                    Spacer(minLength: 8)
                                    if audio.playing == url {
                                        Image(systemName: audio.isPlaying ? "waveform" : "pause.fill")
                                            .foregroundStyle(.tint)
                                    }
                                }
                            }
                            .buttonStyle(.plain)
                            Menu {
                                if let selectedPlaylist {
                                    Button("プレイリストから削除", systemImage: "minus.circle") {
                                        playlists.removeSong(url, from: selectedPlaylist.id)
                                    }
                                } else {
                                    ForEach(playlists.playlists) { playlist in
                                        Button(playlist.name) { playlists.add(url, to: playlist.id) }
                                    }
                                }
                            } label: { Image(systemName: "ellipsis.circle") }
                            .disabled(selectedPlaylist == nil && playlists.playlists.isEmpty)
                            .accessibilityLabel("プレイリスト操作")
                        }
                    }
                }
            }
            .navigationTitle("SGBit Music")
            .toolbar {
                if selectedPlaylist != nil {
                    ToolbarItem(placement: .primaryAction) {
                        Button("曲を追加", systemImage: "plus") { showingAddSongs = true }
                    }
                }
            }
            .sheet(isPresented: $showingAddSongs) {
                NavigationStack {
                    List(tracks, id: \.self) { url in
                        Button {
                            if let selectedPlaylistID { playlists.add(url, to: selectedPlaylistID) }
                        } label: {
                            HStack {
                                Text(url.deletingPathExtension().lastPathComponent)
                                    .foregroundStyle(.primary)
                                Spacer()
                                if let selectedPlaylist, playlists.songs(in: selectedPlaylist, available: tracks).contains(url) {
                                    Image(systemName: "checkmark").foregroundStyle(.tint)
                                } else {
                                    Image(systemName: "plus.circle").foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    .navigationTitle("曲を追加")
                    .toolbar { ToolbarItem(placement: .confirmationAction) {
                        Button("完了") { showingAddSongs = false }
                    } }
                }
            }
            .alert("プレイリストを作成", isPresented: $showingCreate) {
                TextField("プレイリスト名", text: $newName)
                Button("作成") { playlists.create(newName) }
                Button("キャンセル", role: .cancel) {}
            }
            .alert("プレイリスト名を変更", isPresented: $showingRename) {
                TextField("プレイリスト名", text: $newName)
                Button("変更") {
                    if let editingPlaylistID { playlists.rename(editingPlaylistID, to: newName) }
                    editingPlaylistID = nil
                }
                Button("キャンセル", role: .cancel) { editingPlaylistID = nil }
            }
            .safeAreaInset(edge: .bottom) {
                if audio.playing != nil {
                    HStack(spacing: 12) {
                        Group {
                            if let art = audio.artwork {
                                Image(uiImage: art).resizable().scaledToFill()
                                    .frame(width: 52, height: 52)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                            } else { artworkPlaceholder }
                        }
                        VStack(alignment: .leading, spacing: 3) {
                            Text(audio.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                            Text(audio.artist.isEmpty ? "ローカル音楽" : audio.artist)
                                .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                        Spacer(minLength: 0)
                        Button { audio.previous() } label: {
                            Image(systemName: "backward.end.fill").frame(width: 38, height: 44)
                        }.accessibilityLabel("前の曲")
                        Button { audio.toggle() } label: {
                            Image(systemName: audio.isPlaying ? "pause.fill" : "play.fill")
                                .frame(width: 38, height: 44)
                        }.accessibilityLabel(audio.isPlaying ? "一時停止" : "再生")
                        Button { audio.next() } label: {
                            Image(systemName: "forward.end.fill").frame(width: 38, height: 44)
                        }.accessibilityLabel("次の曲")
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal, 12).padding(.vertical, 8)
                    .background(.regularMaterial)
                }
            }
            .alert("音楽を再生できません", isPresented: Binding(
                get: { audio.errorMessage != nil },
                set: { if !$0 { audio.errorMessage = nil } }
            )) { Button("OK", role: .cancel) { audio.errorMessage = nil } }
            message: { Text(audio.errorMessage ?? "") }
            .onAppear { library.refresh(); audio.updateQueue(visibleTracks) }
            .onChange(of: library.revision) { _, _ in audio.updateQueue(visibleTracks) }
            .onChange(of: selectedPlaylistID) { _, _ in audio.updateQueue(visibleTracks) }
            .onChange(of: playlists.playlists) { _, _ in audio.updateQueue(visibleTracks) }
        }
    }
}

@MainActor final class SongRecognition: ObservableObject {
    @Published var status = "周囲の音楽を認識できます"
    @Published var song = ""
    @Published var artist = ""
    @Published var artwork: URL?
    @Published var musicURL: URL?
    @Published var listening = false
    private var session: SHManagedSession?
    private var task: Task<Void, Never>?
    private var requestID = UUID()

    func start() {
        guard !listening else { return }
        requestID = UUID()
        let currentID = requestID
        listening = true
        status = "マイクを準備中…"
        song = ""; artist = ""; artwork = nil; musicURL = nil
        task = Task { [weak self] in
            guard let self else { return }
            let allowed = await Self.microphoneAllowed()
            guard !Task.isCancelled, self.requestID == currentID else { return }
            guard allowed else {
                self.listening = false
                self.status = "マイクが許可されていません。設定からSGBit ONEのマイクを許可してください。"
                return
            }
            do {
                // The music player uses .playback. Recognition must allow microphone input.
                try AVAudioSession.sharedInstance().setCategory(.playAndRecord,
                    mode: .default, options: [.defaultToSpeaker, .mixWithOthers])
                try AVAudioSession.sharedInstance().setActive(true)
            } catch {
                self.listening = false
                self.status = "マイクの準備に失敗: \(error.localizedDescription)"
                return
            }
            guard !Task.isCancelled, self.requestID == currentID else { return }
            let newSession = SHManagedSession()
            self.session = newSession
            self.status = "認識中… 周囲の音楽を聞かせてください"
            let result = await newSession.result()
            guard !Task.isCancelled, self.requestID == currentID else { return }
            self.listening = false
            self.session = nil
            switch result {
            case .match(let match):
                if let item = match.mediaItems.first {
                    self.song = item.title ?? "曲名不明"
                    self.artist = item.artist ?? "アーティスト不明"
                    self.artwork = item.artworkURL
                    self.musicURL = item.appleMusicURL
                    self.status = "見つかりました！"
                } else { self.status = "曲情報がありません" }
            case .noMatch:
                self.status = "一致する曲がありませんでした。もう一度試してください。"
            case .error(let error, _):
                let nsError = error as NSError
                self.status = "認識エラー（\(nsError.domain) / \(nsError.code)）: \(error.localizedDescription)"
            }
        }
    }

    private static func microphoneAllowed() async -> Bool {
        switch AVAudioSession.sharedInstance().recordPermission {
        case .granted: return true
        case .denied: return false
        case .undetermined:
            return await withCheckedContinuation { continuation in
                AVAudioSession.sharedInstance().requestRecordPermission { granted in
                    continuation.resume(returning: granted)
                }
            }
        @unknown default: return false
        }
    }

    func stop() {
        requestID = UUID()
        task?.cancel()
        session?.cancel()
        session = nil
        task = nil
        listening = false
        status = "停止しました"
    }
}

struct RecognitionScreen: View {
    @StateObject private var model = SongRecognition()
    var body: some View {
        NavigationStack {
            VStack(spacing: 22) {
                Spacer()
                if let url = model.artwork {
                    AsyncImage(url: url) { image in image.resizable().scaledToFit() } placeholder: { ProgressView() }
                        .frame(width: 210, height: 210).clipShape(RoundedRectangle(cornerRadius: 20))
                } else {
                    Image(systemName: "waveform.circle.fill").font(.system(size: 125)).foregroundStyle(.blue)
                }
                Text(model.status).foregroundStyle(.secondary)
                if !model.song.isEmpty {
                    Text(model.song).font(.title2.bold())
                    Text(model.artist)
                }
                Button(model.listening ? "停止" : "音楽を認識") {
                    if model.listening { model.stop() } else { model.start() }
                }.buttonStyle(.borderedProminent).controlSize(.large)
                if let url = model.musicURL { Link("Apple Musicで開く", destination: url) }
                Spacer()
            }
            .padding()
            .navigationTitle("音楽認識")
            .onDisappear { model.stop() }
        }
    }
}
