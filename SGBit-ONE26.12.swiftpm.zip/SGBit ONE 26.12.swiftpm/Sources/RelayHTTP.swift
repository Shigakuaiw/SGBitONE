import Foundation
#if canImport(Network)
import Network
#endif

struct ProxyCredentials: Sendable {
    let username = UUID().uuidString
    let password = UUID().uuidString
    let isPrivate: Bool
    init(isPrivate: Bool = false) { self.isPrivate = isPrivate }
}

enum SocksFailure: Error, Equatable {
    case greeting, authentication, request(UInt8), tooLarge

    var reply: Data {
        switch self {
        case .greeting: return Data([5, 255])
        case .authentication: return Data([1, 1])
        case .request(let code): return SocksHandshake.connectReply(code)
        case .tooLarge: return Data()
        }
    }

    var diagnostic: String {
        switch self {
        case .greeting: return "SOCKS5認証方式を拒否（ユーザー名・パスワード方式が必要）"
        case .authentication: return "SOCKS5ユーザー認証失敗"
        case .request(let code): return "SOCKS5接続要求拒否 (\(code))"
        case .tooLarge: return "SOCKS5ハンドシェイクのサイズ上限超過"
        }
    }
}

struct SocksHandshake {
    enum Action {
        case reply(Data)
        case connect(host: String, port: UInt16, initialData: Data)
    }

    private enum Phase { case greeting, authentication, request, finished }
    private var phase = Phase.greeting
    private var buffer: [UInt8] = []
    private let credentials: [ProxyCredentials]
    private(set) var privateSession = false
    static let maxBufferedBytes = 32 * 1024

    init(credentials: ProxyCredentials, additionalCredentials: [ProxyCredentials] = []) {
        self.credentials = [credentials] + additionalCredentials
    }

    var stage: String {
        switch phase {
        case .greeting: return "SOCKS5方式選択"
        case .authentication: return "SOCKS5ユーザー認証"
        case .request: return "SOCKS5接続先受信"
        case .finished: return "SOCKS5要求処理"
        }
    }

    static func connectReply(_ code: UInt8) -> Data {
        Data([5, code, 0, 1, 0, 0, 0, 0, 0, 0])
    }

    mutating func advance(_ data: Data) throws -> Action? {
        guard data.count <= Self.maxBufferedBytes - buffer.count else { throw SocksFailure.tooLarge }
        buffer.append(contentsOf: data)
        switch phase {
        case .greeting:
            guard buffer.count >= 2 else { return nil }
            guard buffer[0] == 5, buffer[1] > 0 else { throw SocksFailure.greeting }
            let length = 2 + Int(buffer[1])
            guard buffer.count >= length else { return nil }
            guard buffer[2..<length].contains(2) else { throw SocksFailure.greeting }
            buffer.removeFirst(length)
            phase = .authentication
            return .reply(Data([5, 2]))

        case .authentication:
            guard buffer.count >= 2 else { return nil }
            guard buffer[0] == 1, buffer[1] > 0 else { throw SocksFailure.authentication }
            let passwordOffset = 2 + Int(buffer[1])
            guard buffer.count > passwordOffset else { return nil }
            guard buffer[passwordOffset] > 0 else { throw SocksFailure.authentication }
            let length = passwordOffset + 1 + Int(buffer[passwordOffset])
            guard buffer.count >= length else { return nil }
            guard let credential = credentials.first(where: {
                Array(buffer[2..<passwordOffset]) == Array($0.username.utf8) &&
                Array(buffer[(passwordOffset + 1)..<length]) == Array($0.password.utf8)
            }) else {
                throw SocksFailure.authentication
            }
            privateSession = credential.isPrivate
            buffer.removeFirst(length)
            phase = .request
            return .reply(Data([1, 0]))

        case .request:
            guard buffer.count >= 4 else { return nil }
            guard buffer[0] == 5, buffer[2] == 0 else { throw SocksFailure.request(1) }
            guard buffer[1] == 1 else { throw SocksFailure.request(7) }
            let host: String
            let addressEnd: Int
            switch buffer[3] {
            case 1:
                addressEnd = 8
                guard buffer.count >= addressEnd + 2 else { return nil }
                host = buffer[4..<8].map { String($0) }.joined(separator: ".")
            case 3:
                guard buffer.count >= 5 else { return nil }
                guard buffer[4] > 0 else { throw SocksFailure.request(8) }
                addressEnd = 5 + Int(buffer[4])
                guard buffer.count >= addressEnd + 2 else { return nil }
                let bytes = buffer[5..<addressEnd]
                guard bytes.allSatisfy({
                    (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0)
                        || $0 == 45 || $0 == 46 || $0 == 95
                }) else { throw SocksFailure.request(8) }
                host = String(decoding: bytes, as: UTF8.self)
            case 4:
                addressEnd = 20
                guard buffer.count >= addressEnd + 2 else { return nil }
                host = stride(from: 4, to: 20, by: 2).map {
                    String((UInt16(buffer[$0]) << 8) | UInt16(buffer[$0 + 1]), radix: 16)
                }.joined(separator: ":")
            default: throw SocksFailure.request(8)
            }
            let port = (UInt16(buffer[addressEnd]) << 8) | UInt16(buffer[addressEnd + 1])
            guard port != 0 else { throw SocksFailure.request(2) }
            let initialData = Data(buffer.dropFirst(addressEnd + 2))
            buffer.removeAll(keepingCapacity: false)
            phase = .finished
            return .connect(host: host, port: port, initialData: initialData)

        case .finished:
            throw SocksFailure.request(1)
        }
    }
}

#if canImport(Network)
// SOCKS5 authenticates locally; TLS stays between WebKit and the destination.
struct RelayUpstreamRoute {
    let configured: Bool?
    let used: Bool
    let endpoint: String?
}

final class ProxyTunnel: @unchecked Sendable {
    typealias RouteInspector = (RelayDirectTCP, DispatchQueue, @escaping (RelayUpstreamRoute?) -> Void) -> Void
    private let inspectRoute: RouteInspector

    static func inspectDirectRoute(_ remote: RelayDirectTCP, queue: DispatchQueue, completion: @escaping (RelayUpstreamRoute?) -> Void) {
        remote.inspectRoute(queue: queue, completion: completion)
    }
    private let client: NWConnection
    private let queue: DispatchQueue
    private let onOpened: () -> Void
    private let onDiagnostic: (String) -> Void
    private let onClose: () -> Void
    private var handshake: SocksHandshake
    private var upstream: RelayDirectTCP?
    private var requestAccepted = false
    private var established = false
    private var checkingRoute = false
    private var responding = false
    private var closed = false
    private var endedDirections = 0
    private let resolver: (any BrowserHostResolver)?
    private let onUpdate: (RelayConnectionSnapshot) -> Void
    private var metrics: RelayConnectionSnapshot
    private var resolutionTask: Task<Void, Never>?
    var isPrivateSession: Bool { metrics.isPrivate }

    init(connection: NWConnection, queue: DispatchQueue, credentials: ProxyCredentials,
         onOpened: @escaping () -> Void, onDiagnostic: @escaping (String) -> Void,
         onClose: @escaping () -> Void, privateCredentials: ProxyCredentials? = nil,
         resolver: (any BrowserHostResolver)? = nil, id: UUID = UUID(),
          onUpdate: @escaping (RelayConnectionSnapshot) -> Void = { _ in },
          inspectRoute: @escaping RouteInspector = ProxyTunnel.inspectDirectRoute) {
        client = connection
        self.queue = queue
        handshake = SocksHandshake(credentials: credentials, additionalCredentials: privateCredentials.map { [$0] } ?? [])
        self.onOpened = onOpened
        self.onDiagnostic = onDiagnostic
        self.onClose = onClose
        self.resolver = resolver
        self.onUpdate = onUpdate
        self.inspectRoute = inspectRoute
        metrics = RelayConnectionSnapshot(id: id)
    }

    func start() {
        onUpdate(metrics)
        client.stateUpdateHandler = { [weak self] state in
            guard let self, !self.closed else { return }
            switch state {
            case .ready:
                self.onDiagnostic("WebView接続・SOCKS5方式選択待ち")
                self.receiveHandshake()
            case .failed(let error):
                self.report("WebView接続失敗", error: error)
                self.close()
            case .cancelled: self.close()
            default: break
            }
        }
        client.start(queue: queue)
        queue.asyncAfter(deadline: .now() + 10) { [weak self] in
            guard let self, !self.closed, !self.requestAccepted else { return }
            self.metrics.error = "SOCKS5ハンドシェイクの期限超過"
            self.onDiagnostic(self.metrics.error!)
            self.close()
        }
    }

    private func receiveHandshake() {
        guard !closed, !responding, !requestAccepted else { return }
        client.receive(minimumIncompleteLength: 1, maximumLength: 16384) {
            [weak self] data, _, complete, error in
            guard let self, !self.closed else { return }
            if let error {
                self.report("SOCKS5受信失敗", error: error)
                self.close()
            } else if let data, !data.isEmpty {
                self.advanceHandshake(data)
            } else if complete {
                self.onDiagnostic("\(self.handshake.stage)中にWebViewが切断")
                self.close()
            } else {
                self.receiveHandshake()
            }
        }
    }

    private func advanceHandshake(_ data: Data) {
        guard !closed, !responding, !requestAccepted else { return }
        do {
            guard let action = try handshake.advance(data) else { receiveHandshake(); return }
            switch action {
            case .reply(let reply):
                metrics.isPrivate = handshake.privateSession
                responding = true
                client.send(content: reply, completion: .contentProcessed { [weak self] error in
                    guard let self, !self.closed else { return }
                    self.responding = false
                    if let error {
                        self.report("SOCKS5応答送信失敗", error: error)
                        self.close()
                    } else {
                        self.onDiagnostic(self.handshake.stage + "待ち")
                        self.advanceHandshake(Data())
                    }
                })
            case .connect(let host, let port, let initialData):
                requestAccepted = true
                metrics.host = host
                metrics.port = port
                metrics.state = "接続中"
                onUpdate(metrics)
                resolveAndConnect(host: host, port: port, initialData: initialData)
                queue.asyncAfter(deadline: .now() + 18) { [weak self] in
                    guard let self, !self.closed, !self.established else { return }
                    self.metrics.error = "DNS / 上流TCP接続 / 宛先確認の期限超過"
                    self.onDiagnostic(self.metrics.error!)
                    self.reject(SocksHandshake.connectReply(4))
                }
            }
        } catch let error as SocksFailure {
            metrics.error = error.diagnostic
            onDiagnostic(error.diagnostic)
            reject(error.reply)
        } catch {
            metrics.error = "SOCKS5要求の解析失敗"
            onDiagnostic(metrics.error!)
            close()
        }
    }

    private func resolveAndConnect(host: String, port: UInt16, initialData: Data) {
        if resolver != nil, host.lowercased() == AdGuardDNSConfiguration.host && port == 443 {
            connect(host: AdGuardDNSConfiguration.bootstrap, port: port, initialData: initialData)
            return
        }
        let selectedResolver: any BrowserHostResolver = resolver ?? SystemDNSResolver()
        if IPv4Address(host) != nil || IPv6Address(host) != nil {
            connect(host: host, port: port, initialData: initialData)
            return
        }
        let queue = queue
        resolutionTask = Task { [weak self] in
            do {
                let addresses = try await selectedResolver.resolve(host)
                guard !addresses.isEmpty, addresses.allSatisfy({ IPv4Address($0) != nil || IPv6Address($0) != nil }) else {
                    throw BrowserDNSFailure.rejected
                }
                try Task.checkCancellation()
                queue.async { [weak self] in
                    guard let self, !self.closed, let first = addresses.first else { return }
                    self.connect(host: first, port: port, initialData: initialData, remaining: Array(addresses.dropFirst()))
                }
            } catch {
                queue.async { [weak self] in
                    guard let self, !self.closed else { return }
                    self.metrics.error = self.resolver == nil ? "名前解決に失敗（別経路へ切り替えません）" : "AdGuard DoHで拒否、または名前解決に失敗"
                    self.onDiagnostic(self.metrics.error!)
                    self.reject(SocksHandshake.connectReply(4))
                }
            }
        }
    }

    private func connect(host: String, port: UInt16, initialData: Data, remaining: [String] = []) {
        guard IPv4Address(host) != nil || IPv6Address(host) != nil else {
            metrics.error = "上流へ渡せるのは名前解決済みのIPアドレスだけです"
            onDiagnostic(metrics.error!); reject(SocksHandshake.connectReply(4)); return
        }
        checkingRoute = false
        onDiagnostic("SOCKS5認証済み・上流TCP接続中")
        let remote = RelayDirectTCP(host: host, port: port, queue: queue)
        metrics.transport = remote.transportDescription
        upstream = remote
        remote.stateUpdateHandler = { [weak self] state in
            guard let self, !self.closed, !self.responding, self.upstream === remote else { return }
            switch state {
            case .ready:
                guard !self.established, !self.checkingRoute else { return }
                self.checkingRoute = true
                self.metrics.state = "上流の経路確認中"
                self.onUpdate(self.metrics)
                self.inspectRoute(remote, self.queue) { [weak self, weak remote] report in
                    guard let self, let remote, !self.closed, !self.responding, self.upstream === remote else { return }
                    self.metrics.proxyConfigured = report?.configured
                    self.metrics.usedProxy = report?.used
                    self.metrics.proxyEndpoint = report?.endpoint
                    guard report?.used == false else {
                        self.metrics.error = report == nil ? "上流の接続先・経路を確認できないため接続を拒否" : "OSプロキシへの切替を拒否"
                        self.onDiagnostic(self.metrics.error!)
                        self.reject(SocksHandshake.connectReply(2))
                        return
                    }
                    self.establish(remote, initialData: initialData)
                }
            case .failed(let error), .waiting(let error):
                if !self.established, let next = remaining.first {
                    remote.stateUpdateHandler = nil
                    remote.cancel()
                    self.connect(host: next, port: port, initialData: initialData, remaining: Array(remaining.dropFirst()))
                    return
                }
                self.report("上流TCP接続失敗", error: error)
                if self.established { self.close() } else { self.reject(SocksHandshake.connectReply(1)) }
            case .cancelled: self.close()
            default: break
            }
        }
        remote.start()
    }

    private func establish(_ remote: RelayDirectTCP, initialData: Data) {
        guard !closed, !responding, upstream === remote, !established else { return }
        established = true
        self.client.send(content: SocksHandshake.connectReply(0),
                         completion: .contentProcessed { [weak self] error in
            guard let self, !self.closed else { return }
            if let error {
                self.report("SOCKS5成功応答の送信失敗", error: error)
                self.close()
                return
            }
            self.onDiagnostic("SOCKS5トンネル確立")
            self.onOpened()
            self.metrics.state = "接続済み"
            self.onUpdate(self.metrics)
            self.pump(.upstream(remote), to: .client(self.client))
            if initialData.isEmpty {
                self.pump(.client(self.client), to: .upstream(remote))
            } else {
                remote.send(initialData) { [weak self] error in
                    guard let self, !self.closed else { return }
                    if let error {
                        self.report("先行データ送信失敗", error: error)
                        self.close()
                    } else {
                        self.metrics.sent += Int64(initialData.count)
                        self.onUpdate(self.metrics)
                        self.pump(.client(self.client), to: .upstream(remote))
                    }
                }
            }
        })
    }

    private func report(_ stage: String, error: NWError) {
        let code: String
        switch error {
        case .posix(let value): code = "POSIX \(value.rawValue)"
        case .dns(let value): code = "DNS \(value)"
        case .tls(let value): code = "TLS \(value)"
        default: code = "NWError"
        }
        onDiagnostic("\(stage) [\(code)]")
        metrics.error = "\(stage) [\(code)]"
    }

    private enum Peer {
        case client(NWConnection), upstream(RelayDirectTCP)
        var isClient: Bool { if case .client = self { return true }; return false }
        func receive(_ completion: @escaping (Data?, Bool, NWError?) -> Void) {
            switch self {
            case .client(let stream): stream.receive(minimumIncompleteLength: 1, maximumLength: 65536) { data, _, complete, error in completion(data, complete, error) }
            case .upstream(let stream): stream.receive(maximumLength: 65536, completion: completion)
            }
        }
        func send(_ data: Data?, final: Bool = false, completion: @escaping (NWError?) -> Void) {
            switch self {
            case .client(let stream): stream.send(content: data, contentContext: final ? .finalMessage : .defaultMessage, isComplete: true, completion: .contentProcessed(completion))
            case .upstream(let stream): stream.send(data, final: final, completion: completion)
            }
        }
    }

    private func pump(_ source: Peer, to destination: Peer) {
        guard !closed else { return }
        source.receive {
            [weak self] data, complete, error in
            guard let self, !self.closed else { return }
            if let error {
                self.report(source.isClient ? "WebViewからの受信失敗" : "上流からの受信失敗", error: error)
                self.close()
                return
            }
            if let data, !data.isEmpty {
                destination.send(data) { [weak self] error in
                    guard let self, !self.closed else { return }
                    if let error {
                        self.report(destination.isClient ? "WebViewへの送信失敗" : "上流への送信失敗", error: error)
                        self.close()
                    } else {
                        if source.isClient { self.metrics.sent += Int64(data.count) }
                        else { self.metrics.received += Int64(data.count) }
                        self.onUpdate(self.metrics)
                        if complete { self.forwardEnd(to: destination) }
                        else { self.pump(source, to: destination) }
                    }
                }
            } else if complete {
                self.forwardEnd(to: destination)
            } else {
                self.pump(source, to: destination)
            }
        }
    }

    private func forwardEnd(to destination: Peer) {
        destination.send(nil, final: true) { [weak self] error in
            guard let self, !self.closed else { return }
            if let error { self.report("TCP終了の送信失敗", error: error); self.close(); return }
            self.endedDirections += 1
            if self.endedDirections == 2 { self.close() }
        }
    }

    private func reject(_ reply: Data) {
        guard !closed, !responding else { return }
        if established || reply.isEmpty { close(); return }
        responding = true
        upstream?.stateUpdateHandler = nil
        upstream?.cancel()
        client.send(content: reply, completion: .contentProcessed { [weak self] _ in self?.close() })
    }

    func close() {
        guard !closed else { return }
        closed = true
        resolutionTask?.cancel()
        metrics.closed = true
        metrics.state = metrics.error == nil ? "終了" : "エラー"
        onUpdate(metrics)
        client.stateUpdateHandler = nil
        upstream?.stateUpdateHandler = nil
        client.cancel()
        upstream?.cancel()
        onClose()
    }
}
#endif
