import Foundation

enum BrowserPhraseConverter {
    private struct Phrase {
        let cost: Int
        let pieces: [[String]]
        var text: String { pieces.map { $0[0] }.joined() }
    }
    private static let kanaConnectors: Set<String> = [
        "は", "が", "を", "に", "で", "と", "も", "の", "へ", "や", "ね", "よ",
        "から", "まで", "より", "です", "でした", "ます", "ました", "ません",
        "する", "した", "して", "します", "しない", "ない", "だった"
    ]

    static func candidates(for reading: String, dictionary: [String: [String]]) -> [String] {
        let characters = Array(reading)
        let count = characters.count
        guard (1...128).contains(count) else { return [] }
        if let exact = dictionary[reading], !exact.isEmpty { return Array(exact.prefix(12)) }

        var paths = Array(repeating: [Phrase](), count: count + 1)
        paths[count] = [Phrase(cost: 0, pieces: [])]
        // shortcut: no POS/connection costs; prefer fewer dictionary words and kana particles. Upgrade for contextual ranking.
        for start in stride(from: count - 1, through: 0, by: -1) {
            let literal = [String(characters[start])]
            var options = paths[start + 1].map { Phrase(cost: 30 + $0.cost, pieces: [literal] + $0.pieces) }
            for length in 1...min(32, count - start) {
                let end = start + length
                let part = String(characters[start..<end])
                let words: [String]
                let cost: Int
                if kanaConnectors.contains(part) { words = [part]; cost = 4 }
                else if length >= 2, let matches = dictionary[part], !matches.isEmpty {
                    words = Array(matches.prefix(12)); cost = 10
                } else { continue }
                let values = words.contains(part) ? words : words + [part]
                options += paths[end].map { Phrase(cost: cost + $0.cost, pieces: [values] + $0.pieces) }
            }
            let ranked = options.enumerated().sorted {
                if $0.element.cost != $1.element.cost { return $0.element.cost < $1.element.cost }
                return $0.offset > $1.offset
            }
            var seen: Set<String> = []
            for option in ranked where seen.insert(option.element.text).inserted {
                paths[start].append(option.element)
                if paths[start].count == 3 { break }
            }
        }

        var result = paths[0].map(\.text)
        // shortcut: vary one segment at a time, cap at 24 phrases instead of multiplying every combination.
        for rank in 1...12 {
            for path in paths[0] {
                for index in path.pieces.indices where rank < path.pieces[index].count {
                    var alternative = path.pieces.map { $0[0] }
                    alternative[index] = path.pieces[index][rank]
                    let value = alternative.joined()
                    if !result.contains(value) { result.append(value) }
                    if result.count == 24 { return result }
                }
            }
        }
        return result
    }
}
