import SwiftUI
import WebKit

@available(iOS 17.0, *)
enum BitTheme {
    static let names = ["blue", "purple", "green", "orange", "pink", "teal"]
    static func color(_ name: String) -> Color {
        switch name {
        case "purple": return .purple
        case "green": return .green
        case "orange": return .orange
        case "pink": return .pink
        case "teal": return .teal
        default: return .blue
        }
    }
}

@available(iOS 17.0, *)
struct ThemeEditorScreen: View {
    @AppStorage("bb.theme.accent") private var accent = "blue"
    @AppStorage("bb.theme.dark") private var dark = true
    @AppStorage("bb.theme.opacity") private var opacity = 0.94
    @AppStorage("bb.theme.corner") private var corners = 21.0
    var body: some View {
        Form {
            Section("外観") {
                Toggle("ダークモード", isOn: $dark)
                HStack {
                    Text("アクセントカラー")
                    Spacer()
                    ForEach(BitTheme.names, id: \.self) { name in
                        Button { accent = name } label: {
                            Circle().fill(BitTheme.color(name))
                                .frame(width: 28, height: 28)
                                .overlay { if accent == name { Image(systemName: "checkmark").font(.caption.bold()).foregroundStyle(.white) } }
                        }.buttonStyle(.plain).accessibilityLabel(name)
                    }
                }
            }
            Section("パネル") {
                VStack(alignment: .leading) {
                    Text("サイドバーの不透明度: \(Int(opacity * 100))%")
                    Slider(value: $opacity, in: 0.55...1.0)
                }
                VStack(alignment: .leading) {
                    Text("ホームアイコンの角丸: \(Int(corners))")
                    Slider(value: $corners, in: 8...35, step: 1)
                }
            }
            Section {
                Button("初期設定に戻す") { accent = "blue"; dark = true; opacity = 0.94; corners = 21 }
            }
        }
        .navigationTitle("テーマエディター")
    }
}

@available(iOS 17.0, *)
struct RemoteDesktopScreen: View {
    @AppStorage("bb.remote.url") private var savedURL = ""
    @State private var draftURL = ""
    @State private var activeURL: URL?
    @State private var error: String?
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "desktopcomputer")
                TextField("https://example.com/guacamole/", text: $draftURL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .textFieldStyle(.roundedBorder)
                Button("接続") { connect() }.buttonStyle(.borderedProminent)
                if activeURL != nil { Button("閉じる") { activeURL = nil } }
            }
            .padding(12)
            if let error { Text(error).font(.caption).foregroundStyle(.red).padding(.horizontal) }
            if let activeURL {
                GuacamoleWebView(url: activeURL)
                    .id(activeURL.absoluteString)
            } else {
                ContentUnavailableView("RDPリモートデスクトップ", systemImage: "desktopcomputer", description: Text("GuacamoleのHTTPSアドレスを入力して接続。WindowsのRDPポートを直接公開する必要はありません。"))
            }
        }
        .onAppear { if draftURL.isEmpty { draftURL = savedURL } }
    }
    private func connect() {
        let value = draftURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: value), url.scheme?.lowercased() == "https", url.host != nil else {
            error = "HTTPSのURLを入力してください（例: https://example.com/guacamole/）"
            return
        }
        savedURL = value
        error = nil
        activeURL = url
    }
}

@available(iOS 17.0, *)
private struct GuacamoleWebView: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        let view = WKWebView(frame: .zero, configuration: config)
        view.allowsBackForwardNavigationGestures = false
        view.scrollView.contentInsetAdjustmentBehavior = .never
        view.load(URLRequest(url: url))
        return view
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
