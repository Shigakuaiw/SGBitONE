import Foundation

enum BrowserKeyboardSize: String, Codable, CaseIterable {
    case minimum, standard
    var title: String { self == .minimum ? "ミニマム" : "スタンダード" }
}

struct BrowserKeyboardKey {
    let value: String
    var units: CGFloat = 1
}

struct BrowserShiftState {
    private(set) var active = false
    private(set) var locked = false
    private var lastTap: TimeInterval?

    mutating func tap(at time: TimeInterval) {
        if locked { active = false; locked = false; lastTap = nil; return }
        if active, let previous = lastTap, (0...0.35).contains(time - previous) {
            locked = true; lastTap = nil; return
        }
        active.toggle()
        lastTap = active ? time : nil
    }

    mutating func interruptTapSequence() { lastTap = nil }
    mutating func didType() { if !locked { active = false }; lastTap = nil }
}

enum BrowserKeyboardLayout {
    static let gap: CGFloat = 3
    static let rows: [[BrowserKeyboardKey]] = makeRows()
    static let shifted: [Character: Character] = makeShifted()

    private static func makeRows() -> [[BrowserKeyboardKey]] {
        var numbers: [BrowserKeyboardKey] = "1234567890-^¥".map { BrowserKeyboardKey(value: String($0)) }
        numbers.insert(BrowserKeyboardKey(value: "halfFull"), at: 0)
        numbers.append(BrowserKeyboardKey(value: "delete"))
        var top: [BrowserKeyboardKey] = "qwertyuiop@[".map { BrowserKeyboardKey(value: String($0)) }
        top.insert(BrowserKeyboardKey(value: "tab", units: 1.5), at: 0)
        top.append(BrowserKeyboardKey(value: "enter", units: 1.5))
        var home: [BrowserKeyboardKey] = "asdfghjkl;:]".map { BrowserKeyboardKey(value: String($0)) }
        home.insert(BrowserKeyboardKey(value: "caps", units: 1.75), at: 0)
        home.append(BrowserKeyboardKey(value: "enterTail", units: 1.25))
        var bottom: [BrowserKeyboardKey] = "zxcvbnm,./\\".map { BrowserKeyboardKey(value: String($0)) }
        bottom.insert(BrowserKeyboardKey(value: "shift", units: 2.25), at: 0)
        bottom.append(BrowserKeyboardKey(value: "shift", units: 1.75))
        let controls: [BrowserKeyboardKey] = [
            BrowserKeyboardKey(value: "paste", units: 2), BrowserKeyboardKey(value: "selectAll", units: 2),
            BrowserKeyboardKey(value: "space", units: 7), BrowserKeyboardKey(value: "left", units: 2),
            BrowserKeyboardKey(value: "right", units: 2)
        ]
        return [numbers, top, home, bottom, controls]
    }

    private static func makeShifted() -> [Character: Character] {
        let plain: [Character] = Array("123456789-^¥@[;:],./\\")
        let upper: [Character] = Array("!\"#$%&'()=~|`{+*}<>?_")
        var result: [Character: Character] = [:]
        for index in plain.indices { result[plain[index]] = upper[index] }
        return result
    }

    static func label(_ value: String, upper: Bool) -> String {
        guard upper else { return value }
        if value.count == 1, let first = value.first, let shifted = shifted[first] { return String(shifted) }
        return value.uppercased()
    }

    static func widths(for row: [BrowserKeyboardKey], available: CGFloat, squareSide: CGFloat? = nil) -> [CGFloat] {
        if let side = squareSide {
            return row.map { $0.units * side + ($0.units - 1) * gap }
        }
        let space = max(0, available - CGFloat(row.count - 1) * gap)
        let total = row.reduce(CGFloat(0)) { $0 + $1.units }
        return row.map { space * $0.units / total }
    }

    static func height(available: CGFloat) -> CGFloat { min(352, max(0, available - 80)) }

    static func height(available: CGFloat, width: CGFloat, size: BrowserKeyboardSize) -> CGFloat {
        if size == .minimum { return height(available: available) }
        let maximum: CGFloat = max(0, available - 80)
        let overhead: CGFloat = 12 + 3 * 28 + 7 * gap
        let widthSide: CGFloat = max(0, (width - 12 - 14 * gap) / 15)
        let heightSide: CGFloat = max(0, (maximum - overhead) / 5)
        return min(maximum, overhead + 5 * min(widthSide, heightSide))
    }
}
