import Foundation
import SwiftUI
import Security

@MainActor
final class ONEAccount: ObservableObject {
    static let shared = ONEAccount()
    @Published private(set) var username = ""
    @Published private(set) var userID = ""
    @Published private(set) var blocked = false
    @Published private(set) var signedIn = false
    @Published var errorMessage = ""
    @Published var working = false

    // Keep the account API and the /status endpoint on the same Worker.
    // The two known Worker hostnames can be selected from Account settings.
    static let defaultHost = "sgbit-one-control.gakushisama.workers.dev"
    static let alternateHost = "one-control.gakushisama.workers.dev"
    private var base: URL {
        let name = UserDefaults.standard.string(forKey: "sgbit.worker.host") ?? Self.defaultHost
        let host = [Self.defaultHost, Self.alternateHost].contains(name) ? name : Self.defaultHost
        return URL(string: "https://\(host)")!
    }
    var workerHost: String {
        UserDefaults.standard.string(forKey: "sgbit.worker.host") ?? Self.defaultHost
    }

    func selectWorker(_ host: String) {
        guard [Self.defaultHost, Self.alternateHost].contains(host), host != workerHost else { return }
        saveToken(nil)
        username = ""; userID = ""; blocked = false; signedIn = false; errorMessage = ""
        UserDefaults.standard.set(host, forKey: "sgbit.worker.host")
        UserDefaults.standard.set("https://\(host)/status", forKey: "sgbit.control.url")
        // Changing servers requires a new login: old sessions must not travel between hosts.
    }

    func fileAPI(_ path: String, query: [URLQueryItem] = []) async throws -> (Data, HTTPURLResponse) {
        guard !blocked else { throw ONEAccountError.message("ACCOUNT_BLOCKED") }
        guard let token else { throw ONEAccountError.message("LOGIN_REQUIRED") }
        var components = URLComponents(url: base.appendingPathComponent(path), resolvingAgainstBaseURL: false)!
        if !query.isEmpty { components.queryItems = query }
        guard let url = components.url else { throw ONEAccountError.message("URLが不正です") }
        var req = URLRequest(url: url)
        req.timeoutInterval = 60
        req.cachePolicy = .reloadIgnoringLocalCacheData
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw ONEAccountError.message("サーバー応答が不正です") }
        guard (200...299).contains(http.statusCode) else {
            let detail = (try? JSONDecoder().decode(ServerError.self, from: data))?.error ?? "HTTP \(http.statusCode)"
            if detail == "ACCOUNT_BLOCKED" { blocked = true }
            if detail == "LOGIN_REQUIRED" { errorMessage = "ログイン期限が切れました。再ログインしてください" }
            throw ONEAccountError.message(detail)
        }
        return (data, http)
    }

    private let service = "net.sgbit.one.session"
    private let account = "user-token"

    private init() {
        signedIn = token != nil
    }

    private var token: String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: account,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func saveToken(_ value: String?) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
        guard let value else { return }
        var attrs = query
        attrs[kSecValueData as String] = Data(value.utf8)
        attrs[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(attrs as CFDictionary, nil)
    }

    private struct ServerError: Decodable { let error: String? }
    private struct User: Decodable { let id: String; let username: String; let blocked: Bool }
    private struct Login: Decodable { let token: String; let user: User }
    private struct Me: Decodable { let user: User }
    private struct RegisterResult: Decodable { let ok: Bool }
    private struct LaunchResult: Decodable { let ok: Bool }
    private struct PreferenceResult: Decodable { let ok: Bool }

    private func request<T: Decodable>(_ path: String, method: String = "GET", payload: [String: Any]? = nil, auth: Bool = false) async throws -> T {
        var request = URLRequest(url: base.appendingPathComponent(path))
        request.httpMethod = method
        request.timeoutInterval = 12
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let payload {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        if auth {
            guard let token else { throw ONEAccountError.message("ログインが必要です") }
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard data.count < 65536, let code = (response as? HTTPURLResponse)?.statusCode else { throw ONEAccountError.message("サーバー応答が不正です") }
        if !(200...299).contains(code) {
            let detail = (try? JSONDecoder().decode(ServerError.self, from: data))?.error ?? "HTTP \(code)"
            if detail == "ACCOUNT_BLOCKED" { blocked = true }
            throw ONEAccountError.message(detail)
        }
        return try JSONDecoder().decode(T.self, from: data)
    }

    private func adopt(_ user: User) {
        username = user.username
        userID = user.id
        blocked = user.blocked
        signedIn = true
    }

    func signUp(username: String, password: String) async -> Bool {
        guard !working else { return false }
        working = true; errorMessage = ""
        defer { working = false }
        do {
            let _: RegisterResult = try await request("api/register", method: "POST", payload: ["username": username, "password": password])
            return try await loginBody(username: username, password: password)
        } catch { errorMessage = error.localizedDescription; return false }
    }

    func signIn(username: String, password: String) async -> Bool {
        guard !working else { return false }
        working = true; errorMessage = ""
        defer { working = false }
        do { return try await loginBody(username: username, password: password) }
        catch { errorMessage = error.localizedDescription; return false }
    }

    private func loginBody(username: String, password: String) async throws -> Bool {
        let result: Login = try await request("api/login", method: "POST", payload: ["username": username, "password": password])
        saveToken(result.token)
        adopt(result.user)
        return true
    }

    func refresh() async {
        guard token != nil else { signedIn = false; return }
        do {
            let info: Me = try await request("api/me", auth: true)
            adopt(info.user)
        } catch {
            // Do not erase offline data or log out on temporary network failures.
            if let message = error as? ONEAccountError, message.isUnauthorized {
                saveToken(nil); signedIn = false
            }
            errorMessage = error.localizedDescription
        }
    }

    func recordLaunch() async {
        guard token != nil else { return }
        do {
            let _: LaunchResult = try await request("api/launch", method: "POST", auth: true)
            blocked = false
        } catch { errorMessage = error.localizedDescription }
    }

    func updateBackup(enabled: Bool, frequency: String) async {
        guard token != nil, !blocked else { return }
        do {
            let _: PreferenceResult = try await request("api/preferences", method: "PUT", payload: ["backupEnabled": enabled, "backupFrequency": frequency], auth: true)
        } catch { errorMessage = error.localizedDescription }
    }

    func signOut() async {
        if token != nil { let _: PreferenceResult? = try? await request("api/logout", method: "POST", auth: true) }
        saveToken(nil); username = ""; userID = ""; blocked = false; signedIn = false
    }
}

private enum ONEAccountError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
    var isUnauthorized: Bool { if case .message(let text) = self { return text == "LOGIN_REQUIRED" }; return false }
}

@available(iOS 17.0, *)
struct ONEAccountSettings: View {
    @ObservedObject private var user = ONEAccount.shared
    @AppStorage("sgbit.setup.complete") private var setupComplete = false
    @State private var confirmLogout = false
    @State private var selectedHost = ONEAccount.shared.workerHost
    var body: some View {
        Form {
            Section("サーバーアカウント") {
                LabeledContent("ユーザー名", value: user.username.isEmpty ? "未確認" : user.username)
                LabeledContent("状態", value: user.blocked ? "オンライン利用制限中" : (user.signedIn ? "ログイン中" : "未ログイン"))
                if !user.userID.isEmpty { LabeledContent("ユーザーID", value: user.userID).font(.caption) }
                Button("ログイン状態を更新") { Task { await user.refresh() } }
                if !user.errorMessage.isEmpty { Text(user.errorMessage).font(.footnote).foregroundStyle(.secondary) }
            }
            Section("接続するCloudflare Worker") {
                Picker("接続先", selection: $selectedHost) {
                    Text("sgbit-one-control").tag(ONEAccount.defaultHost)
                    Text("one-control").tag(ONEAccount.alternateHost)
                }
                Text("管理画面をデプロイしたWorkerを選択してください。切り替えると再ログインが必要です。メンテナンス確認先も同時に変更します。")
                    .font(.footnote).foregroundStyle(.secondary)
                Button("接続先を適用") {
                    user.selectWorker(selectedHost)
                    setupComplete = false
                }
                .disabled(selectedHost == user.workerHost)
            }
            Section {
                Button("ログアウト", role: .destructive) { confirmLogout = true }
            } footer: {
                Text("ログアウトしてもこの端末の音楽・ファイル・パスワード保管庫は消去されません。")
            }
        }
        .navigationTitle("アカウント")
        .confirmationDialog("ログアウトしますか？", isPresented: $confirmLogout) {
            Button("ログアウト", role: .destructive) {
                Task { await user.signOut(); setupComplete = false }
            }
        }
    }
}
