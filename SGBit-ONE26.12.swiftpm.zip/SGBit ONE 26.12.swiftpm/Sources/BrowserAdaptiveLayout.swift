import Foundation

enum BrowserDisplayMode: String, Codable, CaseIterable {
    case automatic, desktop, mobile
    var title: String {
        switch self {
        case .automatic: return "ウィンドウ幅に合わせる"
        case .desktop: return "PC版"
        case .mobile: return "モバイル版"
        }
    }
    func usesDesktop(width: CGFloat) -> Bool {
        switch self {
        case .automatic: return !width.isFinite || width <= 0 || width >= 768
        case .desktop: return true
        case .mobile: return false
        }
    }
}

enum BrowserAdaptiveLayout {
    static func compactTabs(count: Int, width: CGFloat) -> Bool {
        guard count > 0, width.isFinite else { return false }
        return (max(0, width - 66) / CGFloat(count)) < 210
    }
}
