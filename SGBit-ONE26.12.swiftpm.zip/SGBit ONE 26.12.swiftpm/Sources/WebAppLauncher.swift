import SwiftUI

// User-created website shortcuts. Saved locally on this device only.
@available(iOS 17.0, *)
private struct ONEWebApp: Codable, Identifiable, Equatable {
    var id: UUID
    var name: String
    var url: String
}

@available(iOS 17.0, *)
struct ONEAppsScreen: View {
    let openChappy: () -> Void
    let openWebsite: (URL) -> Void
    @AppStorage("sgbit.one.webapps.v1") private var storedApps = "[]"
    @AppStorage("bb.theme.dark") private var darkTheme = true
    @State private var adding = false
    @State private var newName = ""
    @State private var newAddress = ""
    @State private var errorText: String?

    private var apps: [ONEWebApp] {
        guard let data = storedApps.data(using: .utf8) else { return [] }
        return (try? JSONDecoder().decode([ONEWebApp].self, from: data)) ?? []
    }

    private func persist(_ updated: [ONEWebApp]) {
        guard let data = try? JSONEncoder().encode(updated),
              let json = String(data: data, encoding: .utf8) else { return }
        storedApps = json
    }

    private func validatedURL(_ raw: String) -> URL? {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let address = trimmed.contains("://") ? trimmed : "https://" + trimmed
        guard let components = URLComponents(string: address),
              let scheme = components.scheme?.lowercased(),
              ["https", "http"].contains(scheme),
              let host = components.host, host.contains("."),
              let url = components.url else { return nil }
        return url
    }

    private func save() {
        let name = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { errorText = "アプリ名を入力してね"; return }
        guard let url = validatedURL(newAddress) else {
            errorText = "有効なWebサイトのURLを入力してね（https://example.com）"
            return
        }
        var updated = apps
        updated.append(ONEWebApp(id: UUID(), name: String(name.prefix(40)), url: url.absoluteString))
        persist(updated)
        adding = false
        newName = ""
        newAddress = ""
        errorText = nil
    }

    private func remove(_ id: UUID) {
        persist(apps.filter { $0.id != id })
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 124, maximum: 190), spacing: 20)], spacing: 24) {
                    Button(action: openChappy) {
                        appTile(name: "チャッピー", symbol: "sparkles", colors: [.teal, .blue])
                    }
                    .buttonStyle(.plain)
                    ForEach(apps) { app in
                        Button {
                            if let url = validatedURL(app.url) { openWebsite(url) }
                        } label: {
                            appTile(name: app.name, symbol: "globe", colors: [.indigo, .purple])
                        }
                        .buttonStyle(.plain)
                        .contextMenu {
                            Button("ブラウザで開く", systemImage: "globe") {
                                if let url = validatedURL(app.url) { openWebsite(url) }
                            }
                            Button("アプリを削除", systemImage: "trash", role: .destructive) { remove(app.id) }
                        }
                    }
                    Button { adding = true } label: {
                        appTile(name: "アプリを追加", symbol: "plus", colors: [.gray, .gray])
                    }
                    .buttonStyle(.plain)
                }
                .padding(24)
                Text("Webアプリを長押しすると削除できます。登録内容はこの端末内に保存されます。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 24)
            }
            .navigationTitle("アプリ")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("追加", systemImage: "plus") { adding = true }
                }
            }
            .sheet(isPresented: $adding) {
                NavigationStack {
                    Form {
                        Section("Webアプリを追加") {
                            TextField("名前（例：YouTube）", text: $newName)
                                .textInputAutocapitalization(.never)
                            TextField("URL（例：youtube.com）", text: $newAddress)
                                .keyboardType(.URL)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                        }
                        Section {
                            Text("登録したWebサイトは、SGBit ONEのブラウザで開きます。ネイティブアプリのインストールではありません。")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .navigationTitle("アプリを追加")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("キャンセル") { adding = false; errorText = nil }
                        }
                        ToolbarItem(placement: .confirmationAction) { Button("保存", action: save) }
                    }
                    .alert("登録できません", isPresented: Binding(
                        get: { errorText != nil },
                        set: { if !$0 { errorText = nil } }
                    )) { Button("OK", role: .cancel) { errorText = nil } } message: {
                        Text(errorText ?? "")
                    }
                }
            }
        }
    }

    private func appTile(name: String, symbol: String, colors: [Color]) -> some View {
        VStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 34, weight: .medium))
                .foregroundStyle(.white)
                .frame(width: 82, height: 82)
                .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing),
                            in: RoundedRectangle(cornerRadius: 20))
            Text(name)
                .font(.subheadline.weight(.medium))
                .lineLimit(2)
                .multilineTextAlignment(.center)
                .foregroundStyle(.primary)
        }
        .frame(maxWidth: .infinity)
        .contentShape(Rectangle())
    }
}
