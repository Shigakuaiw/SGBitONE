import SwiftUI
import WebKit
import Network

@MainActor
final class RelayBrowserModel: ObservableObject {
    static let userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0.1 Safari/605.1.15"
    static let defaultHomeAddress = "https://google.com"
    @Published private(set) var tabs: [BrowserTab] = []
    @Published private(set) var selectedID: UUID?
    @Published private(set) var proxyPort: UInt16?
    @Published private(set) var relayStatus = "ローカル中継を起動中…"
    @Published private(set) var tunnelCount = 0
    @Published private(set) var proxyDiagnostic = "WebView未接続"
    @Published private(set) var homeAddress: String
    @Published private(set) var isClearingData = false
    @Published private(set) var settingsMessage = ""
    @Published var fullScreen = false
    private(set) var isSceneActive = true

    let dataStore: WKWebsiteDataStore
    let preferences: BrowserPreferences
    let library: BrowserLibrary
    let security: BrowserSecurity
    let downloads: BrowserDownloads
    let monitor = BrowserNetworkMonitor()
    private(set) var privateDataStore = WKWebsiteDataStore.nonPersistent()
    private(set) var iconSession: URLSession?
    private var privateIconSession: URLSession?
    private let relay = LoopbackRelay()
    private let credentials = ProxyCredentials()
    private let privateCredentials = ProxyCredentials(isPrivate: true)
    private var dnsResolver: AdGuardDNSResolver?
    private var started = false
    private var generation = 0
    private var wasBackgrounded = false
    private var restored = false
    private var restoring = false
    private var reloadAfterStart: UUID?
    private var lastDNSSetting: Bool
    private let defaults: UserDefaults
    private let tabDragToken = UUID().uuidString
    private(set) var viewportWidth: CGFloat = 0

    func updateViewport(width: CGFloat) {
        guard width.isFinite, width > 0 else { return }
        viewportWidth = width
        for tab in tabs { tab.updateAutomaticDesktop(width: width) }
    }

    init(defaults: UserDefaults = .standard, dataStore: WKWebsiteDataStore? = nil,
         library: BrowserLibrary? = nil, security: BrowserSecurity? = nil, downloads: BrowserDownloads? = nil) {
        self.defaults = defaults
        self.dataStore = dataStore ?? .default()
        self.library = library ?? BrowserLibrary()
        self.security = security ?? BrowserSecurity()
        self.downloads = downloads ?? BrowserDownloads()
        preferences = BrowserPreferences(defaults: defaults)
        lastDNSSetting = preferences.state.adGuardDNS
        let stored = defaults.string(forKey: "RelayBrowser.homeAddress") ?? Self.defaultHomeAddress
        homeAddress = BrowserAddress.url(for: stored, search: false)?.absoluteString ?? Self.defaultHomeAddress
        preferences.didChange = { [weak self] in self?.preferencesChanged() }
    }

    var selectedTab: BrowserTab? { tabs.first { $0.id == selectedID } }

    func start() {
        guard !started, !security.locked, !isClearingData else { return }
        guard #available(iOS 17.0, *) else { relayStatus = "iOS / iPadOS 17以降が必要です"; return }
        started = true
        wasBackgrounded = false
        generation += 1
        let generation = generation
        relayStatus = "中継を起動中"
        proxyDiagnostic = "WebView接続待ち"
        relay.start(credentials: credentials, onTunnelOpened: { [weak self] in
            guard let self, self.started, self.generation == generation else { return }
            self.tunnelCount += 1
        }, onDiagnostic: { [weak self] message in
            guard let self, self.started, self.generation == generation else { return }
            self.proxyDiagnostic = message
        }, privateCredentials: privateCredentials, onMonitor: { [weak self] value in
            guard let self, self.started, self.generation == generation else { return }
            var value = value
            if !self.tabs.contains(where: \.isPrivate) { value.connections.removeAll(where: \.isPrivate) }
            self.monitor.update(value)
        }) { [weak self] result in
            guard let self, self.started, self.generation == generation else { return }
            switch result {
            case .success(let port):
                let proxy = self.makeProxy(port: port, credentials: self.credentials)
                self.iconSession?.invalidateAndCancel()
                self.iconSession = self.makeSession(proxy: proxy)
                if self.preferences.state.adGuardDNS, let session = self.iconSession {
                    self.dnsResolver = AdGuardDNSResolver(session: session)
                } else { self.dnsResolver = nil }
                self.relay.setResolver(self.dnsResolver) { [weak self] in
                    guard let self, self.started, self.generation == generation, !self.security.locked else { return }
                    self.dataStore.proxyConfigurations = [proxy]
                    self.configurePrivateStore(port: port)
                    self.proxyPort = port
                    self.relayStatus = "中継接続中"
                    if self.tabs.isEmpty { self.openInitialTabs() }
                    if let id = self.reloadAfterStart, let tab = self.tabs.first(where: { $0.id == id }) { self.reload(tab) }
                    self.reloadAfterStart = nil
                }
            case .failure(let error):
                self.started = false
                self.proxyPort = nil
                self.tabs.forEach { $0.interruptLoading() }
                self.invalidateSessions()
                self.relayStatus = "中継エラー: \(error.localizedDescription)"
            }
        }
    }

    @available(iOS 17.0, *)
    private func makeProxy(port: UInt16, credentials: ProxyCredentials) -> ProxyConfiguration {
        var proxy = ProxyConfiguration(socksv5Proxy: .hostPort(host: "127.0.0.1", port: NWEndpoint.Port(rawValue: port)!))
        proxy.allowFailover = false
        proxy.applyCredential(username: credentials.username, password: credentials.password)
        return proxy
    }

    @available(iOS 17.0, *)
    private func makeSession(proxy: ProxyConfiguration) -> URLSession {
        let config = URLSessionConfiguration.ephemeral
        config.proxyConfigurations = [proxy]
        config.httpCookieStorage = nil
        config.urlCredentialStorage = nil
        config.urlCache = nil
        config.timeoutIntervalForRequest = 8
        config.timeoutIntervalForResource = 10
        config.httpAdditionalHeaders = ["User-Agent": Self.userAgent]
        return URLSession(configuration: config, delegate: IconRedirectPolicy(), delegateQueue: nil)
    }

    @available(iOS 17.0, *)
    private func configurePrivateStore(port: UInt16) {
        let proxy = makeProxy(port: port, credentials: privateCredentials)
        privateDataStore.proxyConfigurations = [proxy]
        privateIconSession?.invalidateAndCancel()
        privateIconSession = makeSession(proxy: proxy)
    }

    func sessionForIcons(privateTab: Bool) -> URLSession? { privateTab ? privateIconSession : iconSession }

    private func invalidateSessions() {
        iconSession?.invalidateAndCancel(); iconSession = nil
        privateIconSession?.invalidateAndCancel(); privateIconSession = nil
        dnsResolver = nil
    }

    func sceneChanged(_ phase: ScenePhase) {
        isSceneActive = phase == .active
        if !isSceneActive { cancelDialogs() }
        if phase == .background {
            persistSession()
            wasBackgrounded = true
            security.lock()
            if security.locked { suspendRelay() }
        }
        if phase == .active && !security.locked {
            if wasBackgrounded { wasBackgrounded = false; restartRelay() }
            else { start() }
        }
    }

    private func suspendRelay() {
        started = false
        generation += 1
        proxyPort = nil
        tabs.forEach { $0.interruptLoading() }
        invalidateSessions()
        relay.stop()
    }

    func restartRelay() { suspendRelay(); start() }

    private func openInitialTabs() {
        if !restored, preferences.state.restoreTabs, !library.savedTabs.isEmpty {
            restoring = true
            for saved in library.savedTabs { _ = newTab(restoring: saved) }
            if !tabs.isEmpty { selectedID = tabs[min(max(0, library.savedSelection), tabs.count - 1)].id }
            restoring = false
            selectedTab?.loadPendingRestore()
        } else {
            newTab()
            if let tab = selectedTab { tab.address = homeAddress; openAddress(in: tab) }
        }
        restored = true
    }

    @discardableResult
    func newTab(configuration: WKWebViewConfiguration? = nil, isPrivate: Bool = false,
                desktop: Bool? = nil, displayMode: BrowserDisplayMode? = nil, restoring saved: SavedBrowserTab? = nil) -> BrowserTab? {
        guard let port = proxyPort, !isClearingData, !security.locked else { return nil }
        if isPrivate, privateIconSession == nil, #available(iOS 17.0, *) { configurePrivateStore(port: port) }
        let config = configuration ?? WKWebViewConfiguration()
        config.websiteDataStore = isPrivate ? privateDataStore : dataStore
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        let mode: BrowserDisplayMode
        if let saved { mode = saved.displayMode ?? .automatic }
        else if let displayMode { mode = displayMode }
        else if let desktop { mode = desktop ? .desktop : .mobile }
        else { mode = selectedTab?.displayMode ?? .automatic }
        let tab = BrowserTab(configuration: config, browser: self, isPrivate: isPrivate,
                             desktop: mode.usesDesktop(width: viewportWidth), displayMode: mode, restoring: saved)
        tabs.append(tab)
        select(tab.id)
        persistSession()
        return tab
    }

    func select(_ id: UUID) {
        guard tabs.contains(where: { $0.id == id }) else { return }
        if selectedID != id {
            selectedTab?.dialogs.cancel()
            selectedTab?.pageInput.cancelPending()
            selectedTab?.webView.endEditing(true)
        }
        selectedID = id
        selectedTab?.barsHidden = false
        if !restoring { selectedTab?.loadPendingRestore() }
        persistSession()
    }

    func cancelDialogs() { tabs.forEach { $0.dialogs.cancel() } }

    func tabDragData(for id: UUID) -> Data? {
        guard !security.locked, !isClearingData, tabs.contains(where: { $0.id == id }) else { return nil }
        return Data("\(tabDragToken):\(id.uuidString)".utf8)
    }

    @discardableResult
    func acceptTabDrop(_ data: Data, onto target: UUID) -> Bool {
        guard data.count == 73, let value = String(data: data, encoding: .utf8) else { return false }
        let parts = value.split(separator: ":", omittingEmptySubsequences: false)
        guard parts.count == 2, parts[0] == tabDragToken, let id = UUID(uuidString: String(parts[1])) else { return false }
        return moveTab(id, onto: target)
    }

    @discardableResult
    func moveTab(_ id: UUID, onto target: UUID) -> Bool {
        guard !security.locked, !isClearingData, id != target,
              let source = tabs.firstIndex(where: { $0.id == id }),
              let destination = tabs.firstIndex(where: { $0.id == target }) else { return false }
        var reordered = tabs
        let tab = reordered.remove(at: source)
        reordered.insert(tab, at: destination)
        tabs = reordered
        persistSession()
        return true
    }

    func moveTab(_ id: UUID, by offset: Int) {
        guard offset == -1 || offset == 1, let index = tabs.firstIndex(where: { $0.id == id }),
              tabs.indices.contains(index + offset) else { return }
        moveTab(id, onto: tabs[index + offset].id)
    }

    func close(_ id: UUID) {
        guard let index = tabs.firstIndex(where: { $0.id == id }) else { return }
        let tab = tabs.remove(at: index)
        tab.dispose()
        if selectedID == id { selectedID = tabs.isEmpty ? nil : tabs[min(index, tabs.count - 1)].id }
        if tab.isPrivate && !tabs.contains(where: \.isPrivate) {
            relay.closePrivateConnections()
            monitor.hidePrivateRecords()
            privateIconSession?.invalidateAndCancel(); privateIconSession = nil
            privateDataStore = .nonPersistent()
            Task { await dnsResolver?.clearCache() }
        }
        if tabs.isEmpty { newTab() }
        selectedTab?.barsHidden = false
        selectedTab?.loadPendingRestore()
        persistSession()
    }

    func openAddress(in tab: BrowserTab) {
        guard proxyPort != nil, !isClearingData, !security.locked, tabs.contains(where: { $0 === tab }) else { return }
        guard let url = BrowserAddress.url(for: tab.address) else { tab.status = "URLまたは検索語を確認してください"; return }
        tab.address = url.absoluteString
        tab.barsHidden = false
        tab.load(url)
    }

    func open(_ url: URL) {
        guard let tab = selectedTab else { return }
        tab.address = url.absoluteString
        openAddress(in: tab)
    }

    func reload(_ tab: BrowserTab) {
        guard tabs.contains(where: { $0 === tab }), !security.locked, !isClearingData else { return }
        if proxyPort == nil { reloadAfterStart = tab.id; restartRelay() }
        else if let scheme = tab.webView.url?.scheme, scheme == "https" || scheme == "http" { tab.webView.reloadFromOrigin() }
        else if !tab.address.isEmpty { openAddress(in: tab) }
    }

    func home(_ tab: BrowserTab) { tab.address = homeAddress; openAddress(in: tab) }

    func saveHomeAddress(_ value: String) -> Bool {
        guard let url = BrowserAddress.url(for: value, search: false) else {
            settingsMessage = "ホームページにはHTTP / HTTPS URLを入力してください"; return false
        }
        homeAddress = url.absoluteString
        defaults.set(homeAddress, forKey: "RelayBrowser.homeAddress")
        settingsMessage = "ホームページを保存しました"
        return true
    }

    func tabFinished(_ tab: BrowserTab) {
        guard tabs.contains(where: { $0 === tab }) else { return }
        if !tab.isPrivate, preferences.state.keepHistory, let url = tab.webView.url { library.record(title: tab.title, url: url) }
        persistSession()
    }

    func tabLocationChanged(_ tab: BrowserTab) {
        if !tab.isLoading { tabFinished(tab) }
        else { persistSession() }
    }

    func persistSession() {
        guard !restoring, !isClearingData, !security.wipePending else { return }
        let normal = tabs.filter { !$0.isPrivate }
        let records = preferences.state.restoreTabs ? normal.map {
            SavedBrowserTab(url: $0.pendingRestoreURL ?? $0.requestedURL ?? $0.webView.url.flatMap { BrowserAddress.webURL($0.absoluteString) },
                            title: $0.title, desktop: $0.desktop, displayMode: $0.displayMode)
        } : []
        library.saveSession(records, selection: normal.firstIndex(where: { $0.id == selectedID }) ?? 0)
    }

    private func preferencesChanged() {
        persistSession()
        if preferences.state.adGuardDNS != lastDNSSetting {
            lastDNSSetting = preferences.state.adGuardDNS
            if started { restartRelay() }
        }
    }

    func addCurrentBookmark() {
        guard let tab = selectedTab, let url = tab.webView.url else { return }
        library.addBookmark(title: tab.title, url: url)
    }

    func clearSiteData(host: String?) async {
        guard !isClearingData else { return }
        isClearingData = true
        defer {
            isClearingData = false
            if tabs.isEmpty { newTab() }
            persistSession()
        }
        settingsMessage = "サイトデータを削除中…"
        downloads.cancelAll()
        let stores = [dataStore, privateDataStore]
        let types = WKWebsiteDataStore.allWebsiteDataTypes()
        var groups: [(WKWebsiteDataStore, [WKWebsiteDataRecord])] = []
        for store in stores {
            let records = await store.dataRecords(ofTypes: types)
            let selected = host.map { host in records.filter { BrowserAddress.host(host, belongsTo: $0.displayName) } } ?? records
            groups.append((store, selected))
        }
        let records = groups.flatMap { $0.1 }
        let affected = tabs.filter { tab in
            guard let host else { return true }
            let hosts = [tab.webView.url?.host, tab.pendingRestoreURL?.host,
                         BrowserAddress.url(for: tab.address, search: false)?.host].compactMap { $0 }
            return hosts.contains { tabHost in
                BrowserAddress.host(tabHost, belongsTo: host) || records.contains { BrowserAddress.host(tabHost, belongsTo: $0.displayName) }
            }
        }.map(\.id)
        for id in affected { close(id) }
        for (store, records) in groups {
            if host == nil { await store.removeData(ofTypes: types, modifiedSince: .distantPast) }
            else { await store.removeData(ofTypes: types, for: records) }
        }
        settingsMessage = "Cookieとサイトデータを削除しました"
    }

    func performSecurityWipe() async {
        guard security.wipePending, !isClearingData else { return }
        suspendRelay()
        downloads.cancelAll()
        await clearSiteData(host: nil)
        relay.clearMonitor()
        monitor.clear()
        do {
            try library.eraseHistoryAndSession()
            try downloads.forgetSources()
            try security.finishWipe()
        } catch { security.reportWipeFailure(error) }
    }

    func clearMonitor() { relay.clearMonitor(); monitor.clear() }

    var inputDiagnostic: String {
        guard let window = selectedTab?.webView.window else { return "入力ウィンドウ未接続" }
        return "key=\(window.isKeyWindow), canBecomeKey=\(window.canBecomeKey)"
    }

    deinit {
        iconSession?.invalidateAndCancel()
        privateIconSession?.invalidateAndCancel()
        relay.stop()
    }
}

private final class IconRedirectPolicy: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        let url = request.url
        completionHandler(url?.scheme == "https" && url?.user == nil && url?.password == nil ? request : nil)
    }
}
