import SwiftUI

struct BrowserDialogAnswer {
    var text = ""
    var username = ""
    var password = ""
}

@MainActor
final class BrowserDialogRequest: Identifiable {
    enum Kind { case alert, confirm, prompt, authentication }
    let id = UUID()
    let kind: Kind
    let origin: String
    let message: String
    let defaultText: String
    private var completion: ((BrowserDialogAnswer?) -> Void)?
    var hasInput: Bool { kind == .prompt || kind == .authentication }

    init(kind: Kind, origin: String, message: String, defaultText: String = "",
         completion: @escaping (BrowserDialogAnswer?) -> Void) {
        self.kind = kind; self.origin = origin
        self.message = String(decoding: message.utf16.prefix(8192), as: UTF16.self)
        self.defaultText = String(decoding: defaultText.utf16.prefix(8192), as: UTF16.self)
        self.completion = completion
    }

    func finish(_ answer: BrowserDialogAnswer?) {
        let callback = completion
        completion = nil
        callback?(answer)
    }

    static func origin(scheme: String, host: String, port: Int) -> String {
        let scheme = scheme.lowercased()
        guard ["http", "https"].contains(scheme), !host.isEmpty else { return "オリジン不明" }
        let hostname = host.contains(":") && !host.hasPrefix("[") ? "[\(host)]" : host
        let defaultPort = scheme == "https" ? 443 : 80
        let suffix = port > 0 && port != defaultPort ? ":\(port)" : ""
        return "\(scheme)://\(hostname)\(suffix)"
    }
}

@MainActor
final class BrowserDialogs: ObservableObject {
    @Published private(set) var request: BrowserDialogRequest?
    private var cancelling = false

    func show(_ next: BrowserDialogRequest) {
        // shortcut: Concurrent frame dialogs are cancelled; add a bounded queue if sites require them.
        guard request == nil, !cancelling else { next.finish(nil); return }
        request = next
    }

    func resolve(_ id: UUID, answer: BrowserDialogAnswer?) {
        guard let current = request, current.id == id else { return }
        request = nil
        current.finish(answer)
    }

    func cancel() {
        cancelling = true
        defer { cancelling = false }
        guard let current = request else { return }
        request = nil
        current.finish(nil)
    }
}

@MainActor
struct BrowserDialogOverlay: View {
    @ObservedObject var dialogs: BrowserDialogs
    let prepare: () -> Void

    var body: some View {
        if let request = dialogs.request {
            BrowserDialogCard(request: request) { answer in dialogs.resolve(request.id, answer: answer) }
                .id(request.id).onAppear(perform: prepare)
        }
    }
}

@MainActor
private struct BrowserDialogCard: View {
    private enum Field: Int { case value, username, password }
    let request: BrowserDialogRequest
    let finish: (BrowserDialogAnswer?) -> Void
    @EnvironmentObject private var preferences: BrowserPreferences
    @State private var value: String
    @State private var username = ""
    @State private var password = ""
    @State private var active: Field
    @State private var keyboardVisible = true
    @StateObject private var valueInput = BrowserTextInput()
    @StateObject private var usernameInput = BrowserTextInput()
    @StateObject private var passwordInput = BrowserTextInput()

    init(request: BrowserDialogRequest, finish: @escaping (BrowserDialogAnswer?) -> Void) {
        self.request = request; self.finish = finish
        _value = State(initialValue: request.defaultText)
        _active = State(initialValue: request.kind == .authentication ? .username : .value)
    }

    private var activeInput: BrowserTextInput {
        switch active { case .value: return valueInput; case .username: return usernameInput; case .password: return passwordInput }
    }
    private var fieldLabel: String {
        switch active { case .value: return "入力"; case .username: return "ユーザー名"; case .password: return "パスワード" }
    }
    private var title: String {
        switch request.kind {
        case .alert: return "ページからのお知らせ"
        case .confirm: return "ページからの確認"
        case .prompt: return "ページからの入力要求"
        case .authentication: return "BASIC認証"
        }
    }
    private var valid: Bool { value.utf16.count <= 8192 && username.utf16.count <= 8192 && password.utf16.count <= 8192 }

    private func submit() {
        guard valid else { return }
        let answer = BrowserDialogAnswer(text: value, username: username, password: password)
        value = ""; username = ""; password = ""
        finish(answer)
    }

    var body: some View {
        GeometryReader { geometry in
            let width: CGFloat = max(0, min(900, geometry.size.width - 24))
            let height: CGFloat = request.hasInput ? max(0, geometry.size.height - 24) : min(320, max(0, geometry.size.height - 24))
            ZStack {
                Color.black.opacity(0.45).ignoresSafeArea()
                content(width: width, height: geometry.size.height)
                    .padding(12).frame(width: width, height: height)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .accessibilityAddTraits(.isModal).privacySensitive()
            }
        }
        .onChange(of: usernameInput.isEditing) { _, editing in if editing { active = .username } }
        .onChange(of: passwordInput.isEditing) { _, editing in if editing { active = .password } }
        .onDisappear {
            value = ""; username = ""; password = ""
            valueInput.resign(); usernameInput.resign(); passwordInput.resign()
        }
    }

    private func content(width: CGFloat, height: CGFloat) -> some View {
        VStack(spacing: 10) {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    Text(title).font(.headline)
                    Text(request.origin).font(.system(.callout, design: .monospaced)).bold().textSelection(.enabled)
                    Text(request.message).font(.callout).textSelection(.enabled)
                    inputFields
                }.frame(maxWidth: .infinity, alignment: .leading)
            }
            actions
            if request.hasInput && keyboardVisible {
                keyboard
                    .id(active)
                    .frame(height: BrowserKeyboardLayout.height(available: max(0, height - 220), width: max(0, width - 24), size: preferences.state.keyboardSize))
            }
        }
    }

    @ViewBuilder
    private var inputFields: some View {
        if request.kind == .prompt {
            BrowserURLField(text: $value, input: valueInput, placeholder: "入力") { submit() }
                .frame(height: 40).accessibilityLabel("ページに返す文字列")
        } else if request.kind == .authentication {
            HStack {
                Button("ユーザー名へ入力") { active = .username; keyboardVisible = true }
                Button("パスワードへ入力") { active = .password; keyboardVisible = true }
            }.buttonStyle(.bordered)
            BrowserURLField(text: $username, input: usernameInput, placeholder: "ユーザー名") { active = .password }
                .frame(height: 40).accessibilityLabel("BASIC認証のユーザー名")
            BrowserURLField(text: $password, input: passwordInput, placeholder: "パスワード", secure: true) { submit() }
                .frame(height: 40).accessibilityLabel("BASIC認証のパスワード")
            if request.origin.hasPrefix("http://") {
                Text("HTTP接続です。認証情報は暗号化されません。").font(.caption).foregroundStyle(.orange)
            }
        }
    }

    private var actions: some View {
        HStack {
            if request.hasInput {
                Button { keyboardVisible.toggle() } label: { Image(systemName: "keyboard").frame(width: 44, height: 44) }
                    .accessibilityLabel("アプリ内キーボードを開閉")
            }
            Spacer()
            if request.kind != .alert { Button("キャンセル", role: .cancel) { finish(nil) }.buttonStyle(.bordered) }
            Button(request.kind == .authentication ? "ログイン" : "OK") { submit() }
                .buttonStyle(.borderedProminent).disabled(!valid)
        }
    }

    private var keyboard: some View {
        BrowserKeyboardPanel(target: .address, contextID: active.rawValue, status: "\(fieldLabel)へ入力", secure: active == .password,
                             send: { operation, text, done in done(activeInput.apply(operation, text: text)) },
                             close: { keyboardVisible = false }, keyboardSize: preferences.state.keyboardSize,
                             fixedTargetLabel: fieldLabel)
    }
}
