import SwiftUI

// App-only controls. No attempt to replace iPadOS Control Center or system switches.
@available(iOS 17.0, *)
struct ONEOSCustomizationSettings: View {
    @AppStorage("sgbit.lock.clock.size") private var clockSize = 84.0
    @AppStorage("sgbit.lock.clock.style") private var clockStyle = "glass"
    @AppStorage("sgbit.lock.clock.color") private var clockColor = "white"
    @AppStorage("sgbit.lock.clock.height") private var clockHeight = 0.15
    @AppStorage("sgbit.lock.glass.enabled") private var glassEnabled = true
    @AppStorage("sgbit.control.enabled") private var controlEnabled = true
    @AppStorage("sgbit.control.glass") private var controlGlass = true

    var body: some View {
        Form {
            Section("ロック画面の時計") {
                Picker("デザイン", selection: $clockStyle) {
                    Text("ガラス風").tag("glass")
                    Text("太字").tag("bold")
                    Text("細字").tag("thin")
                }
                Slider(value: $clockSize, in: 48...125, step: 1) {
                    Text("時計の大きさ")
                } minimumValueLabel: {
                    Image(systemName: "textformat.size.smaller")
                } maximumValueLabel: {
                    Image(systemName: "textformat.size.larger")
                }
                Text("文字サイズ: \(Int(clockSize)) pt").font(.caption).foregroundStyle(.secondary)
                Picker("時計の色", selection: $clockColor) {
                    Text("ホワイト").tag("white")
                    Text("ブルー").tag("blue")
                    Text("パープル").tag("purple")
                    Text("オレンジ").tag("orange")
                }
                Slider(value: $clockHeight, in: 0.02...0.35, step: 0.01) {
                    Text("上からの位置")
                }
                Text("左に動かすほど時計が上に移動します").font(.caption).foregroundStyle(.secondary)
                Toggle("時計のLiquid Glass風パネル", isOn: $glassEnabled)
            }
            Section("独自コントロールセンター") {
                Toggle("右端から開く", isOn: $controlEnabled)
                Toggle("ガラス風パネル", isOn: $controlGlass)
                    .disabled(!controlEnabled)
                Text("画面右側の細いハンドルから左にスワイプするか、ハンドルをタップして開きます。iPadOSのWi-FiやBluetoothを直接変更するものではありません。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("壁紙") {
                NavigationLink("ホーム・ロック画面の壁紙") { ONEWallpaperSettings() }
            }
        }
        .navigationTitle("ロック画面とOS風UI")
    }
}

@available(iOS 17.0, *)
struct ONEControlCenterOverlay: View {
    let openHome: () -> Void
    let openBrowser: () -> Void
    let openSettings: () -> Void
    let lockApp: () -> Void

    @AppStorage("sgbit.control.enabled") private var enabled = true
    @AppStorage("sgbit.control.glass") private var glass = true
    @AppStorage("bb.theme.dark") private var dark = true
    @State private var presented = false

    var body: some View {
        GeometryReader { geo in
            if enabled {
                ZStack(alignment: .trailing) {
                    if presented {
                        Color.black.opacity(0.30)
                            .ignoresSafeArea()
                            .onTapGesture { withAnimation(.easeInOut(duration: 0.23)) { presented = false } }
                        panel
                            .frame(width: min(345, geo.size.width * 0.88))
                            .frame(maxHeight: .infinity)
                            .transition(.move(edge: .trailing).combined(with: .opacity))
                            .gesture(DragGesture(minimumDistance: 24).onEnded { value in
                                if value.translation.width > 65 { withAnimation { presented = false } }
                            })
                    } else {
                        // Deliberately not at the top-right system gesture region.
                        VStack {
                            Spacer()
                            Capsule()
                                .fill(.thinMaterial)
                                .overlay(Image(systemName: "chevron.left")
                                    .font(.system(size: 10, weight: .bold)))
                                .frame(width: 18, height: 82)
                                .overlay(Capsule().strokeBorder(.white.opacity(0.25)))
                                .contentShape(Rectangle())
                                .onTapGesture { withAnimation(.easeInOut(duration: 0.23)) { presented = true } }
                                .gesture(DragGesture(minimumDistance: 18).onEnded { value in
                                    if value.translation.width < -35 { withAnimation { presented = true } }
                                })
                            Spacer()
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
                .animation(.easeInOut(duration: 0.23), value: presented)
            }
        }
        .accessibilityElement(children: .contain)
    }

    private var panel: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Label("SGBit Control Center", systemImage: "slider.horizontal.3")
                    .font(.headline)
                Spacer()
                Button { withAnimation { presented = false } } label: {
                    Image(systemName: "xmark.circle.fill").font(.title2)
                }
                .accessibilityLabel("閉じる")
            }
            Text(Date(), style: .date).font(.subheadline).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                tile("ホーム", symbol: "house.fill") { openHome() }
                tile("ブラウザ", symbol: "globe") { openBrowser() }
                tile("ダークモード", symbol: dark ? "moon.fill" : "sun.max.fill") { dark.toggle() }
                tile("画面をロック", symbol: "lock.fill") { lockApp() }
                tile("設定", symbol: "gearshape.fill") { openSettings() }
            }
            Divider()
            Label("アプリ内の操作パネルです", systemImage: "info.circle")
                .font(.caption).foregroundStyle(.secondary)
            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(glass ? AnyShapeStyle(.regularMaterial) : AnyShapeStyle(Color(uiColor: .secondarySystemBackground)))
                .overlay(RoundedRectangle(cornerRadius: 28).strokeBorder(.white.opacity(0.25)))
        }
        .padding(.vertical, 10)
        .padding(.trailing, 5)
    }

    private func tile(_ title: String, symbol: String, perform: @escaping () -> Void) -> some View {
        Button {
            withAnimation { presented = false }
            perform()
        } label: {
            VStack(alignment: .leading, spacing: 13) {
                Image(systemName: symbol).font(.title2)
                Text(title).font(.subheadline.weight(.semibold))
                    .lineLimit(2).minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity, minHeight: 93, alignment: .leading)
            .padding(12)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 19))
        }
        .buttonStyle(.plain)
    }
}
