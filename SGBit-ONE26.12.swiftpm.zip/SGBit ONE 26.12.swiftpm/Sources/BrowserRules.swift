import Foundation

enum BrowserAddress {
    static func url(for value: String, search: Bool = true) -> URL? {
        let input = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !input.isEmpty else { return nil }
        if input.range(of: "^[A-Za-z][A-Za-z0-9+.-]*://", options: .regularExpression) != nil {
            return webURL(input)
        }
        if !input.contains(where: \.isWhitespace), let url = webURL("https://" + input),
           let host = url.host, host.contains(".") || host == "localhost" || host.contains(":") {
            return url
        }
        // A scheme-like input must never turn into an executable or external URL.
        if input.range(of: "^[A-Za-z][A-Za-z0-9+.-]*:", options: .regularExpression) != nil { return nil }
        guard search else { return nil }
        var components = URLComponents(string: "https://google.com/search")!
        components.queryItems = [URLQueryItem(name: "q", value: input)]
        components.percentEncodedQuery = components.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        return components.url
    }

    static func webURL(_ value: String) -> URL? {
        guard !value.contains(where: \.isWhitespace), let url = URL(string: value),
              let scheme = url.scheme?.lowercased(), scheme == "https" || scheme == "http",
              let host = url.host, !host.isEmpty, url.user == nil, url.password == nil,
              (1...65535).contains(url.port ?? (scheme == "http" ? 80 : 443)) else { return nil }
        var components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        components?.scheme = scheme
        return components?.url
    }

    static func host(_ host: String, belongsTo site: String) -> Bool {
        let host = host.lowercased(), site = site.lowercased()
        return !site.isEmpty && (host == site || host.hasSuffix("." + site))
    }
}

struct BrowserScrollState {
    var hidden = false
    private var previous: CGFloat = 0
    private var distance: CGFloat = 0

    init(hidden: Bool = false) { self.hidden = hidden }

    mutating func update(translation: CGFloat, atTop: Bool, canScroll: Bool) -> Bool {
        let delta = translation - previous
        previous = translation
        if atTop || !canScroll {
            hidden = false
            distance = 0
        } else {
            if delta * distance < 0 { distance = 0 }
            distance += delta
            if abs(distance) >= 24 {
                hidden = distance < 0
                distance = 0
            }
        }
        return hidden
    }
}
