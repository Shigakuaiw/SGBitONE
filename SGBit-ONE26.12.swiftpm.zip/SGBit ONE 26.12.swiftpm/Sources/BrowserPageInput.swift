import Foundation
import WebKit
import Combine

@MainActor
final class BrowserPageInput: ObservableObject {
    @Published private(set) var focusSerial = 0
    @Published private(set) var status = "ページ内の入力欄をタップしてください"
    @Published private(set) var secure = false
    var hasTarget: Bool { frame != nil && !token.isEmpty }
    private(set) var pointerSelected = false
    private weak var webView: WKWebView?
    private var controller: WKUserContentController?
    private var frame: WKFrameInfo?
    private var token = ""
    private var generation = 0
    private var task: Task<Void, Never>?
    private struct Command {
        let operation: String, text: String, token: String
        let frame: WKFrameInfo
        let completion: (Bool) -> Void
    }
    private var commands: [Command] = []
    static let world = WKContentWorld.world(name: "RelayBrowserKeyboard")

    func install(in configuration: WKWebViewConfiguration) {
        let content = WKUserContentController()
        for script in configuration.userContentController.userScripts where script.source != Self.pageScript { content.addUserScript(script) }
        configuration.userContentController = content
        controller = content
        content.add(BrowserKeyboardReceiver(owner: self), contentWorld: Self.world, name: "relayKeyboard")
        content.addUserScript(WKUserScript(source: Self.pageScript, injectionTime: .atDocumentStart, forMainFrameOnly: false, in: Self.world))
    }

    func attach(_ webView: WKWebView) { self.webView = webView }
    func selected(_ message: WKScriptMessage) {
        guard message.webView === webView, let value = message.body as? [String: String],
              let token = value["token"], token.utf8.count <= 100,
              let kind = value["kind"], ["input", "password", "textarea", "contenteditable", "none"].contains(kind),
              let source = value["source"], ["pointer", "focus"].contains(source) else { return }
        self.token = token
        secure = kind == "password"
        frame = kind == "none" ? nil : message.frameInfo
        pointerSelected = source == "pointer"
        status = kind == "none" ? "ページ内の入力欄をタップしてください" : "ページ内の\(kind == "password" ? "パスワード欄" : "入力欄")を選択中"
        focusSerial += 1
    }

    func cancelPending() {
        generation += 1
        task?.cancel(); task = nil
        let abandoned = commands; commands.removeAll()
        for command in abandoned { command.completion(false) }
    }

    func reset() {
        cancelPending()
        frame = nil; token = ""
        pointerSelected = false
        secure = false
        status = "ページ内の入力欄をタップしてください"
        focusSerial += 1
    }

    func dispose() {
        reset()
        controller?.removeScriptMessageHandler(forName: "relayKeyboard", contentWorld: Self.world)
        controller = nil; webView = nil
    }

    func send(_ operation: String, text: String, completion: @escaping (Bool) -> Void) {
        guard ["insert", "delete", "left", "right", "selectAll", "enter", "lineBreak"].contains(operation), text.utf16.count <= 8192,
              let frame, !token.isEmpty, webView != nil, commands.count < 64 else {
            status = "入力欄を選んでから操作してください（対応: テキスト欄・編集可能な本文）"
            completion(false); return
        }
        commands.append(Command(operation: operation, text: text, token: token, frame: frame, completion: completion))
        guard task == nil else { return }
        let generation = generation
        task = Task { @MainActor [weak self] in
            guard let self else { return }
            while let command = self.commands.first {
                guard self.generation == generation, !Task.isCancelled else { return }
                var result = "unavailable"
                do {
                    if command.token != self.token { result = "stale" }
                    else { result = try await self.webView?.callAsyncJavaScript(
                        "return globalThis.relayKeyboard.apply(operation, text, token)",
                        arguments: ["operation": command.operation, "text": command.text, "token": command.token],
                        in: command.frame, contentWorld: Self.world) as? String ?? "unavailable" }
                } catch { result = "unavailable" }
                guard self.generation == generation, !Task.isCancelled else { return }
                self.commands.removeFirst()
                let success = ["ok", "handled", "enter-dispatched"].contains(result)
                switch result {
                case "ok", "handled": self.status = "入力しました"
                case "enter-dispatched": self.status = "Enterを通知しました。送信されない場合はページの送信ボタンを使ってください（改行はShift＋Enter）"
                case "blocked": self.status = "サイトが入力を拒否しました"
                case "composing": self.status = "OSの文字変換を確定してから試してください"
                case "maxlength": self.status = "入力欄の文字数上限です"
                case "invalid-value": self.status = "この入力欄では使えない文字です"
                case "selection-unavailable": self.status = "この種類の入力欄ではカーソル操作を使えません"
                case "unsupported": self.status = "この編集欄には対応していません"
                default: self.status = "入力できませんでした。入力欄を選び直してください"
                }
                command.completion(success)
            }
            self.task = nil
        }
    }

    static let pageScript = #"""
(() => {
    let target = null, savedRange = null, token = '', serial = 0, composing = false;
    const types = new Set(['text', 'search', 'url', 'email', 'tel', 'password', 'number']);
    const editable = node => {
        if (!(node instanceof Element)) return null;
        if (node instanceof HTMLInputElement) return types.has(node.type) && !node.readOnly && !node.matches(':disabled') ? node : null;
        if (node instanceof HTMLTextAreaElement) return !node.readOnly && !node.matches(':disabled') ? node : null;
        if (node.isContentEditable) {
            while (node.parentElement?.isContentEditable) node = node.parentElement;
            return node;
        }
        return null;
    };
    const saveRange = () => {
        if (!target?.isContentEditable) return;
        const selection = getSelection();
        if (selection.rangeCount && target.contains(selection.getRangeAt(0).commonAncestorContainer)) savedRange = selection.getRangeAt(0).cloneRange();
    };
    const choose = (node, source) => {
        if (node !== target) {
            target = node; savedRange = null; composing = false;
            token = node ? `${Date.now()}-${++serial}-${Math.random()}` : '';
        }
        const kind = !node ? 'none' : node instanceof HTMLInputElement ? (node.type === 'password' ? 'password' : 'input') : node instanceof HTMLTextAreaElement ? 'textarea' : 'contenteditable';
        window.webkit.messageHandlers.relayKeyboard.postMessage({token, kind, source});
        saveRange();
    };
    for (const event of ['pointerup', 'focusin']) document.addEventListener(event, event => {
        const node = event.composedPath().map(editable).find(Boolean) || null;
        choose(node, event.type === 'pointerup' && event.isTrusted ? 'pointer' : 'focus');
    }, true);
    document.addEventListener('selectionchange', saveRange, true);
    document.addEventListener('compositionstart', () => { composing = true; }, true);
    document.addEventListener('compositionend', () => { composing = false; }, true);
    const boundary = (value, offset, direction) => {
        const positions = [...new Intl.Segmenter(undefined, {granularity: 'grapheme'}).segment(value)].map(part => part.index);
        positions.push(value.length);
        return direction < 0 ? (positions.filter(position => position < offset).pop() ?? 0) : (positions.find(position => position > offset) ?? value.length);
    };
    const apply = (operation, text, expected) => {
        const node = target;
        if (!node || expected !== token || !node.isConnected || editable(node) !== node) return 'stale';
        if (composing) return 'composing';
        if (!['insert', 'delete', 'left', 'right', 'selectAll', 'enter', 'lineBreak'].includes(operation) || typeof text !== 'string' || text.length > 8192) return 'unsupported';
        const rich = node.isContentEditable;
        if (rich) {
            const previousRange = savedRange?.cloneRange();
            node.focus({preventScroll: true});
            if (target !== node || expected !== token) return 'stale';
            const selection = getSelection(), range = previousRange || document.createRange();
            if (!previousRange || !node.contains(range.commonAncestorContainer)) { range.selectNodeContents(node); range.collapse(false); }
            selection.removeAllRanges(); selection.addRange(range);
        }
        if (operation === 'enter' || operation === 'lineBreak') {
            const lineBreak = operation === 'lineBreak';
            const form = node.form;
            let submitted = false;
            const onSubmit = () => { submitted = true; };
            form?.addEventListener('submit', onSubmit);
            try {
                if (!rich && !(node instanceof HTMLTextAreaElement)) node.dispatchEvent(new Event('change', {bubbles: true, composed: true}));
                if (target !== node || expected !== token || !node.isConnected || editable(node) !== node) return 'stale';
                const init = {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, shiftKey: lineBreak, bubbles: true, cancelable: true, composed: true};
                let handled = !node.dispatchEvent(new KeyboardEvent('keydown', init));
                if (!handled && target === node && expected === token && node.isConnected) handled = !node.dispatchEvent(new KeyboardEvent('keypress', init));
                node.dispatchEvent(new KeyboardEvent('keyup', init));
                if (handled || submitted) return 'handled';
                if (target !== node || expected !== token || !node.isConnected || editable(node) !== node) return 'stale';
                if (!lineBreak) {
                    if (form && !rich && !(node instanceof HTMLTextAreaElement)) { form.requestSubmit(); return 'ok'; }
                    // shortcut: Untrusted key events cannot submit every editor; use the site's send button when ignored.
                    return 'enter-dispatched';
                }
                if (!rich && !(node instanceof HTMLTextAreaElement)) return 'unsupported';
            } finally { form?.removeEventListener('submit', onSubmit); }
        }
        if (rich) {
            const selection = getSelection(), range = selection.rangeCount ? selection.getRangeAt(0) : null;
            if (!range) return 'stale';
            let ok = true;
            if (operation === 'selectAll') { range.selectNodeContents(node); selection.removeAllRanges(); selection.addRange(range); }
            else if (operation === 'left' || operation === 'right') selection.modify('move', operation === 'left' ? 'backward' : 'forward', 'character');
            // shortcut: rich editors must support WebKit editing commands; custom canvas editors need their own integration.
            else {
                const inputType = operation === 'insert' ? 'insertText' : operation === 'delete' ? 'deleteContentBackward' : 'insertLineBreak';
                if (!node.dispatchEvent(new InputEvent('beforeinput', {inputType, data: operation === 'insert' ? text : null, bubbles: true, cancelable: true, composed: true}))) return 'blocked';
                if (target !== node || expected !== token || !node.isConnected || editable(node) !== node) return 'stale';
                ok = document.execCommand(operation === 'insert' ? 'insertText' : operation === 'delete' ? 'delete' : 'insertLineBreak', false, operation === 'insert' ? text : undefined);
            }
            saveRange();
            return ok ? 'ok' : 'unsupported';
        }
        const value = node.value;
        let start = node.selectionStart ?? value.length, end = node.selectionEnd ?? value.length;
        if (operation === 'selectAll' || operation === 'left' || operation === 'right') {
            if (node.selectionStart === null) return 'selection-unavailable';
            if (operation === 'selectAll') node.setSelectionRange(0, value.length);
            else {
                const offset = operation === 'left' ? (start !== end ? start : boundary(value, start, -1)) : (start !== end ? end : boundary(value, end, 1));
                node.setSelectionRange(offset, offset);
            }
            return 'ok';
        }
        const addition = operation === 'insert' ? text : operation === 'lineBreak' ? '\n' : '';
        if (operation === 'delete' && start === end) start = boundary(value, start, -1);
        let inserted = addition;
        if (node.maxLength >= 0) {
            const room = Math.max(0, node.maxLength - (value.length - (end - start)));
            inserted = '';
            for (const {segment} of new Intl.Segmenter(undefined, {granularity: 'grapheme'}).segment(addition)) {
                if (inserted.length + segment.length > room) break;
                inserted += segment;
            }
            if (addition && !inserted) return 'maxlength';
        }
        const inputType = operation === 'delete' ? 'deleteContentBackward' : operation === 'lineBreak' ? 'insertLineBreak' : 'insertText';
        if (!node.dispatchEvent(new InputEvent('beforeinput', {inputType, data: inserted || null, bubbles: true, cancelable: true, composed: true}))) return 'blocked';
        if (expected !== token || target !== node || node.value !== value || !node.isConnected || editable(node) !== node) return 'stale';
        const next = value.slice(0, start) + inserted + value.slice(end);
        const prototype = node instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const set = Object.getOwnPropertyDescriptor(prototype, 'value').set;
        set.call(node, next);
        if (next && !node.value) { set.call(node, value); return 'invalid-value'; }
        if (node.selectionStart !== null) node.setSelectionRange(start + inserted.length, start + inserted.length);
        node.dispatchEvent(new InputEvent('input', {inputType, data: inserted || null, bubbles: true, composed: true}));
        return 'ok';
    };
    globalThis.relayKeyboard = {apply};
})();
"""#
}

@MainActor
private final class BrowserKeyboardReceiver: NSObject, WKScriptMessageHandler {
    private weak var owner: BrowserPageInput?
    init(owner: BrowserPageInput) { self.owner = owner; super.init() }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "relayKeyboard" else { return }
        owner?.selected(message)
    }
}
