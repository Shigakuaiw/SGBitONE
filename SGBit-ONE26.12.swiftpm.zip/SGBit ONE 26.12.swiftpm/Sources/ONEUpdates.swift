import SwiftUI
import Foundation

// Safe, data-only updates: no remote Swift, JavaScript injection, or executable code.
@available(iOS 17.0, *)
private struct ONEUpdateManifest: Decodable {
    struct Patch: Decodable {
        var darkTheme: Bool?
        var accent: String?
        var panelOpacity: Double?
        var cornerRadius: Double?
    }
    let schema: Int
    let version: String
    let title: String
    let notes: String
    let downloadURL: String?
    let patch: Patch?
}

// GitHub public Releases API. The app never needs a GitHub access token.
@available(iOS 17.0, *)
private struct ONEGitHubRelease: Decodable {
    struct Asset: Decodable {
        let name: String
        let browser_download_url: String
        let size: Int
    }
    let tag_name: String
    let name: String?
    let body: String?
    let html_url: String
    let assets: [Asset]
    let draft: Bool
    let prerelease: Bool
}

@available(iOS 17.0, *)
struct ONEUpdatesScreen: View {
    @AppStorage("sgbit.one.update.manifestURL") private var manifestURL = ""
    @AppStorage("sgbit.one.update.appliedVersion") private var appliedVersion = ""
    @AppStorage("bb.theme.dark") private var darkTheme = true
    @AppStorage("bb.theme.accent") private var accentName = "blue"
    @AppStorage("bb.theme.opacity") private var panelOpacity = 0.94
    @AppStorage("bb.theme.corner") private var cornerRadius = 21.0
    @State private var result: ONEUpdateManifest?
    @State private var loading = false
    @State private var message: String?
    @State private var showConfirm = false
    @State private var githubRelease: ONEGitHubRelease?
    @State private var githubLoading = false
    @State private var githubMessage: String?
    private let installedVersion = "26.11.1119.000"
    private let githubAPI = "https://api.github.com/repos/Shigakuaiw/SGBitONE/releases/latest"

    private func versionParts(_ raw: String) -> [Int] {
        raw.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "v", with: "", options: [.anchored, .caseInsensitive])
            .split(separator: ".").compactMap { Int($0) }
    }

    // A development build based on 26.11 is newer than the official 26.11.
    private var githubIsNewer: Bool {
        guard let release = githubRelease else { return false }
        let a = versionParts(release.tag_name)
        let b = versionParts(installedVersion)
        guard a.count >= 2, b.count >= 2 else { return false }
        for i in 0..<max(a.count, b.count) {
            let x = i < a.count ? a[i] : 0
            let y = i < b.count ? b[i] : 0
            if x != y { return x > y }
        }
        return false
    }

    private var githubZip: URL? {
        guard let release = githubRelease else { return nil }
        guard let asset = release.assets.first(where: { $0.name.hasSuffix(".swiftpm.zip") }),
              let url = URL(string: asset.browser_download_url),
              url.scheme == "https", url.host == "github.com" else { return nil }
        return url
    }

    private func checkGitHub() async {
        githubLoading = true
        githubMessage = nil
        defer { githubLoading = false }
        guard let url = URL(string: githubAPI) else { return }
        do {
            var request = URLRequest(url: url)
            request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
            request.setValue("SGBitONE-Updater", forHTTPHeaderField: "User-Agent")
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.timeoutInterval = 20
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                githubMessage = "GitHubから応答がありません。"; return
            }
            guard http.statusCode == 200 else {
                githubMessage = http.statusCode == 404 ? "公開済みReleaseが見つかりません。リポジトリの公開状態を確認してください。" : "GitHubの応答エラー (\(http.statusCode))"
                return
            }
            guard data.count < 524288 else { githubMessage = "更新情報が大きすぎます。"; return }
            let release = try JSONDecoder().decode(ONEGitHubRelease.self, from: data)
            guard !release.draft, !release.prerelease,
                  release.tag_name.range(of: #"^v?\d+\.\d+(\.\d+)*$"#, options: .regularExpression) != nil else {
                githubMessage = "Releaseのバージョン形式が不正です。"; return
            }
            githubRelease = release
            githubMessage = githubIsNewer ? "新しいバージョンがあります。" : "このアプリは最新の開発版、または公開版と同等以上です。"
        } catch {
            githubMessage = "GitHubの更新確認に失敗しました。通信状態を確認してください。"
        }
    }

    private var isNewer: Bool {
        guard let result else { return false }
        func parts(_ version: String) -> [Int] { version.split(separator: ".").map { Int($0) ?? 0 } }
        let a = parts(result.version), b = parts(installedVersion)
        for i in 0..<max(a.count, b.count) {
            let left = i < a.count ? a[i] : 0
            let right = i < b.count ? b[i] : 0
            if left != right { return left > right }
        }
        return false
    }

    private func check() async {
        loading = true
        defer { loading = false }
        message = nil
        result = nil
        let raw = manifestURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: raw), url.scheme == "https", url.host != nil,
              url.user == nil, url.password == nil else {
            message = "管理者のHTTPS更新URLを入力してください。"
            return
        }
        do {
            var request = URLRequest(url: url)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.timeoutInterval = 15
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
                message = "更新サーバーから正常な応答がありません。"
                return
            }
            guard data.count <= 65536 else { message = "更新データが大きすぎます。"; return }
            let item = try JSONDecoder().decode(ONEUpdateManifest.self, from: data)
            guard item.schema == 1,
                  item.version.range(of: #"^\d+\.\d+(\.\d+)?$"#, options: .regularExpression) != nil,
                  !item.title.isEmpty, item.title.count <= 100, item.notes.count <= 4000 else {
                message = "この更新データ形式には対応していません。"
                return
            }
            result = item
            if !isNewer && item.patch == nil { message = "現在のアプリは最新版です。" }
        } catch {
            message = "更新を確認できませんでした。接続先とネットワークを確認してください。"
        }
    }

    private func applyPatch() {
        guard let item = result, let patch = item.patch else { return }
        if let dark = patch.darkTheme { darkTheme = dark }
        if let accent = patch.accent, ["blue", "purple", "pink", "red", "orange", "green", "teal"].contains(accent) {
            accentName = accent
        }
        if let opacity = patch.panelOpacity, opacity.isFinite, (0.5...1.0).contains(opacity) { panelOpacity = opacity }
        if let radius = patch.cornerRadius, radius.isFinite, (8...36).contains(radius) { cornerRadius = radius }
        appliedVersion = item.version
        message = "設定パッチを適用しました。変更が反映されない場合は画面を開き直してください。"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("GitHub Releases・公式アップデート") {
                    LabeledContent("配信元", value: "Shigakuaiw / SGBitONE")
                    Button { Task { await checkGitHub() } } label: {
                        Label(githubLoading ? "確認中…" : "GitHubでアップデートを確認", systemImage: "arrow.clockwise.circle")
                    }
                    .disabled(githubLoading)
                    if let release = githubRelease {
                        LabeledContent("公開バージョン", value: release.tag_name)
                        if githubIsNewer {
                            Label("新しいバージョンが利用できます", systemImage: "arrow.down.circle.fill")
                                .foregroundStyle(.green)
                        }
                        Text(release.name ?? "SGBit ONE").font(.headline)
                        if let notes = release.body, !notes.isEmpty {
                            Text(String(notes.prefix(4000))).font(.subheadline)
                        }
                        if let zip = githubZip {
                            Link(destination: zip) {
                                Label("更新ZIPをダウンロード", systemImage: "square.and.arrow.down")
                            }
                        } else {
                            Text(".swiftpm.zip ファイルがReleaseに見つかりません。")
                                .foregroundStyle(.secondary)
                        }
                        if let page = URL(string: release.html_url), page.scheme == "https", page.host == "github.com" {
                            Link("GitHubのReleaseページを開く", destination: page)
                        }
                    }
                    if let githubMessage { Text(githubMessage).font(.footnote) }
                } footer: {
                    Text("公開GitHub Releaseを確認します。ZIPの取得後はSwift Playgroundsで手動更新してください。アプリ内の保存データを守るため、更新前のバックアップをおすすめします。")
                }
                Section("インストール済み") {
                    LabeledContent("SGBit ONE", value: installedVersion)
                    if !appliedVersion.isEmpty { LabeledContent("適用済み設定パッチ", value: appliedVersion) }
                }
                Section {
                    TextField("https://example.workers.dev/updates", text: $manifestURL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    Button { Task { await check() } } label: {
                        Label(loading ? "確認中…" : "アップデートを確認", systemImage: "arrow.clockwise")
                    }.disabled(loading)
                } header: {
                    Text("旧Cloudflare設定パッチ（任意）")
                } footer: {
                    Text("このURLは管理者が公開した読み取り専用の更新情報です。管理者用の秘密キーはアプリに保存しません。")
                }
                if let item = result {
                    Section("配信中のアップデート") {
                        LabeledContent("バージョン", value: item.version)
                        Text(item.title).font(.headline)
                        Text(item.notes).font(.body)
                        if let patch = item.patch {
                            Button("設定パッチを適用") { showConfirm = true }
                            Text("変更可能: テーマ、アクセント、パネルの透明度、角丸。アプリ本体のSwiftコードは変更されません。")
                                .font(.caption).foregroundStyle(.secondary)
                            if appliedVersion == item.version { Text("このバージョンの設定パッチは適用済みです。").foregroundStyle(.secondary) }
                            // Keep reference for optional properties and aid compiler type-checking.
                            if patch.darkTheme != nil { Text("配色設定を含みます").font(.caption).foregroundStyle(.secondary) }
                        }
                        if let link = item.downloadURL, let url = URL(string: link), url.scheme == "https" {
                            Link("新しいアプリ本体の配布ページを開く", destination: url)
                        } else if isNewer {
                            Text("新しい本体の配布URLはまだ登録されていません。")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                if let message { Section { Text(message) } }
                Section {
                    Text("セキュリティ: 更新情報はHTTPSで受信します。設定パッチはユーザー確認後だけ適用。アプリ本体の更新は通常の配布・インストールが必要です。")
                        .font(.footnote)
                }
            }
            .navigationTitle("ソフトウェアアップデート")
            .task { await checkGitHub() }
            .confirmationDialog("管理者からの設定変更を適用しますか？", isPresented: $showConfirm) {
                Button("適用する") { applyPatch() }
                Button("キャンセル", role: .cancel) { }
            } message: {
                Text("信頼できる管理者のサーバーであることを確認してください。")
            }
        }
    }
}
