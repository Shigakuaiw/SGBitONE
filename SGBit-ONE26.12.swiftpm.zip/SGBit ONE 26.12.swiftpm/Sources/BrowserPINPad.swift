import Foundation

struct BrowserPINDraft {
    static func edit(_ current: String, key: String) -> String {
        if key == "delete" { return String(current.dropLast()) }
        if key == "clear" { return "" }
        guard current.utf8.count < 4, key.utf8.count == 1, let digit = key.utf8.first, (48...57).contains(digit) else { return current }
        return current + key
    }
}

#if canImport(SwiftUI)
import SwiftUI

// A frosted, iOS 17-compatible visual treatment. No changes to PIN processing.
private enum BitPINGlass {
    static let blue = Color(red: 0.20, green: 0.47, blue: 0.96)
    static let border = Color.white.opacity(0.19)
}

struct BrowserPINEntry: View {
    let label: String
    let pin: String
    var active = true
    var select: () -> Void = {}

    var body: some View {
        Button(action: select) {
            HStack(spacing: 12) {
                Image(systemName: active ? "lock.shield.fill" : "lock.shield")
                    .font(.title3)
                    .foregroundStyle(active ? BitPINGlass.blue : Color.secondary)
                    .frame(width: 28)
                VStack(alignment: .leading, spacing: 9) {
                    Text(label)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                    HStack(spacing: 12) {
                        ForEach(0..<4, id: \.self) { index in
                            Circle()
                                .fill(index < pin.count ? BitPINGlass.blue : Color.clear)
                                .frame(width: 12, height: 12)
                                .overlay {
                                    Circle().strokeBorder(index < pin.count ? BitPINGlass.blue : Color.secondary.opacity(0.55), lineWidth: 1.7)
                                }
                        }
                    }
                }
                Spacer(minLength: 0)
                if active {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(BitPINGlass.blue)
                }
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 17)
            .frame(maxWidth: .infinity, minHeight: 80, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(active ? BitPINGlass.blue.opacity(0.7) : BitPINGlass.border, lineWidth: active ? 1.5 : 1)
            }
            .shadow(color: active ? BitPINGlass.blue.opacity(0.13) : .black.opacity(0.05), radius: 12, y: 5)
            .contentShape(RoundedRectangle(cornerRadius: 22))
        }
        .buttonStyle(.plain)
        .privacySensitive()
        .accessibilityLabel("\(label)、\(pin.count)桁入力済み\(active ? "、入力先" : "")")
    }
}

struct BrowserPINPad: View {
    @Binding var pin: String
    let submitTitle: String
    var enabled = true
    var keyHeight: CGFloat = 54
    let submit: () -> Void
    private let rows = [["1", "2", "3"], ["4", "5", "6"], ["7", "8", "9"], ["clear", "0", "delete"]]

    var body: some View {
        VStack(spacing: 12) {
            VStack(spacing: 9) {
                ForEach(rows, id: \.self) { row in
                    HStack(spacing: 9) {
                        ForEach(row, id: \.self) { key in
                            digitButton(key)
                        }
                    }
                }
            }
            Button(action: submit) {
                HStack(spacing: 8) {
                    Image(systemName: "lock.shield")
                    Text(submitTitle).fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .frame(height: max(48, keyHeight))
                .foregroundStyle(.white)
                .background(BitPINGlass.blue.gradient, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 17, style: .continuous)
                        .strokeBorder(.white.opacity(0.27), lineWidth: 1)
                }
            }
            .buttonStyle(.plain)
            .disabled(!enabled)
            .opacity(enabled ? 1 : 0.45)
        }
        .padding(15)
        .frame(maxWidth: 380)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .strokeBorder(BitPINGlass.border, lineWidth: 1)
        }
        .shadow(color: .black.opacity(0.16), radius: 18, y: 8)
        .privacySensitive()
    }

    private func digitButton(_ key: String) -> some View {
        Button {
            pin = BrowserPINDraft.edit(pin, key: key)
        } label: {
            Group {
                if key == "delete" {
                    Image(systemName: "delete.left")
                        .font(.title3.weight(.medium))
                } else if key == "clear" {
                    Text("消去")
                        .font(.subheadline.weight(.medium))
                } else {
                    Text(key)
                        .font(.title2.weight(.medium).monospacedDigit())
                }
            }
            .foregroundStyle(.primary)
            .frame(maxWidth: .infinity)
            .frame(height: max(48, keyHeight))
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .strokeBorder(.white.opacity(0.22), lineWidth: 1)
            }
            .contentShape(RoundedRectangle(cornerRadius: 16))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(key == "clear" ? "PINを全消去" : key == "delete" ? "PINを一桁削除" : key)
    }
}
#endif
