import Foundation
import Network

// Mutable state is confined to queue; UI callbacks are dispatched to main.
final class LoopbackRelay: @unchecked Sendable {
    private let queue = DispatchQueue(label: "RelayBrowser.proxy")
    private var listener: NWListener?
    private var tunnels: [UUID: ProxyTunnel] = [:]
    private var resolver: (any BrowserHostResolver)?
    private var metrics: [UUID: RelayConnectionSnapshot] = [:]
    private var total = 0, errors = 0
    private var sent: Int64 = 0, received: Int64 = 0
    private var publishScheduled = false
    private var monitorCallback: (@MainActor @Sendable (RelayMonitorSnapshot) -> Void)?

    func start(credentials: ProxyCredentials, onTunnelOpened: @escaping @MainActor @Sendable () -> Void,
               onDiagnostic: @escaping @MainActor @Sendable (String) -> Void,
               privateCredentials: ProxyCredentials? = nil,
               onMonitor: @escaping @MainActor @Sendable (RelayMonitorSnapshot) -> Void = { _ in },
               inspectRoute: @escaping ProxyTunnel.RouteInspector = ProxyTunnel.inspectDirectRoute,
               completion: @escaping @MainActor @Sendable (Result<UInt16, Error>) -> Void) {
        queue.async {
            self.monitorCallback = onMonitor
            guard self.listener == nil else { return }
            do {
                let parameters = NWParameters.tcp
                parameters.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
                let listener = try NWListener(using: parameters, on: .any)
                self.listener = listener
                listener.stateUpdateHandler = { [weak self, weak listener] state in
                    guard let self, let listener, self.listener === listener else { return }
                    switch state {
                    case .ready:
                        guard let port = listener.port?.rawValue else { return }
                        DispatchQueue.main.async { completion(.success(port)) }
                    case .failed(let error):
                        self.shutdown()
                        DispatchQueue.main.async { completion(.failure(error)) }
                    default: break
                    }
                }
                listener.newConnectionHandler = { [weak self, weak listener] connection in
                    guard let self, let listener, self.listener === listener else {
                        connection.cancel()
                        return
                    }
                    guard self.tunnels.count < 128 else {
                        DispatchQueue.main.async { onDiagnostic("中継の接続数上限 (128)") }
                        connection.cancel()
                        return
                    }
                    let id = UUID()
                    let tunnel = ProxyTunnel(connection: connection, queue: self.queue,
                                             credentials: credentials,
                                             onOpened: {
                        DispatchQueue.main.async { onTunnelOpened() }
                    }, onDiagnostic: { message in
                        let label = String(id.uuidString.prefix(6))
                        DispatchQueue.main.async { onDiagnostic("[\(label)] \(message)") }
                    }, onClose: { [weak self] in self?.tunnels.removeValue(forKey: id) },
                                             privateCredentials: privateCredentials, resolver: self.resolver, id: id,
                                             onUpdate: { [weak self] in self?.update($0) }, inspectRoute: inspectRoute)
                    self.tunnels[id] = tunnel
                    tunnel.start()
                }
                listener.start(queue: self.queue)
            } catch {
                DispatchQueue.main.async { completion(.failure(error)) }
            }
        }
    }

    func stop() { queue.async { self.shutdown() } }

    func setResolver(_ resolver: (any BrowserHostResolver)?, completion: @escaping @MainActor @Sendable () -> Void = {}) {
        queue.async { self.resolver = resolver; DispatchQueue.main.async { completion() } }
    }

    func closePrivateConnections() {
        queue.async { for tunnel in Array(self.tunnels.values) where tunnel.isPrivateSession { tunnel.close() } }
    }

    func clearMonitor() {
        queue.async {
            for tunnel in Array(self.tunnels.values) { tunnel.close() }
            self.metrics.removeAll()
            self.total = 0; self.errors = 0; self.sent = 0; self.received = 0
            self.publish()
        }
    }

    private func update(_ value: RelayConnectionSnapshot) {
        let old = metrics[value.id]
        if old == nil { total += 1 }
        sent += max(0, value.sent - (old?.sent ?? 0))
        received += max(0, value.received - (old?.received ?? 0))
        if value.error != nil && old?.error == nil { errors += 1 }
        if value.closed && value.isPrivate { metrics.removeValue(forKey: value.id) }
        else { metrics[value.id] = value }
        while metrics.count > 200, let oldest = metrics.values.filter(\.closed).min(by: { $0.started < $1.started }) {
            metrics.removeValue(forKey: oldest.id)
        }
        publish()
    }

    private func publish() {
        guard !publishScheduled else { return }
        publishScheduled = true
        queue.asyncAfter(deadline: .now() + 0.25) {
            self.publishScheduled = false
            guard let callback = self.monitorCallback else { return }
            let value = RelayMonitorSnapshot(connections: self.metrics.values.sorted { $0.started > $1.started },
                                             active: self.metrics.values.filter { !$0.closed }.count,
                                             total: self.total, sent: self.sent, received: self.received, errors: self.errors)
            DispatchQueue.main.async { callback(value) }
        }
    }

    private func shutdown() {
        listener?.stateUpdateHandler = nil
        listener?.newConnectionHandler = nil
        listener?.cancel()
        listener = nil
        resolver = nil
        for tunnel in Array(tunnels.values) { tunnel.close() }
        tunnels.removeAll()
    }
}
