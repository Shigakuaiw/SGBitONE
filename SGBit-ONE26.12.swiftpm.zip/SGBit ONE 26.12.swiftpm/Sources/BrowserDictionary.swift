import Foundation

actor BrowserDictionary {
    static let shared = BrowserDictionary()
    private var cached: Result<[String: [String]], Error>?

    func candidates(for reading: String) async throws -> [String] {
        try Task.checkCancellation()
        if cached == nil { cached = Result { try Self.load() } }
        guard let cached else { throw CocoaError(.fileReadCorruptFile) }
        let words = BrowserPhraseConverter.candidates(for: reading, dictionary: try cached.get())
        try Task.checkCancellation()
        return words
    }

    private static func load() throws -> [String: [String]] {
        guard let url = resourceURL("mozc-dictionary", extension: "json") else {
            throw CocoaError(.fileNoSuchFile)
        }
        let data = try Data(contentsOf: url, options: .mappedIfSafe)
        guard data.count <= 16 * 1024 * 1024 else { throw CocoaError(.fileReadCorruptFile) }
        return try JSONDecoder().decode([String: [String]].self, from: data)
    }

    static var licenseNotice: String {
        guard let url = resourceURL("Mozc-Dictionary", extension: "txt"),
              let text = try? String(contentsOf: url, encoding: .utf8) else {
            return "Mozc辞書のライセンスが見つかりません。Resources一式を確認してください。"
        }
        return text
    }

    static func resourceURL(_ name: String, extension suffix: String, in bundles: [Bundle]? = nil) -> URL? {
        let candidates = bundles ?? [Bundle.main, Bundle(for: BrowserDictionaryResourceAnchor.self)]
        for bundle in candidates {
            if let url = find(name, extension: suffix, in: bundle) { return url }
            let roots = Set([bundle.resourceURL, bundle.bundleURL].compactMap { $0 })
            for root in roots {
                let children = (try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)) ?? []
                for child in children where child.pathExtension == "bundle" {
                    if let resources = Bundle(url: child), let url = find(name, extension: suffix, in: resources) { return url }
                }
            }
        }
        return nil
    }

    private static func find(_ name: String, extension suffix: String, in bundle: Bundle) -> URL? {
        bundle.url(forResource: name, withExtension: suffix)
            ?? bundle.url(forResource: name, withExtension: suffix, subdirectory: "Resources")
    }
}

private final class BrowserDictionaryResourceAnchor: NSObject {}
