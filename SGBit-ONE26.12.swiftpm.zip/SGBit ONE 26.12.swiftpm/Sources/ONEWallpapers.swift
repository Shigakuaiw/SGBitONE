import SwiftUI
import PhotosUI
import UIKit
import ImageIO

// Three completely independent local wallpapers. Only copies chosen by the user
// are stored inside this app; the photo library is not scanned or uploaded.
@MainActor
final class ONEWallpapers: ObservableObject {
    static let shared = ONEWallpapers()
    enum Area: String, CaseIterable, Identifiable {
        case lock = "lock", home = "home", browser = "browser"
        var id: String { rawValue }
        var title: String {
            switch self { case .lock: return "ロック画面"; case .home: return "ホーム画面"; case .browser: return "ブラウザの新しいタブ" }
        }
    }
    @Published private(set) var images: [Area: UIImage] = [:]
    @Published var errorMessage = ""
    private init() { for area in Area.allCases { reload(area) } }
    private func location(_ area: Area) -> URL? {
        guard let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        return base.appendingPathComponent("ONEWallpapers", isDirectory: true).appendingPathComponent(area.rawValue + ".jpg")
    }
    func image(for area: Area) -> UIImage? { images[area] }
    private func reload(_ area: Area) {
        guard let url = location(area),
              let attributes = try? FileManager.default.attributesOfItem(atPath: url.path),
              let fileSize = attributes[.size] as? NSNumber,
              fileSize.int64Value <= 12_000_000,
              let source = CGImageSourceCreateWithURL(url as CFURL, [kCGImageSourceShouldCache: false] as CFDictionary),
              let thumbnail = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceThumbnailMaxPixelSize: 2048,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceShouldCacheImmediately: true
              ] as CFDictionary) else { return }
        images[area] = UIImage(cgImage: thumbnail)
    }
    func remove(_ area: Area) {
        if let url = location(area) { try? FileManager.default.removeItem(at: url) }
        images.removeValue(forKey: area)
        errorMessage = ""
    }
    func set(_ data: Data, for area: Area) {
        guard let url = location(area), !data.isEmpty else {
            errorMessage = "画像を読み込めません"
            return
        }
        // ImageIO downsamples before decoding full-resolution images to avoid
        // memory spikes with modern HEIC / 48MP photographs.
        let options = [kCGImageSourceShouldCache: false] as CFDictionary
        guard let source = CGImageSourceCreateWithData(data as CFData, options),
              let thumbnail = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceThumbnailMaxPixelSize: 2048,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceShouldCacheImmediately: true
              ] as CFDictionary) else {
            errorMessage = "対応していない写真形式です"
            return
        }
        let scaled = UIImage(cgImage: thumbnail)
        guard let jpeg = scaled.jpegData(compressionQuality: 0.8) else {
            errorMessage = "画像を保存できません"
            return
        }
        do {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            try jpeg.write(to: url, options: .atomic)
            images[area] = scaled
            errorMessage = ""
        } catch { errorMessage = "保存できません: \(error.localizedDescription)" }
    }
}

@available(iOS 17.0, *)
struct ONEWallpaperBackground: View {
    let area: ONEWallpapers.Area
    @ObservedObject private var wallpapers = ONEWallpapers.shared
    @AppStorage("bb.theme.dark") private var darkTheme = false
    @AppStorage("sgbit.wallpaper.preset") private var preset = "system"
    var body: some View {
        GeometryReader { geometry in
            Group {
                if let image = wallpapers.image(for: area) {
                    Image(uiImage: image).resizable().scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                } else {
                    switch area {
                    case .lock:
                        LinearGradient(colors: [Color(red: 0.08, green: 0.17, blue: 0.37), Color(red: 0.28, green: 0.43, blue: 0.72), Color(red: 0.62, green: 0.71, blue: 0.86)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    case .home:
                        switch preset {
                        case "gradient":
                            LinearGradient(colors: [Color(red: 0.82, green: 0.91, blue: 1), Color(red: 0.87, green: 0.82, blue: 0.98), Color.white], startPoint: .topLeading, endPoint: .bottomTrailing)
                        case "solid":
                            Color(red: 0.79, green: 0.88, blue: 0.99)
                        default:
                            Color(uiColor: .systemGroupedBackground)
                        }
                    case .browser:
                        LinearGradient(colors: darkTheme ? [Color(red: 0.12, green: 0.20, blue: 0.36), Color(red: 0.07, green: 0.11, blue: 0.20)] : [Color(red: 0.97, green: 0.98, blue: 1.0), Color(red: 0.91, green: 0.94, blue: 0.98)], startPoint: .top, endPoint: .bottom)
                    }
                }
            }
        }.ignoresSafeArea().allowsHitTesting(false)
    }
}

@available(iOS 17.0, *)
struct ONEWallpaperSettings: View {
    @ObservedObject private var wallpapers = ONEWallpapers.shared
    var body: some View {
        List {
            Section {
                Text("ロック画面・ホーム画面・ブラウザの新しいタブに、それぞれ別の写真を設定できます。Webサイト自体の背景は変更しません。")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            ForEach(ONEWallpapers.Area.allCases) { area in
                Section(area.title) { ONEWallpaperPickerRow(area: area) }
            }
            if !wallpapers.errorMessage.isEmpty { Text(wallpapers.errorMessage).foregroundStyle(.red) }
        }
        .navigationTitle("壁紙")
    }
}

@available(iOS 17.0, *)
private struct ONEWallpaperPickerRow: View {
    let area: ONEWallpapers.Area
    @ObservedObject private var wallpapers = ONEWallpapers.shared
    @State private var selectedPhoto: PhotosPickerItem?
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 16).fill(Color.secondary.opacity(0.08))
                if let image = wallpapers.image(for: area) {
                    Image(uiImage: image).resizable().scaledToFill().frame(height: 120).clipped()
                } else { Image(systemName: "photo").font(.largeTitle).foregroundStyle(.secondary) }
            }
            .frame(maxWidth: .infinity).frame(height: 120)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            HStack {
                PhotosPicker(selection: $selectedPhoto, matching: .images) {
                    Label("写真から選ぶ", systemImage: "photo.on.rectangle")
                }
                .buttonStyle(.borderedProminent)
                if wallpapers.image(for: area) != nil {
                    Button("標準に戻す", role: .destructive) { wallpapers.remove(area) }
                        .buttonStyle(.bordered)
                }
            }
        }
        .padding(.vertical, 8)
        .onChange(of: selectedPhoto) { _, photo in
            guard let photo else { return }
            Task {
                if let data = try? await photo.loadTransferable(type: Data.self) {
                    wallpapers.set(data, for: area)
                } else { wallpapers.errorMessage = "写真を読み込めません" }
                selectedPhoto = nil
            }
        }
    }
}
