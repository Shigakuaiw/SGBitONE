import SwiftUI

struct BrowserPreferencesState: Codable, Equatable {
    var keepHistory = true
    var restoreTabs = false
    var showBookmarksBar = false
    var adGuardDNS = false
    var keyboardSize: BrowserKeyboardSize = .minimum
    var debugStatusBar = false

    private enum CodingKeys: String, CodingKey {
        case keepHistory, restoreTabs, showBookmarksBar, adGuardDNS, keyboardSize, debugStatusBar
    }
    init() {}
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        keepHistory = try values.decodeIfPresent(Bool.self, forKey: .keepHistory) ?? true
        restoreTabs = try values.decodeIfPresent(Bool.self, forKey: .restoreTabs) ?? false
        showBookmarksBar = try values.decodeIfPresent(Bool.self, forKey: .showBookmarksBar) ?? false
        adGuardDNS = try values.decodeIfPresent(Bool.self, forKey: .adGuardDNS) ?? false
        keyboardSize = (try? values.decode(BrowserKeyboardSize.self, forKey: .keyboardSize)) ?? .minimum
        debugStatusBar = (try? values.decode(Bool.self, forKey: .debugStatusBar)) ?? false
    }
}

@MainActor
final class BrowserPreferences: ObservableObject {
    @Published var japaneseInput = false
    @Published var state: BrowserPreferencesState {
        didSet {
            if let data = try? JSONEncoder().encode(state) { defaults.set(data, forKey: "RelayBrowser.preferences") }
            didChange?()
        }
    }
    var didChange: (() -> Void)?
    private let defaults: UserDefaults
    init(defaults: UserDefaults) {
        self.defaults = defaults
        state = defaults.data(forKey: "RelayBrowser.preferences")
            .flatMap { try? JSONDecoder().decode(BrowserPreferencesState.self, from: $0) } ?? .init()
    }
}

struct BrowserBookmark: Codable, Identifiable, Equatable {
    var id = UUID()
    var title: String
    var url: URL
}

struct BrowserHistoryEntry: Codable, Identifiable {
    var id = UUID()
    var title: String
    var url: URL
    var date = Date()
}

struct SavedBrowserTab: Codable {
    var url: URL?
    var title: String
    var desktop: Bool
    var displayMode: BrowserDisplayMode? = nil
}

@MainActor
final class BrowserLibrary: ObservableObject {
    private struct Session: Codable {
        var tabs: [SavedBrowserTab] = []
        var selectedTab = 0
    }
    @Published private(set) var bookmarks: [BrowserBookmark] = []
    @Published private(set) var history: [BrowserHistoryEntry] = []
    @Published private(set) var error = ""
    private var session = Session()
    private let directory: URL
    private var writableFiles: Set<String> = []
    private static let bookmarkFile = "Bookmarks.json"
    private static let historyFile = "History.json"
    private static let sessionFile = "TabSession.json"

    var savedTabs: [SavedBrowserTab] { session.tabs }
    var savedSelection: Int { session.selectedTab }

    init(directory: URL = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]) {
        self.directory = directory
        do { try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true) }
        catch { self.error = "保存先を作成できません"; return }
        bookmarks = load([BrowserBookmark].self, name: Self.bookmarkFile, fallback: [])
            .filter { BrowserAddress.webURL($0.url.absoluteString) != nil }
        history = Array(load([BrowserHistoryEntry].self, name: Self.historyFile, fallback: [])
            .filter { BrowserAddress.webURL($0.url.absoluteString) != nil }.prefix(1000))
        session = load(Session.self, name: Self.sessionFile, fallback: .init())
    }

    private func load<T: Decodable>(_ type: T.Type, name: String, fallback: T) -> T {
        do {
            let file = directory.appendingPathComponent(name)
            let value = FileManager.default.fileExists(atPath: file.path)
                ? try JSONDecoder().decode(type, from: Data(contentsOf: file)) : fallback
            writableFiles.insert(name)
            return value
        } catch { self.error = "\(name)を読み込めません。元ファイルは保持します"; return fallback }
    }

    private func persist<T: Encodable>(_ value: T, name: String, erasing: Bool = false) throws {
        guard erasing || writableFiles.contains(name) else { throw CocoaError(.fileWriteNoPermission) }
        try JSONEncoder().encode(value).write(to: directory.appendingPathComponent(name), options: .atomic)
        writableFiles.insert(name)
        error = ""
    }

    private func save<T: Encodable>(_ value: T, name: String, erasing: Bool = false) {
        do { try persist(value, name: name, erasing: erasing) }
        catch { self.error = "\(name)を保存できません: \(error.localizedDescription)" }
    }

    func addBookmark(title: String, url: URL) {
        guard BrowserAddress.webURL(url.absoluteString) != nil else { return }
        if let index = bookmarks.firstIndex(where: { $0.url == url }) { bookmarks[index].title = title }
        else { bookmarks.append(.init(title: title, url: url)) }
        save(bookmarks, name: Self.bookmarkFile)
    }

    func removeBookmark(_ id: UUID) { bookmarks.removeAll { $0.id == id }; save(bookmarks, name: Self.bookmarkFile) }

    func record(title: String, url: URL) {
        guard BrowserAddress.webURL(url.absoluteString) != nil else { return }
        if history.first?.url == url { history[0].title = title; history[0].date = Date() }
        else { history.insert(.init(title: title, url: url), at: 0) }
        history = Array(history.prefix(1000))
        save(history, name: Self.historyFile)
    }

    func clearHistory() { history = []; save(history, name: Self.historyFile, erasing: true) }

    func saveSession(_ tabs: [SavedBrowserTab], selection: Int) {
        session.tabs = tabs
        session.selectedTab = max(0, min(selection, tabs.count - 1))
        save(session, name: Self.sessionFile)
    }

    func eraseHistoryAndSession() throws {
        history = []
        session = .init()
        try persist(history, name: Self.historyFile, erasing: true)
        try persist(session, name: Self.sessionFile, erasing: true)
    }
}
