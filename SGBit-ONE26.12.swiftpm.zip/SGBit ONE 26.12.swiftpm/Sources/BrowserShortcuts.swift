import SwiftUI

@MainActor
struct BrowserShortcuts: View {
    @ObservedObject var browser: RelayBrowserModel
    @ObservedObject var dialogs: BrowserDialogs
    let blocked: Bool
    let newTab: (Bool) -> Void
    let focusAddress: () -> Void

    private func moveTab(_ offset: Int) {
        guard let id = browser.selectedID, let index = browser.tabs.firstIndex(where: { $0.id == id }), !browser.tabs.isEmpty else { return }
        browser.select(browser.tabs[(index + offset + browser.tabs.count) % browser.tabs.count].id)
    }

    var body: some View {
        Group {
            Button("新しいタブ") { newTab(browser.selectedTab?.isPrivate ?? false) }
                .keyboardShortcut("t", modifiers: .command).disabled(browser.proxyPort == nil)
            Button("プライベートタブを開く") { newTab(true) }
                .keyboardShortcut("n", modifiers: [.command, .shift]).disabled(browser.proxyPort == nil)
            Button("タブを閉じる") { if let id = browser.selectedID { browser.close(id) } }.keyboardShortcut("w", modifiers: .command)
            Button("URL欄を選択", action: focusAddress).keyboardShortcut("l", modifiers: .command)
            Button("再読み込み") { if let tab = browser.selectedTab { browser.reload(tab) } }.keyboardShortcut("r", modifiers: .command)
            Button("前のタブ") { moveTab(-1) }.keyboardShortcut("[", modifiers: [.command, .shift])
            Button("次のタブ") { moveTab(1) }.keyboardShortcut("]", modifiers: [.command, .shift])
        }
        .disabled(blocked || dialogs.request != nil || browser.isClearingData || !browser.isSceneActive)
        .frame(width: 0, height: 0).opacity(0).allowsHitTesting(false).accessibilityHidden(true)
    }
}
