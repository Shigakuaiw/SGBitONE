import SwiftUI
import WebKit
import UIKit
import ImageIO

@MainActor
final class BrowserTab: NSObject, ObservableObject, Identifiable, WKNavigationDelegate, WKUIDelegate {
    let id = UUID()
    let webView: WKWebView
    let pageInput: BrowserPageInput
    let dialogs = BrowserDialogs()
    let isPrivate: Bool
    @Published private(set) var desktop: Bool
    @Published private(set) var displayMode: BrowserDisplayMode
    @Published private(set) var connectionState: BrowserConnectionState = .empty
    private(set) var connectionURL: URL?
    private var connectionCommitted = false
    private var connectionFailed = false
    var pendingRestoreURL: URL?
    private(set) var requestedURL: URL?
    @Published var address = ""
    @Published var title = "新しいタブ"
    @Published var status = "URLを入力してください"
    @Published private(set) var isLoading = false
    @Published private(set) var canGoBack = false
    @Published private(set) var canGoForward = false
    @Published var barsHidden = false
    @Published private(set) var favicon: UIImage?
    @Published var findVisible = false
    @Published var findQuery = ""
    @Published private(set) var findMessage = ""
    private weak var browser: RelayBrowserModel?
    private var observations: [NSKeyValueObservation] = []
    private var observedURL: URL?
    private var iconTask: Task<Void, Never>?
    private var scrollState = BrowserScrollState()

    var summaryStatus: String {
        if isLoading { return "読み込み中" }
        if status.hasPrefix("読み込み失敗") { return "読み込み失敗" }
        if status.hasPrefix("読み込みが中断") { return "読み込み中断" }
        return status
    }


    var isStartPage: Bool {
        guard !isLoading else { return false }
        if let url = webView.url {
            return url.absoluteString == "about:blank"
        }
        return requestedURL == nil && pendingRestoreURL == nil
    }

    init(configuration: WKWebViewConfiguration, browser: RelayBrowserModel, isPrivate: Bool = false,
         desktop: Bool = true, displayMode: BrowserDisplayMode = .automatic, restoring saved: SavedBrowserTab? = nil) {
        self.browser = browser
        self.isPrivate = isPrivate
        self.desktop = desktop
        self.displayMode = displayMode
        pendingRestoreURL = saved?.url.flatMap { BrowserAddress.webURL($0.absoluteString) }
        let input = BrowserPageInput()
        pageInput = input
        input.install(in: configuration)
        webView = WKWebView(frame: .zero, configuration: configuration)
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        super.init()
        pageInput.attach(webView)
        applyUserAgent()
        if let saved { title = saved.title; address = pendingRestoreURL?.absoluteString ?? "" }
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.panGestureRecognizer.addTarget(self, action: #selector(pagePanned(_:)))
        observations = [webView.observe(\.title, options: [.new]) { [weak self] _, _ in
            Task { @MainActor in self?.sync() }
        }, webView.observe(\.url, options: [.new]) { [weak self] _, _ in
            Task { @MainActor in self?.sync() }
        }, webView.observe(\.canGoBack, options: [.new]) { [weak self] _, _ in
            Task { @MainActor in self?.sync() }
        }, webView.observe(\.canGoForward, options: [.new]) { [weak self] _, _ in
            Task { @MainActor in self?.sync() }
        }, webView.observe(\.serverTrust, options: [.new]) { [weak self] _, _ in
            Task { @MainActor in self?.syncConnection() }
        }, webView.observe(\.hasOnlySecureContent, options: [.new]) { [weak self] _, _ in
            Task { @MainActor in self?.syncConnection() }
        }]
    }

    private func sync() {
        title = webView.title.flatMap { $0.isEmpty ? nil : $0 } ?? webView.url?.host ?? "新しいタブ"
        canGoBack = webView.canGoBack
        canGoForward = webView.canGoForward
        if webView.url != observedURL {
            observedURL = webView.url
            if let url = webView.url, url.scheme == "https" || url.scheme == "http" { address = url.absoluteString }
            if !isLoading { requestedURL = webView.url.flatMap { BrowserAddress.webURL($0.absoluteString) } }
            browser?.tabLocationChanged(self)
        }
        syncConnection()
    }

    private func syncConnection() {
        if connectionCommitted && !connectionFailed { connectionURL = webView.url }
        connectionState = BrowserConnectionState.classify(url: connectionURL, loading: isLoading,
            failed: connectionFailed, committed: connectionCommitted,
            hasTrust: webView.serverTrust != nil, onlySecureContent: webView.hasOnlySecureContent)
    }

    func interruptLoading() {
        dialogs.cancel()
        if isLoading {
            webView.stopLoading()
            isLoading = false
            status = "読み込みが中断されました。再読み込みしてください"
            connectionFailed = true
            syncConnection()
        }
    }

    func dispose() {
        dialogs.cancel()
        pageInput.dispose()
        iconTask?.cancel()
        webView.scrollView.panGestureRecognizer.removeTarget(self, action: #selector(pagePanned(_:)))
        observations.removeAll()
        webView.endEditing(true)
        webView.stopLoading()
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
        webView.removeFromSuperview()
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 preferences: WKWebpagePreferences,
                 decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
        let scheme = navigationAction.request.url?.scheme?.lowercased()
        preferences.preferredContentMode = desktop ? .desktop : .mobile
        let isDownload = navigationAction.shouldPerformDownload && (scheme == "blob" || scheme == "data")
        guard scheme == "https" || scheme == "http" || scheme == "about" || isDownload else {
            if navigationAction.targetFrame?.isMainFrame != false {
                isLoading = false
                status = "HTTP / HTTPS以外のURLは開けません"
            }
            decisionHandler(.cancel, preferences)
            return
        }
        guard browser?.proxyPort != nil, browser?.isClearingData == false, browser?.security.locked == false else {
            isLoading = false
            status = "中継が未接続です。再読み込みで再接続してください"
            decisionHandler(.cancel, preferences)
            return
        }
        if navigationAction.targetFrame?.isMainFrame == true,
           let url = navigationAction.request.url.flatMap({ BrowserAddress.webURL($0.absoluteString) }) {
            requestedURL = url
        }
        decisionHandler(navigationAction.shouldPerformDownload ? .download : .allow, preferences)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        let scheme = navigationAction.request.url?.scheme?.lowercased()
        guard navigationAction.targetFrame == nil, scheme == "https" || scheme == "http" || scheme == "about" else { return nil }
        // WebKit loads the request itself, preserving POST bodies and window.opener.
        return browser?.newTab(configuration: configuration, isPrivate: isPrivate, displayMode: displayMode)?.webView
    }

    func webViewDidClose(_ webView: WKWebView) { browser?.close(id) }

    private func presentDialog(_ request: BrowserDialogRequest) {
        guard let browser, browser.selectedID == id, browser.isSceneActive,
              !browser.security.locked, !browser.isClearingData else { request.finish(nil); return }
        dialogs.show(request)
    }

    private func dialogOrigin(_ frame: WKFrameInfo) -> String {
        let origin = frame.securityOrigin
        return BrowserDialogRequest.origin(scheme: origin.`protocol`, host: origin.host, port: origin.port)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        presentDialog(BrowserDialogRequest(kind: .alert, origin: dialogOrigin(frame), message: message) { _ in completionHandler() })
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        presentDialog(BrowserDialogRequest(kind: .confirm, origin: dialogOrigin(frame), message: message) { answer in
            completionHandler(answer != nil)
        })
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        presentDialog(BrowserDialogRequest(kind: .prompt, origin: dialogOrigin(frame), message: prompt, defaultText: defaultText ?? "") { answer in
            completionHandler(answer?.text)
        })
    }

    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge,
                 completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        authenticate(challenge, completionHandler: completionHandler)
    }

    private func authenticate(_ challenge: URLAuthenticationChallenge,
                              completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        let space = challenge.protectionSpace
        guard space.authenticationMethod == NSURLAuthenticationMethodHTTPBasic else {
            completionHandler(.performDefaultHandling, nil); return
        }
        guard !space.isProxy(), let scheme = space.`protocol`, ["http", "https"].contains(scheme.lowercased()) else {
            completionHandler(.cancelAuthenticationChallenge, nil); return
        }
        let origin = BrowserDialogRequest.origin(scheme: scheme, host: space.host, port: space.port)
        var message = "この接続先のユーザー名とパスワードを入力してください。"
        if let realm = space.realm, !realm.isEmpty { message += "\nRealm: \(realm)" }
        if challenge.previousFailureCount > 0 { message += "\n認証に失敗しました。入力内容を確認してください。" }
        presentDialog(BrowserDialogRequest(kind: .authentication, origin: origin, message: message) { answer in
            guard let answer else { completionHandler(.cancelAuthenticationChallenge, nil); return }
            let credential = URLCredential(user: answer.username, password: answer.password, persistence: .none)
            completionHandler(.useCredential, credential)
        })
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        dialogs.cancel()
        pageInput.reset()
        isLoading = true
        connectionCommitted = false; connectionFailed = false; connectionURL = nil
        syncConnection()
        iconTask?.cancel()
        favicon = nil
        barsHidden = false
        status = "読み込み中…"
        sync()
    }

    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        connectionCommitted = true
        syncConnection()
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        isLoading = false
        status = "読み込み完了"
        requestedURL = webView.url.flatMap { BrowserAddress.webURL($0.absoluteString) }
        sync()
        loadFavicon()
        browser?.tabFinished(self)
    }

    private func fail(_ error: Error) {
        dialogs.cancel()
        let failure = error as NSError
        if failure.domain == NSURLErrorDomain && failure.code == NSURLErrorCancelled { return }
        isLoading = false
        connectionFailed = true
        status = "読み込み失敗 [\(failure.domain) \(failure.code)]: \(failure.localizedDescription)"
        sync()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!,
                 withError error: Error) { fail(error) }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!,
                 withError error: Error) { fail(error) }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        dialogs.cancel()
        pageInput.reset()
        isLoading = false
        status = "WebViewが終了しました。再読み込みしてください"
        connectionCommitted = false; connectionFailed = true; connectionURL = nil
        syncConnection()
    }

    func load(_ url: URL) {
        pendingRestoreURL = nil
        requestedURL = url
        webView.load(URLRequest(url: url))
        browser?.persistSession()
    }

    func loadPendingRestore() {
        guard browser?.proxyPort != nil, browser?.security.locked == false, let url = pendingRestoreURL else { return }
        load(url)
    }

    private func applyUserAgent() {
        if desktop { webView.customUserAgent = RelayBrowserModel.userAgent }
        else {
            let version = UIDevice.current.systemVersion.replacingOccurrences(of: ".", with: "_")
            let device = UIDevice.current.userInterfaceIdiom == .pad ? "iPad; CPU OS" : "iPhone; CPU iPhone OS"
            webView.customUserAgent = "Mozilla/5.0 (\(device) \(version) like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/\(UIDevice.current.systemVersion) Mobile/15E148 Safari/604.1"
        }
    }

    func setDesktop(_ value: Bool) {
        setDisplayMode(value ? .desktop : .mobile)
    }

    func setDisplayMode(_ mode: BrowserDisplayMode) {
        guard displayMode != mode else { return }
        displayMode = mode
        let next = mode.usesDesktop(width: browser?.viewportWidth ?? 0)
        let changed = desktop != next
        desktop = next
        applyUserAgent()
        browser?.persistSession()
        if changed && webView.url != nil { browser?.reload(self) }
    }

    func updateAutomaticDesktop(width: CGFloat) {
        guard displayMode == .automatic else { return }
        let next = displayMode.usesDesktop(width: width)
        guard desktop != next else { return }
        desktop = next
        applyUserAgent()
    }

    func find(backwards: Bool = false) {
        let config = WKFindConfiguration()
        config.backwards = backwards
        config.wraps = true
        webView.find(findQuery, configuration: config) { [weak self] result in
            self?.findMessage = result.matchFound ? "一致" : "見つかりません"
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) { beginDownload(download) }
    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { beginDownload(download) }

    private func beginDownload(_ download: WKDownload) {
        guard let browser, !browser.security.locked, !browser.isClearingData else { download.cancel(nil); return }
        isLoading = false
        status = "ダウンロードを開始しました"
        requestedURL = webView.url.flatMap { BrowserAddress.webURL($0.absoluteString) }
        browser.downloads.attach(download, isPrivate: isPrivate) { [weak self] challenge, completion in
            guard let self else { completion(.cancelAuthenticationChallenge, nil); return }
            self.authenticate(challenge, completionHandler: completion)
        }
        browser.persistSession()
    }

    @objc private func pagePanned(_ gesture: UIPanGestureRecognizer) {
        let scroll = webView.scrollView
        if gesture.state == .began { scrollState = BrowserScrollState(hidden: barsHidden) }
        guard gesture.state == .changed else { return }
        let hidden = scrollState.update(translation: gesture.translation(in: scroll).y,
                                        atTop: scroll.contentOffset.y <= -scroll.adjustedContentInset.top + 4,
                                        canScroll: scroll.contentSize.height > scroll.bounds.height + 24)
        if barsHidden != hidden { barsHidden = hidden }
    }

    private func loadFavicon() {
        iconTask?.cancel()
        guard let pageURL = webView.url, pageURL.scheme == "https" || pageURL.scheme == "http",
              let session = browser?.sessionForIcons(privateTab: isPrivate) else { return }
        iconTask = Task { @MainActor [weak self] in
            guard let self else { return }
            let declared = (try? await self.webView.callAsyncJavaScript(
                "return Array.from(document.querySelectorAll('link[rel~=icon]')).slice(0, 2).map(link => link.href)",
                arguments: [:], in: nil, contentWorld: .defaultClient)) as? [String] ?? []
            // Icons use HTTPS even on HTTP pages; they never get a system-default session.
            var fallback = URLComponents(url: pageURL, resolvingAgainstBaseURL: false)
            fallback?.scheme = "https"
            if pageURL.scheme == "http" { fallback?.port = nil }
            fallback?.path = "/favicon.ico"
            fallback?.query = nil
            fallback?.fragment = nil
            let candidates = declared.compactMap { URL(string: $0, relativeTo: pageURL)?.absoluteURL } + [fallback?.url].compactMap { $0 }
            for url in candidates where url.scheme == "https" && url.user == nil && url.password == nil {
                if Task.isCancelled { return }
                do {
                    let (bytes, response) = try await session.bytes(from: url)
                    defer { bytes.task.cancel() }
                    guard let response = response as? HTTPURLResponse, response.statusCode == 200,
                          response.expectedContentLength <= 262144 else { continue }
                    var data = Data()
                    for try await byte in bytes {
                        try Task.checkCancellation()
                        guard data.count < 262144 else { throw URLError(.dataLengthExceedsMaximum) }
                        data.append(byte)
                    }
                    guard !Task.isCancelled, self.webView.url == pageURL,
                          let source = CGImageSourceCreateWithData(data as CFData, nil),
                          let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                            kCGImageSourceCreateThumbnailFromImageAlways: true,
                            kCGImageSourceThumbnailMaxPixelSize: 32,
                            kCGImageSourceCreateThumbnailWithTransform: true
                          ] as CFDictionary) else { continue }
                    self.favicon = UIImage(cgImage: image)
                    return
                } catch { if Task.isCancelled { return } }
            }
        }
    }
}

@MainActor
struct RelayWebView: UIViewControllerRepresentable {
    let webView: WKWebView

    func makeUIViewController(context: Context) -> WebContentController {
        let controller = WebContentController()
        controller.show(webView)
        return controller
    }

    func updateUIViewController(_ controller: WebContentController, context: Context) {
        controller.show(webView)
    }
}

@MainActor
final class WebContentController: UIViewController {
    private weak var current: WKWebView?

    func show(_ webView: WKWebView) {
        guard current !== webView else { return }
        loadViewIfNeeded()
        current?.endEditing(true)
        current?.removeFromSuperview()
        current = webView
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
}
