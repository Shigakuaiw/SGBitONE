import SwiftUI
import WebKit

@available(iOS 17.0, *)
struct ONEPasswordFillSheet: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var store = ONEPasswordStore.shared
    let webView: WKWebView
    @State private var master = ""
    @State private var status = ""

    private var site: URL? { webView.url }
    private var safeHost: String? {
        guard let site, site.scheme?.lowercased() == "https", let host = site.host,
              !host.isEmpty, !host.contains(" ") else { return nil }
        return host
    }
    var body: some View {
        NavigationStack {
            Form {
                if let safeHost {
                    Section("現在のサイト") { Text("https://\(safeHost)") }
                    if !store.unlocked {
                        Section("SGBit Passwords を解除") {
                            if store.configured {
                                SecureField("独自マスターパスワード", text: $master)
                                Button("解除") { if store.unlock(master: master) { master = "" } }
                            } else { Text("まず「パスワード」で保管庫を作成してください") }
                        }
                    } else {
                        Section("このサイトに登録されているアカウント") {
                            let candidates = store.matching(host: safeHost)
                            if candidates.isEmpty { Text("一致する登録はありません").foregroundStyle(.secondary) }
                            ForEach(candidates) { item in
                                Button {
                                    fill(item, host: safeHost)
                                } label: { Label(item.username, systemImage: "key.fill") }
                            }
                        }
                    }
                } else {
                    Section { Text("安全のためHTTPSサイトでのみ入力できます") }
                }
                if !status.isEmpty { Section { Text(status).foregroundStyle(.secondary) } }
                if !store.message.isEmpty { Section { Text(store.message).font(.caption).foregroundStyle(.red) } }
            }
            .navigationTitle("ログイン情報を入力")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("閉じる") { dismiss() } } }
        }
    }
    private func fill(_ entry: ONELogin, host: String) {
        guard webView.url?.scheme == "https", webView.url?.host?.lowercased() == host.lowercased() else {
            status = "ページが変わりました。もう一度開いてください"; return
        }
        // Script is invoked only by a user gesture. Host check runs again inside the page.
        // No credential is sent to remote updater / administrative API.
        let js = """
        return (() => {
          if (location.protocol !== 'https:' || location.hostname.toLowerCase() !== expectedHost.toLowerCase()) return false;
          const pw = [...document.querySelectorAll('input[type=password]')].find(e => !e.disabled && !e.readOnly);
          if (!pw) return false;
          const form = pw.form;
          const names = form ? [...form.querySelectorAll('input')] : [...document.querySelectorAll('input')];
          const user = names.find(e => !e.disabled && !e.readOnly && e !== pw &&
            (e.autocomplete === 'username' || /user|email|login/i.test(e.name || '') || e.type === 'email')) ||
            names.find(e => !e.disabled && !e.readOnly && e !== pw && (e.type === 'text' || e.type === 'email'));
          function setField(el, value) {
            if (!el) return;
            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
            setter.call(el, value);
            el.dispatchEvent(new Event('input', {bubbles:true}));
            el.dispatchEvent(new Event('change', {bubbles:true}));
          }
          setField(user, loginUser);
          setField(pw, loginPassword);
          return true;
        })()
        """
        // callAsyncJavaScript arguments avoid interpolating secrets into script source.
        webView.callAsyncJavaScript(js, arguments: ["expectedHost": host,
            "loginUser": entry.username, "loginPassword": entry.password], in: nil, in: .page) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let value):
                    if (value as? Bool) == true { dismiss() }
                    else { status = "ログイン欄が見つかりません。手動入力してください" }
                case .failure: status = "このページでは入力できませんでした"
                }
            }
        }
    }
}
