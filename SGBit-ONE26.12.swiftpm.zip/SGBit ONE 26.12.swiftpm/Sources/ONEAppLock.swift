import SwiftUI
import Security
import CryptoKit

// Separate from the browser's optional website/PIN protection.
@MainActor
final class ONEAppLock: ObservableObject {
    private struct StoredCode: Codable {
        let salt: Data
        let digest: Data
    }

    @Published private(set) var hasCode = false
    @Published private(set) var unlocked = false
    @Published var error = ""
    private var stored: StoredCode?
    private var attempts = 0
    private var retryAfter = Date.distantPast

    private var itemQuery: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: (Bundle.main.bundleIdentifier ?? "SGBitONE") + ".one-app-passcode-v1",
         kSecAttrAccount as String: "app-passcode"]
    }

    init() {
        var query = itemQuery
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        if status == errSecItemNotFound { return }
        if status == errSecSuccess,
           let data = item as? Data,
           let decoded = try? JSONDecoder().decode(StoredCode.self, from: data),
           decoded.salt.count == 16, decoded.digest.count == 32 {
            stored = decoded
            hasCode = true
        } else {
            // Fail closed: never bypass a code when keychain is unavailable or corrupt.
            hasCode = true
            error = "パスコードを読み込めません。Keychainを確認してください。"
        }
    }

    private func hash(_ code: String, salt: Data) -> Data {
        var result = Data(SHA256.hash(data: salt + Data(code.utf8)))
        // Slow down offline guessing without using CryptoKit's unavailable PBKDF2 API.
        for _ in 0..<12000 { result = Data(SHA256.hash(data: result + salt)) }
        return result
    }

    func create(_ code: String) -> Bool {
        guard !hasCode, code.count == 6, code.utf8.allSatisfy({ (48...57).contains($0) }) else {
            error = "数字6桁で設定してください"
            return false
        }
        var salt = Data(count: 16)
        let randomStatus = salt.withUnsafeMutableBytes { buffer in
            SecRandomCopyBytes(kSecRandomDefault, buffer.count, buffer.baseAddress!)
        }
        guard randomStatus == errSecSuccess else { error = "乱数の生成に失敗しました"; return false }
        let record = StoredCode(salt: salt, digest: hash(code, salt: salt))
        guard let data = try? JSONEncoder().encode(record) else { error = "保存に失敗しました"; return false }
        var query = itemQuery
        query[kSecValueData as String] = data
        query[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status == errSecSuccess else { error = "パスコードを保存できません（\(status)）"; return false }
        stored = record
        hasCode = true
        unlocked = true
        error = ""
        return true
    }

    func unlock(_ code: String) -> Bool {
        guard hasCode, let stored else { error = "パスコードを読み込めません"; return false }
        guard Date() >= retryAfter else { error = "時間をおいて再試行してください"; return false }
        guard code.count == 6 else { error = "数字6桁を入力してください"; return false }
        let candidate = hash(code, salt: stored.salt)
        let matching = zip(candidate, stored.digest).reduce(UInt8(0)) { $0 | ($1.0 ^ $1.1) } == 0
        if matching {
            attempts = 0
            error = ""
            unlocked = true
            return true
        }
        attempts += 1
        if attempts >= 5 { retryAfter = Date().addingTimeInterval(30); attempts = 0; error = "5回間違えたため、30秒後に再試行してください" }
        else { error = "パスコードが違います" }
        return false
    }

    func lock() {
        if hasCode { unlocked = false; error = "" }
    }
}

@available(iOS 17.0, *)
struct ONELockScreen: View {
    @ObservedObject var lock: ONEAppLock
    @State private var showingKeypad = false
    @State private var input = ""
    @State private var confirmation = ""
    @State private var setupStep = 0
    @State private var clock = Date()
    @AppStorage("sgbit.lock.clock.size") private var clockSize = 84.0
    @AppStorage("sgbit.lock.clock.style") private var clockStyle = "glass"
    @AppStorage("sgbit.lock.clock.color") private var clockColor = "white"
    @AppStorage("sgbit.lock.clock.height") private var clockHeight = 0.15
    @AppStorage("sgbit.lock.glass.enabled") private var lockGlassEnabled = true

    private var clockTint: Color {
        switch clockColor {
        case "blue": return Color(red: 0.55, green: 0.80, blue: 1)
        case "purple": return Color(red: 0.83, green: 0.68, blue: 1)
        case "orange": return Color(red: 1, green: 0.81, blue: 0.50)
        default: return .white
        }
    }

    private var clockWeight: Font.Weight {
        switch clockStyle {
        case "bold": return .bold
        case "thin": return .ultraLight
        default: return .light
        }
    }


    var body: some View {
        GeometryReader { geo in
            ZStack {
                ONEWallpaperBackground(area: .lock)
                Color.black.opacity(0.22).ignoresSafeArea().allowsHitTesting(false)
                if !lock.hasCode || showingKeypad {
                    keypad
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                } else {
                    VStack(spacing: 0) {
                        Spacer(minLength: max(12, geo.size.height * min(0.35, max(0.02, clockHeight))))
                        VStack(spacing: 7) {
                            Text(clock, format: .dateTime.weekday(.wide).month().day())
                                .font(.system(size: 18, weight: .medium))
                            Text(clock, format: .dateTime.hour().minute())
                                .font(.system(size: min(clockSize, geo.size.width * 0.34), weight: clockWeight, design: .rounded))
                                .minimumScaleFactor(0.55)
                                .lineLimit(1)
                                .shadow(color: .black.opacity(0.35), radius: 6, y: 3)
                        }
                        .foregroundStyle(clockTint)
                        .padding(.horizontal, 25)
                        .padding(.vertical, lockGlassEnabled ? 16 : 0)
                        .background {
                            if lockGlassEnabled {
                                RoundedRectangle(cornerRadius: 28, style: .continuous)
                                    .fill(.ultraThinMaterial)
                                    .overlay {
                                        RoundedRectangle(cornerRadius: 28)
                                            .strokeBorder(.white.opacity(0.20), lineWidth: 0.7)
                                    }
                            }
                        }
                        Spacer()
                        Image(systemName: "lock.fill")
                            .font(.system(size: 27))
                            .padding(.bottom, 22)
                        Button { revealKeypad() } label: {
                            VStack(spacing: 8) {
                                Image(systemName: "chevron.up").font(.title2.bold())
                                Text("上にスワイプしてロック解除").font(.subheadline)
                            }
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 85)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .padding(.bottom, 20)
                    }
                    .frame(maxWidth: .infinity)
                    .contentShape(Rectangle())
                    .gesture(DragGesture(minimumDistance: 40).onEnded { value in
                        if value.translation.height < -55 {
                            revealKeypad()
                        }
                    })
                    .transition(.opacity)
                }
            }
            .foregroundStyle(.white)
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .onReceive(Timer.publish(every: 20, on: .main, in: .common).autoconnect()) { clock = $0 }
        .privacySensitive()
    }

    // PIN entry intentionally has NO focused text field: only on-screen buttons.
    private func revealKeypad() {
        withAnimation(.easeInOut(duration: 0.25)) { showingKeypad = true }
    }

    private var keypad: some View {
        ScrollView {
            VStack(spacing: 18) {
                Image(systemName: "lock.shield.fill").font(.system(size: 34))
                Text(!lock.hasCode ? (setupStep == 0 ? "SGBit ONE パスコード設定" : "もう一度入力して確認") : "SGBit ONE ロック解除")
                    .font(.title3.bold())
                Text(!lock.hasCode ? "端末のパスコードとは別の数字6桁を設定" : "設定した数字6桁を入力")
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.8))
                HStack(spacing: 16) {
                    ForEach(0..<6, id: \.self) { i in
                        Circle()
                            .fill(i < input.count ? .white : .clear)
                            .frame(width: 13, height: 13)
                            .overlay(Circle().stroke(.white.opacity(0.8), lineWidth: 1.5))
                    }
                }.padding(.vertical, 12)
                Text(lock.error).font(.caption).foregroundStyle(.white).frame(minHeight: 34)
                VStack(spacing: 12) {
                    ForEach(0..<4, id: \.self) { row in
                        HStack(spacing: 24) {
                            ForEach(0..<3, id: \.self) { col in
                                let digit = row * 3 + col + 1
                                if row == 3 && col == 0 {
                                    Color.clear.frame(width: 72, height: 72)
                                } else if row == 3 && col == 2 {
                                    Button { if !input.isEmpty { input.removeLast() } } label: {
                                        Image(systemName: "delete.left").font(.title2)
                                            .frame(width: 72, height: 72)
                                            .background(.ultraThinMaterial, in: Circle())
                                            .overlay(Circle().strokeBorder(.white.opacity(0.30), lineWidth: 1))
                                    }.buttonStyle(.plain)
                                } else {
                                    Button { appendDigit(row == 3 ? "0" : "\(digit)") } label: {
                                        Text(row == 3 ? "0" : "\(digit)")
                                            .font(.title.weight(.regular))
                                            .frame(width: 72, height: 72)
                                            .background(.ultraThinMaterial, in: Circle())
                                            .overlay(Circle().strokeBorder(.white.opacity(0.30), lineWidth: 1))
                                            .shadow(color: .black.opacity(0.15), radius: 8, y: 4)
                                    }.buttonStyle(.plain)
                                }
                            }
                        }
                    }
                }
                if lock.hasCode {
                    Button("ロック画面に戻る") {
                        input = ""
                        withAnimation { showingKeypad = false }
                    }.font(.footnote).padding(.top, 8)
                }
            }
            .padding(.horizontal, 15)
            .padding(.vertical, 28)
            .frame(maxWidth: .infinity)
        }
        .scrollIndicators(.hidden)
    }

    private func appendDigit(_ digit: String) {
        guard input.count < 6 else { return }
        input += digit
        if input.count == 6 { commitPasscode(input) }
    }

    private func commitPasscode(_ entered: String) {
        guard entered.count == 6 else { return }
        input = ""
        if lock.hasCode {
            _ = lock.unlock(entered)
        } else if setupStep == 0 {
            confirmation = entered
            setupStep = 1
        } else {
            if entered == confirmation {
                if lock.create(entered) { confirmation = ""; setupStep = 0 }
            } else {
                lock.error = "一致しません。最初から設定してください"
                confirmation = ""
                setupStep = 0
            }
        }
    }
}
