import SwiftUI
import Foundation
import CryptoKit

// Remote control applies to the app UI, not to arbitrary system networking.
@MainActor final class ONENetworkControl: ObservableObject {
    static let shared = ONENetworkControl()
    @AppStorage("sgbit.control.url") var endpoint = "https://sgbit-one-control.gakushisama.workers.dev/status"
    @AppStorage("sgbit.control.adminVerifier") private var verifier = ""
    @Published private(set) var restricted = false
    @Published private(set) var message = "現在オンライン機能はメンテナンス中です。"
    @Published private(set) var reason = "maintenance"
    @Published private(set) var lastChecked: Date?
    @Published private(set) var error: String?
    @Published var overrideUntil: Date?
    private var task: Task<Void, Never>?
    private init() {}
    var blocked: Bool { restricted && !(overrideUntil.map { $0 > Date() } ?? false) }
    var hasLocalPassword: Bool { !verifier.isEmpty }
    private func digest(_ input: String) -> String { SHA256.hash(data: Data(input.utf8)).map { String(format: "%02x", $0) }.joined() }
    func setLocalPassword(_ value: String) { if value.count >= 8 { verifier = digest(value) } }
    func unlock(_ value: String) -> Bool {
        guard !verifier.isEmpty, digest(value) == verifier else { return false }
        overrideUntil = Date().addingTimeInterval(1800)
        return true
    }
    func lockAgain() { overrideUntil = nil }
    func start() {
        guard task == nil else { return }
        task = Task { [weak self] in
            while !Task.isCancelled {
                await self?.refresh()
                try? await Task.sleep(for: .seconds(30))
            }
        }
    }
    func refresh() async {
        guard let url = URL(string: endpoint), url.scheme == "https", url.host != nil else {
            error = "HTTPSの制御URLが未設定です"; return
        }
        do {
            var req = URLRequest(url: url)
            req.cachePolicy = .reloadIgnoringLocalCacheData
            req.timeoutInterval = 8
            let (data, response) = try await URLSession.shared.data(for: req)
            guard (response as? HTTPURLResponse)?.statusCode == 200, data.count < 8192 else { throw URLError(.badServerResponse) }
            let obj = try JSONDecoder().decode(ONEControlPayload.self, from: data)
            guard obj.schema == 1 else { throw URLError(.cannotParseResponse) }
            restricted = obj.mode != "normal"
            reason = obj.mode
            message = obj.message ?? (obj.mode == "maintenance" ? "現在メンテナンス中です。" : "オンライン機能へのアクセスが制限されています。")
            lastChecked = Date(); error = nil
        } catch { self.error = "制御サーバーを確認できません: \(error.localizedDescription)" }
    }
}
private struct ONEControlPayload: Decodable {
    let schema: Int
    let mode: String
    let message: String?
}

struct ONENetworkBlockScreen: View {
    @ObservedObject var control = ONENetworkControl.shared
    @ObservedObject private var account = ONEAccount.shared
    @State private var password = ""
    @State private var feedback = ""
    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "network.slash").font(.system(size: 48)).foregroundStyle(.orange)
            Text(account.blocked ? "アカウントが制限されています" : (control.reason == "maintenance" ? "メンテナンス中" : "アクセスが制限されています")).font(.title2.bold())
            Text(account.blocked ? "管理者によりオンライン機能へのアクセスが制限されています。" : control.message).multilineTextAlignment(.center)
            Text("保存済みの音楽やオフラインデータは利用できます。")
                .font(.caption).foregroundStyle(.secondary)
            if !account.blocked { SecureField("管理者パスワード", text: $password).textContentType(.password)
                .textFieldStyle(.roundedBorder).frame(maxWidth: 320)
            Button("この端末で30分間解除") {
                if control.unlock(password) { password = ""; feedback = "解除しました" }
                else { feedback = "パスワードが違うか、未設定です" }
            }.buttonStyle(.borderedProminent)
            Text(feedback).font(.caption).foregroundStyle(.secondary)
            }
            Button("制限状態を再確認") { Task { await control.refresh(); await account.refresh() } }
        }.padding(25).frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct ONEControlSettings: View {
    @ObservedObject var control = ONENetworkControl.shared
    @State private var newPassword = ""
    @State private var notice = ""
    var body: some View {
        Section("オンライン機能の遠隔制御") {
            TextField("公開ステータスJSONのHTTPS URL", text: $control.endpoint)
                .textInputAutocapitalization(.never).autocorrectionDisabled()
            Button("今すぐ状態を確認") { Task { await control.refresh() } }
            Text(control.restricted ? "制限中: \(control.reason)" : "通常運用 / 未設定")
            if let error = control.error { Text(error).font(.caption).foregroundStyle(.orange) }
            SecureField("端末の緊急解除パスワード（8文字以上）", text: $newPassword)
            Button("緊急解除パスワードを登録") {
                if newPassword.count >= 8 { control.setLocalPassword(newPassword); newPassword = ""; notice = "登録しました" }
                else { notice = "8文字以上にしてください" }
            }
            if !notice.isEmpty { Text(notice).font(.caption) }
            if control.overrideUntil != nil { Button("緊急解除を終了") { control.lockAgain() } }
            Text("管理者パスワードはこの端末用です。遠隔制限の変更はサーバー側で行います。制御サーバーの障害時は直近の状態を保持します。")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
}
