import SwiftUI
import Foundation
import Security
import CryptoKit
import CommonCrypto

// SGBit Passwords: encrypted app-private file, unlocked by the user's own master password.
// Previous Keychain data is only read on the user's explicit import request; never deleted.
struct ONELogin: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var website: String
    var username: String
    var password: String
}

private struct ONESealedVault: Codable {
    let format: Int
    let salt: Data
    let ciphertext: Data
}

@MainActor
final class ONEPasswordStore: ObservableObject {
    static let shared = ONEPasswordStore()
    @Published private(set) var entries: [ONELogin] = []
    @Published private(set) var unlocked = false
    @Published var message = ""
    private var secretKey: SymmetricKey?
    private var salt: Data?
    private let workFactor: UInt32 = 240_000

    private var fileURL: URL {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return support.appendingPathComponent("SGBitPasswords.v1.enc")
    }
    var configured: Bool { FileManager.default.fileExists(atPath: fileURL.path) }

    private func random(_ count: Int) -> Data? {
        var bytes = [UInt8](repeating: 0, count: count)
        guard SecRandomCopyBytes(kSecRandomDefault, count, &bytes) == errSecSuccess else { return nil }
        return Data(bytes)
    }
    private func derive(_ password: String, salt: Data) -> SymmetricKey? {
        let pwd = Array(password.utf8)
        var output = [UInt8](repeating: 0, count: 32)
        let outputSize = output.count
        let result = pwd.withUnsafeBytes { input in
            salt.withUnsafeBytes { saltBytes in
                CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), input.baseAddress?.assumingMemoryBound(to: Int8.self),
                    pwd.count, saltBytes.baseAddress?.assumingMemoryBound(to: UInt8.self), salt.count,
                    CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), workFactor, &output, outputSize)
            }
        }
        guard result == kCCSuccess else { return nil }
        return SymmetricKey(data: Data(output))
    }
    private func write(_ values: [ONELogin], key: SymmetricKey, salt: Data) -> Bool {
        do {
            let plaintext = try JSONEncoder().encode(values)
            let sealed = try AES.GCM.seal(plaintext, using: key)
            guard let combined = sealed.combined else { throw NSError(domain: "Vault", code: 1) }
            let output = try JSONEncoder().encode(ONESealedVault(format: 1, salt: salt, ciphertext: combined))
            let parent = fileURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: parent, withIntermediateDirectories: true)
            try output.write(to: fileURL, options: [.atomic, .completeFileProtectionUnlessOpen])
            entries = values
            return true
        } catch {
            message = "暗号化ファイルの保存に失敗しました: \(error.localizedDescription)"
            return false
        }
    }
    func create(master: String, confirmation: String) -> Bool {
        guard !configured else { message = "すでに保管庫があります"; return false }
        guard master.count >= 12, master == confirmation else {
            message = "12文字以上の一致するマスターパスワードを設定してください"; return false
        }
        guard let newSalt = random(16), let key = derive(master, salt: newSalt) else {
            message = "暗号化キーを作れませんでした"; return false
        }
        guard write([], key: key, salt: newSalt) else { return false }
        salt = newSalt; secretKey = key; unlocked = true; message = ""; return true
    }
    func unlock(master: String) -> Bool {
        do {
            let box = try JSONDecoder().decode(ONESealedVault.self, from: Data(contentsOf: fileURL))
            guard box.format == 1, let key = derive(master, salt: box.salt),
                  let sealed = try? AES.GCM.SealedBox(combined: box.ciphertext),
                  let opened = try? AES.GCM.open(sealed, using: key),
                  let list = try? JSONDecoder().decode([ONELogin].self, from: opened) else {
                message = "パスワードが違うか、保管庫を読み込めません"; return false
            }
            salt = box.salt; secretKey = key; entries = list; unlocked = true; message = ""; return true
        } catch { message = "保管庫ファイルが見つからないか壊れています"; return false }
    }
    func lock() { unlocked = false; secretKey = nil; salt = nil; entries = [] }
    func upsert(_ entry: ONELogin) -> Bool {
        guard let key = secretKey, let salt else { return false }
        var next = entries
        if let index = next.firstIndex(where: { $0.id == entry.id }) { next[index] = entry }
        else { next.append(entry) }
        return write(next, key: key, salt: salt)
    }
    func remove(_ entry: ONELogin) -> Bool {
        guard let key = secretKey, let salt else { return false }
        return write(entries.filter { $0.id != entry.id }, key: key, salt: salt)
    }
    func matching(host: String) -> [ONELogin] {
        guard unlocked else { return [] }
        return entries.filter { item in
            let raw = item.website.trimmingCharacters(in: .whitespacesAndNewlines)
            let url = URL(string: raw.contains("://") ? raw : "https://" + raw)
            return url?.host?.lowercased() == host.lowercased()
        }
    }
    func importLegacy() {
        guard unlocked else { return }
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "net.bitbrowser.password-vault.v1",
            kSecAttrAccount as String: "vault", kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data,
              let old = try? JSONDecoder().decode([ONELogin].self, from: data) else {
            message = status == errSecItemNotFound ? "以前のKeychainデータは見つかりません" : "以前のデータを読み込めません"; return
        }
        var merged = entries
        for entry in old where !merged.contains(where: { $0.id == entry.id }) { merged.append(entry) }
        if let key = secretKey, let salt, write(merged, key: key, salt: salt) {
            message = "\(old.count)件の旧データを取り込みました。旧Keychainデータは削除していません。"
        }
    }
}

@available(iOS 17.0, *)
struct PasswordVaultView: View {
    @ObservedObject private var vault = ONEPasswordStore.shared
    @Environment(\.scenePhase) private var scenePhase
    @State private var master = ""
    @State private var confirmation = ""
    @State private var search = ""
    @State private var editing: ONELogin?
    @State private var showEditor = false
    @State private var revealed: Set<UUID> = []
    @State private var delete: ONELogin?
    @State private var showLegacyImport = false

    var body: some View {
        NavigationStack {
            Group {
                if !vault.unlocked { gateway } else { list }
            }
            .navigationTitle("SGBit Passwords")
            .onChange(of: scenePhase) { _, phase in if phase != .active { vault.lock() } }
            .alert("以前のKeychainデータを取り込む？", isPresented: $showLegacyImport) {
                Button("取り込む") { vault.importLegacy() }
                Button("キャンセル", role: .cancel) {}
            } message: { Text("古いデータは削除せず、新しい暗号化保管庫へコピーします。") }
            .sheet(isPresented: $showEditor) {
                if let editing { ONEPasswordEditor(entry: editing) { newEntry in
                    if vault.upsert(newEntry) { showEditor = false }
                }}
            }
            .confirmationDialog("ログイン情報を削除しますか？", isPresented: Binding(get: { delete != nil }, set: { if !$0 { delete = nil } })) {
                Button("削除", role: .destructive) { if let delete { _ = vault.remove(delete) }; delete = nil }
            }
        }
    }
    private var gateway: some View {
        Form {
            Section {
                Text(vault.configured ? "SGBit専用のマスターパスワードを入力" : "初回設定：SGBit専用のマスターパスワードを作成")
                SecureField("マスターパスワード", text: $master).textContentType(.newPassword)
                if !vault.configured { SecureField("確認用", text: $confirmation).textContentType(.newPassword) }
                Button(vault.configured ? "保管庫を開く" : "保管庫を作成") {
                    let ok = vault.configured ? vault.unlock(master: master) : vault.create(master: master, confirmation: confirmation)
                    if ok { master = ""; confirmation = "" }
                }
                .disabled(master.isEmpty || (!vault.configured && confirmation.isEmpty))
            }
            Section {
                Text("パスワードは独自のAES-GCM暗号化ファイルに保存されます。端末のFace ID / Touch IDで解除しません。")
                Text("マスターパスワードを忘れると復元できません。保管庫ファイルのバックアップも重要です。")
            }.font(.caption).foregroundStyle(.secondary)
            if !vault.message.isEmpty { Section { Text(vault.message).foregroundStyle(.red) } }
        }
    }
    // Keep SwiftUI's ForEach on the value-based overload, not the Binding overload.
    // A separately typed row prevents generic inference errors on iPad Swift Playgrounds.
    private var filteredEntries: [ONELogin] {
        vault.entries.filter { entry in
            search.isEmpty ||
                entry.website.localizedCaseInsensitiveContains(search) ||
                entry.username.localizedCaseInsensitiveContains(search)
        }
    }

    private var list: some View {
        List {
            Section {
                Label("保存先：SGBit ONEの暗号化保管庫", systemImage: "lock.shield")
                Button("以前のBit Keychainから取り込む", systemImage: "square.and.arrow.down") { showLegacyImport = true }
                Button("保管庫をロック", systemImage: "lock") { vault.lock() }
            }
            if !vault.message.isEmpty { Section { Text(vault.message).font(.caption) } }
            Section("保存済みログイン（\(vault.entries.count)）") {
                ForEach(filteredEntries, id: \.id) { (entry: ONELogin) in
                    ONEPasswordListRow(
                        entry: entry,
                        isRevealed: revealed.contains(entry.id),
                        toggleReveal: {
                            if revealed.contains(entry.id) { revealed.remove(entry.id) }
                            else { revealed.insert(entry.id) }
                        },
                        edit: { editing = entry; showEditor = true },
                        requestDelete: { delete = entry }
                    )
                }
            }
        }
        .searchable(text: $search)
        .toolbar { ToolbarItem(placement: .primaryAction) {
            Button("追加", systemImage: "plus") { editing = ONELogin(website: "", username: "", password: ""); showEditor = true }
        }}
    }
}

@available(iOS 17.0, *)
private struct ONEPasswordListRow: View {
    let entry: ONELogin
    let isRevealed: Bool
    let toggleReveal: () -> Void
    let edit: () -> Void
    let requestDelete: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(entry.website).font(.headline)
            Text(entry.username).font(.subheadline).foregroundStyle(.secondary)
            HStack {
                Text(isRevealed ? entry.password : "••••••••")
                    .lineLimit(1)
                Spacer()
                Button(isRevealed ? "隠す" : "表示", action: toggleReveal)
                    .buttonStyle(.borderless)
                Button("編集", action: edit)
                    .buttonStyle(.borderless)
            }
        }
        .swipeActions {
            Button("削除", role: .destructive, action: requestDelete)
        }
    }
}

@available(iOS 17.0, *)
private struct ONEPasswordEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State var entry: ONELogin
    var save: (ONELogin) -> Void
    @State private var reveal = false
    var body: some View {
        NavigationStack {
            Form {
                Section("ログイン先") {
                    TextField("example.com", text: $entry.website).textInputAutocapitalization(.never).autocorrectionDisabled()
                    TextField("ユーザー名・メールアドレス", text: $entry.username).textInputAutocapitalization(.never).autocorrectionDisabled()
                }
                Section("パスワード") {
                    HStack {
                        Group {
                            if reveal { TextField("パスワード", text: $entry.password) }
                            else { SecureField("パスワード", text: $entry.password) }
                        }.textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button { reveal.toggle() } label: { Image(systemName: reveal ? "eye.slash" : "eye") }
                    }
                    Button("強力なパスワードを生成", systemImage: "arrow.triangle.2.circlepath") {
                        entry.password = ONEPasswordGenerator.generate(); reveal = true
                    }
                }
            }
            .navigationTitle("ログイン情報")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("保存") { save(entry) } }
            }
        }
    }
}

private enum ONEPasswordGenerator {
    static func generate() -> String {
        let chars = Array("abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&*-_")
        var bytes = [UInt8](repeating: 0, count: 30)
        guard SecRandomCopyBytes(kSecRandomDefault, bytes.count, &bytes) == errSecSuccess else { return "" }
        return String(bytes.map { chars[Int($0) % chars.count] })
    }
}
