import SwiftUI

// SGBit ONE 26.12 — first-run setup. The setup surface is always light;
// the selected appearance is applied only after entering the home screen.
@available(iOS 17.0, *)
struct ONESetupView: View {
    @ObservedObject private var account = ONEAccount.shared
    @ObservedObject var browserPreferences: BrowserPreferences
    @AppStorage("sgbit.setup.complete") private var completed = false
    @AppStorage("sgbit.setup.terms.version") private var acceptedTermsVersion = ""
    @AppStorage("sgbit.setup.language") private var savedLanguage = "ja"
    @AppStorage("sgbit.setup.region") private var savedRegion = "JP"
    @AppStorage("sgbit.theme.automatic") private var savedAutomatic = false
    @AppStorage("sgbit.wallpaper.preset") private var savedWallpaper = "gradient"
    @AppStorage("bb.theme.accent") private var accent = "blue"
    @AppStorage("bb.theme.dark") private var dark = false
    @AppStorage("sgbit.backup.enabled") private var backup = false
    @AppStorage("sgbit.backup.frequency") private var frequency = "manual"

    @State private var step = 0 // 0: welcome, 1...7: setup, 8: ready
    @State private var greetingIndex = 0
    @State private var language = "ja"
    @State private var region = "JP"
    @State private var adGuard = false
    @State private var trackingProtection = false
    @State private var automaticAppearance = false
    @State private var selectedDark = false
    @State private var previewDark = false
    @State private var accentDraft = "blue"
    @State private var wallpaper = "gradient"
    @State private var registering = true
    @State private var name = ""
    @State private var password = ""
    @State private var confirmation = ""
    @State private var localError = ""
    @State private var backupEnabled = false
    @State private var backupFrequency = "manual"
    @State private var showBackupExport = false
    @State private var confirmDecline = false

    private let blue = Color(red: 0, green: 122 / 255, blue: 1)
    private let greetings = ["ようこそ", "Welcome", "歡迎", "Bienvenido", "어서 오세요", "Willkommen", "Välkommen", "مرحباً"]
    private let termsVersion = "26.12-1"

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                if step == 0 || step == 8 {
                    greetingScreen(height: geometry.size.height)
                } else {
                    setupScreen
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.white.ignoresSafeArea())
        }
        .preferredColorScheme(.light)
        .tint(blue)
        .task {
            language = savedLanguage
            region = savedRegion
            adGuard = browserPreferences.state.adGuardDNS
            trackingProtection = UserDefaults.standard.bool(forKey: "sgbit.network.trackingProtection")
            automaticAppearance = savedAutomatic
            selectedDark = dark
            previewDark = dark
            accentDraft = accent
            wallpaper = savedWallpaper
            backupEnabled = backup
            backupFrequency = frequency
        }
        .task(id: step == 0) {
            guard step == 0 else { return }
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(1.65))
                if Task.isCancelled { break }
                withAnimation(.easeInOut(duration: 0.38)) {
                    greetingIndex = (greetingIndex + 1) % greetings.count
                }
            }
        }
        .task(id: step == 4 && automaticAppearance) {
            guard step == 4 && automaticAppearance else { return }
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(2.2))
                if Task.isCancelled { break }
                withAnimation(.easeInOut(duration: 0.55)) { previewDark.toggle() }
            }
        }
        .confirmationDialog("利用規約に同意しませんか？", isPresented: $confirmDecline) {
            Button("同意しないでWelcomeに戻る", role: .destructive) {
                withAnimation(.easeInOut(duration: 0.35)) { step = 0 }
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("ホームには進めません。これまで選んだ設定は保持されます。")
        }
    }

    private func greetingScreen(height: CGFloat) -> some View {
        ZStack {
            Color.white
            Circle().fill(Color(red: 0.58, green: 0.76, blue: 1).opacity(0.55))
                .frame(width: 360, height: 360).blur(radius: 85)
                .offset(x: -135, y: -height * 0.2)
            Circle().fill(Color(red: 0.80, green: 0.65, blue: 0.99).opacity(0.38))
                .frame(width: 370, height: 370).blur(radius: 92)
                .offset(x: 140, y: height * 0.18)
            VStack(spacing: 12) {
                Text("SGBit ONE · 26.12")
                    .font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                    .padding(.top, 34)
                Spacer()
                if step == 0 {
                    Text(greetings[greetingIndex])
                        .id(greetingIndex)
                        .font(.system(size: 48, weight: .semibold, design: .rounded))
                        .minimumScaleFactor(0.55)
                        .lineLimit(1)
                        .transition(.opacity.combined(with: .scale(scale: 0.97)))
                        .accessibilityLabel(greetings[greetingIndex])
                } else {
                    Text("それでは始めましょう")
                        .font(.system(size: 35, weight: .semibold, design: .rounded))
                        .minimumScaleFactor(0.65)
                        .lineLimit(1)
                    Text("SGBit ONEの準備ができました。")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevrons.up")
                    .font(.system(size: 29, weight: .medium)).foregroundStyle(blue)
                    .symbolEffect(.pulse, options: .repeating)
                Text(step == 0 ? "上にスワイプして開始" : "上にスワイプしてホームへ")
                    .font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                    .padding(.bottom, 36)
            }
            .padding(.horizontal, 22)
        }
        .contentShape(Rectangle())
        .gesture(DragGesture(minimumDistance: 45).onEnded { value in
            guard value.translation.height < -75 else { return }
            withAnimation(.easeInOut(duration: 0.42)) {
                if step == 0 { step = 1 }
                else if step == 8 && acceptedTermsVersion == termsVersion { finishSetup() }
            }
        })
        .accessibilityAction(named: step == 0 ? "設定を開始" : "ホームへ移動") {
            if step == 0 { step = 1 }
            else if acceptedTermsVersion == termsVersion { finishSetup() }
        }
    }

    private var setupScreen: some View {
        VStack(spacing: 0) {
            HStack {
                if step == 7 {
                    Button("同意しない") { confirmDecline = true }
                        .foregroundStyle(blue)
                    Spacer(minLength: 8)
                    Text("利用規約").font(.headline)
                    Spacer(minLength: 8)
                    Button("同意する") {
                        acceptedTermsVersion = termsVersion
                        withAnimation(.easeInOut(duration: 0.3)) { step = 8 }
                    }
                    .fontWeight(.semibold).foregroundStyle(blue)
                } else {
                    Button { withAnimation(.easeInOut(duration: 0.25)) { step = max(0, step - 1) } } label: {
                        Label("戻る", systemImage: "chevron.left")
                    }
                    Spacer()
                    Text("\(step) / 7").font(.subheadline).foregroundStyle(.secondary)
                }
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 22).padding(.vertical, 17)

            if step != 7 {
                GeometryReader { bar in
                    Capsule().fill(Color(red: 0.9, green: 0.93, blue: 0.97))
                        .overlay(alignment: .leading) {
                            Capsule().fill(blue).frame(width: bar.size.width * CGFloat(step) / 7)
                        }
                }
                .frame(height: 4).padding(.horizontal, 22)
            }
            ScrollView {
                VStack(alignment: .leading, spacing: 19) {
                    Text(pageTitle).font(.system(size: 30, weight: .bold, design: .rounded))
                        .foregroundStyle(Color(red: 0.08, green: 0.11, blue: 0.16))
                    Text(pageDescription).foregroundStyle(.secondary)
                    pageBody
                    if !localError.isEmpty {
                        Text(localError).font(.footnote).foregroundStyle(.red)
                    }
                }
                .frame(maxWidth: 520)
                .padding(.horizontal, 23).padding(.vertical, 28)
                .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
            if step != 7 {
                Button(action: next) {
                    Text("次へ").font(.headline)
                        .frame(maxWidth: .infinity).frame(height: 55)
                        .foregroundStyle(.white)
                        .background(blue, in: Capsule())
                }
                .buttonStyle(.plain)
                .disabled(step == 5 && account.working)
                .opacity(step == 5 && account.working ? 0.5 : 1)
                .padding(.horizontal, 22).padding(.top, 14).padding(.bottom, 15)
                .background(.ultraThinMaterial)
            }
        }
        .background(Color.white)
    }

    private var pageTitle: String {
        switch step {
        case 1: return "言語を選択"
        case 2: return "国または地域を選択"
        case 3: return "ネットワーク設定"
        case 4: return "外観をカスタマイズ"
        case 5: return "アカウント設定"
        case 6: return "バックアップ設定"
        default: return "SGBit ONE ソフトウェア使用許諾契約"
        }
    }
    private var pageDescription: String {
        switch step {
        case 1: return "SGBit ONEで使用する言語を選択してください。"
        case 2: return "国や地域に合わせて表示を調整します。"
        case 3: return "ブラウザの通信に関する設定を選択します。"
        case 4: return "ライト・ダークの見本を見ながら設定できます。セットアップ中は白背景のままです。"
        case 5: return "新しいアカウントを作成するか、ログインしてください。"
        case 6: return "必要に応じてバックアップを有効にできます。"
        default: return "内容を読んで、画面上部から同意するか選択してください。"
        }
    }

    @ViewBuilder private var pageBody: some View {
        switch step {
        case 1: languageOptions
        case 2: regionOptions
        case 3: networkOptions
        case 4: appearanceOptions
        case 5: accountOptions
        case 6: backupOptions
        default: termsView
        }
    }

    private var languageOptions: some View {
        VStack(spacing: 0) {
            ForEach(Array(["ja", "en", "zh-Hant", "es", "ko", "de", "sv", "ar"].enumerated()), id: \.offset) { index, code in
                let names = ["日本語", "English", "繁體中文", "Español", "한국어", "Deutsch", "Svenska", "العربية"]
                Button { language = code } label: {
                    HStack {
                        Text(names[index]).foregroundStyle(.primary)
                        Spacer()
                        if language == code { Image(systemName: "checkmark.circle.fill").foregroundStyle(blue) }
                    }.padding(.vertical, 14).padding(.horizontal, 15)
                }.buttonStyle(.plain)
                if index != 7 { Divider().padding(.leading, 15) }
            }
        }.background(Color(white: 0.965), in: RoundedRectangle(cornerRadius: 19))
    }
    private var regionOptions: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("国または地域", selection: $region) {
                Text("日本").tag("JP")
                Text("アメリカ合衆国").tag("US")
                Text("台湾").tag("TW")
                Text("スペイン").tag("ES")
                Text("韓国").tag("KR")
                Text("ドイツ").tag("DE")
                Text("スウェーデン").tag("SE")
                Text("サウジアラビア").tag("SA")
            }.pickerStyle(.menu)
            Text("選択した地域は設定に保存されます。")
                .font(.footnote).foregroundStyle(.secondary)
        }.setupCard()
    }
    private var networkOptions: some View {
        VStack(spacing: 0) {
            Toggle(isOn: $adGuard) {
                Label {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("AdGuard DNS（DoH）")
                        Text("対応するブラウザ通信のDNSで広告ドメインを制限")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                } icon: { Image(systemName: "shield.lefthalf.filled").foregroundStyle(blue) }
            }.padding(16)
            Divider().padding(.leading, 16)
            Toggle(isOn: $trackingProtection) {
                Label {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("追跡保護の希望設定")
                        Text("将来の保護機能に向けて設定を保存")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                } icon: { Image(systemName: "hand.raised").foregroundStyle(blue) }
            }.padding(16)
        }.tint(.green).background(Color(white: 0.965), in: RoundedRectangle(cornerRadius: 19))
    }
    private var appearanceOptions: some View {
        VStack(alignment: .leading, spacing: 17) {
            HStack(spacing: 12) {
                themeSample(isDark: false, selected: !selectedDark && !automaticAppearance)
                themeSample(isDark: true, selected: selectedDark && !automaticAppearance)
            }
            VStack(spacing: 0) {
                Toggle(isOn: $automaticAppearance) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("自動").fontWeight(.medium)
                        Text("デバイスのライト・ダークに合わせる")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                .tint(.green).padding(16)
                if automaticAppearance {
                    Divider().padding(.horizontal, 16)
                    HStack {
                        Image(systemName: previewDark ? "moon.stars.fill" : "sun.max.fill")
                        Text("自動切り替えの見本を表示中")
                    }.font(.caption).foregroundStyle(.secondary)
                        .padding(16).transition(.opacity)
                }
            }.background(Color(white: 0.965), in: RoundedRectangle(cornerRadius: 19))
            Text("アクセントカラー").font(.headline)
            HStack(spacing: 13) {
                ForEach(BitTheme.names, id: \.self) { color in
                    Button { withAnimation(.easeInOut(duration: 0.2)) { accentDraft = color } } label: {
                        Circle().fill(BitTheme.color(color))
                            .frame(width: 35, height: 35)
                            .overlay {
                                if accentDraft == color {
                                    Image(systemName: "checkmark").font(.footnote.bold()).foregroundStyle(.white)
                                }
                            }
                    }.buttonStyle(.plain).accessibilityLabel(color)
                }
            }
            Text("背景").font(.headline)
            HStack(spacing: 10) {
                wallpaperSample("gradient", label: "グラデーション")
                wallpaperSample("solid", label: "単色")
                wallpaperSample("system", label: "標準")
            }
            Text("背景プリセットは初回設定として保存されます。画像の壁紙はホームの「壁紙」から変更できます。")
                .font(.footnote).foregroundStyle(.secondary)
        }
    }

    private func themeSample(isDark: Bool, selected: Bool) -> some View {
        let visibleDark = automaticAppearance ? previewDark : selectedDark
        return Button {
            withAnimation(.easeInOut(duration: 0.3)) {
                automaticAppearance = false
                selectedDark = isDark
                previewDark = isDark
            }
        } label: {
            VStack(spacing: 8) {
                VStack(spacing: 12) {
                    HStack {
                        Text("9:41").font(.system(size: 11, weight: .semibold))
                        Spacer()
                        Image(systemName: "wifi").font(.system(size: 11))
                    }
                    Spacer(minLength: 0)
                    Image(systemName: "square.grid.2x2.fill")
                        .font(.system(size: 23)).foregroundStyle(BitTheme.color(accentDraft))
                    Text("SGBit ONE").font(.system(size: 11, weight: .semibold))
                    HStack(spacing: 6) {
                        ForEach(0..<3) { _ in
                            RoundedRectangle(cornerRadius: 5)
                                .fill(BitTheme.color(accentDraft)).frame(width: 20, height: 20)
                        }
                    }
                    Spacer(minLength: 0)
                    Capsule().fill(isDark ? Color.white.opacity(0.12) : Color.black.opacity(0.09))
                        .frame(height: 6)
                }
                .foregroundStyle(isDark ? Color.white : Color.black)
                .padding(12).frame(maxWidth: .infinity).frame(height: 169)
                .background(isDark ? Color(red: 0.11, green: 0.14, blue: 0.22) : .white,
                            in: RoundedRectangle(cornerRadius: 14))
                .overlay {
                    if automaticAppearance && visibleDark == isDark {
                        RoundedRectangle(cornerRadius: 14).stroke(BitTheme.color(accentDraft).opacity(0.8), lineWidth: 2)
                    }
                }
                Text(isDark ? "ダーク" : "ライト")
                    .font(.subheadline.weight(.medium))
                Image(systemName: selected ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(selected ? BitTheme.color(accentDraft) : .gray)
            }
            .foregroundStyle(isDark ? Color.white : Color.primary)
            .padding(10).frame(maxWidth: .infinity)
            .background(isDark ? Color(red: 0.12, green: 0.14, blue: 0.20) : Color(red: 0.91, green: 0.94, blue: 0.97), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20)
                .stroke(selected ? BitTheme.color(accentDraft) : Color.clear, lineWidth: 2))
        }.buttonStyle(.plain)
    }

    private func wallpaperSample(_ id: String, label: String) -> some View {
        Button { withAnimation(.easeInOut(duration: 0.2)) { wallpaper = id } } label: {
            VStack(spacing: 7) {
                RoundedRectangle(cornerRadius: 12)
                    .fill(id == "solid" ? AnyShapeStyle(Color(red: 0.62, green: 0.79, blue: 0.98)) :
                          id == "system" ? AnyShapeStyle(Color(white: 0.91)) :
                          AnyShapeStyle(LinearGradient(colors: [.blue.opacity(0.35), .purple.opacity(0.48), .white], startPoint: .topLeading, endPoint: .bottomTrailing)))
                    .frame(height: 82)
                    .overlay {
                        if wallpaper == id { Image(systemName: "checkmark.circle.fill").foregroundStyle(blue) }
                    }
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(wallpaper == id ? blue : .clear, lineWidth: 2))
                Text(label).font(.caption2).foregroundStyle(.primary).lineLimit(1).minimumScaleFactor(0.7)
            }.frame(maxWidth: .infinity)
        }.buttonStyle(.plain)
    }

    private var accountOptions: some View {
        VStack(spacing: 15) {
            Picker("アカウント", selection: $registering) {
                Text("新規登録").tag(true)
                Text("ログイン").tag(false)
            }.pickerStyle(.segmented)
            TextField("ユーザー名（英数字・_、3〜24文字）", text: $name)
                .textContentType(.username).textInputAutocapitalization(.never)
                .autocorrectionDisabled().textFieldStyle(.roundedBorder)
            SecureField("パスワード（12文字以上）", text: $password)
                .textContentType(registering ? .newPassword : .password)
                .textFieldStyle(.roundedBorder)
            if registering {
                SecureField("パスワードを再入力", text: $confirmation)
                    .textContentType(.newPassword).textFieldStyle(.roundedBorder)
            }
            if account.signedIn {
                Label("ログイン済み：\(account.username)", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            }
            if account.working { ProgressView("サーバーに接続中…") }
            if !account.errorMessage.isEmpty {
                Text(account.errorMessage).font(.footnote).foregroundStyle(.red)
            }
            Text("新規登録するとCloudflare Workerにアカウントが作成されます。重要な情報の送信前に利用規約を確認してください。")
                .font(.footnote).foregroundStyle(.secondary)
        }.setupCard()
    }
    private var backupOptions: some View {
        VStack(alignment: .leading, spacing: 15) {
            Toggle("バックアップを有効にする", isOn: $backupEnabled).tint(.green)
            if backupEnabled {
                Picker("バックアップ頻度", selection: $backupFrequency) {
                    Text("手動").tag("manual")
                    Text("毎日（希望）").tag("daily")
                    Text("毎週（希望）").tag("weekly")
                }
                Text("実行のタイミングはアプリの動作状況に依存します。ZIPの書き出しは手動です。")
                    .font(.caption).foregroundStyle(.secondary)
                Button("今すぐZIPを書き出す") { showBackupExport = true }
                    .buttonStyle(.bordered)
            }
            Text("ZIPには個人情報や履歴が含まれる可能性があります。安全な場所に保管してください。クラウドR2の暗号化バックアップは別途動作確認が必要です。")
                .font(.footnote).foregroundStyle(.secondary)
        }
        .setupCard()
        .sheet(isPresented: $showBackupExport) { ONEBackupView() }
    }
    private var termsView: some View {
        VStack(alignment: .leading, spacing: 13) {
            Text("SGBit ONE ソフトウェア使用許諾契約").font(.headline)
            Text("本ソフトウェア（以下「本OS」）を使用する前に、以下の契約条件を注意深くお読みください。")
            Text("「同意する」を選択することで、あなたは本契約のすべての条項に拘束されることに同意したものとみなされます。")
            Text("1. 使用許諾").font(.headline)
            Text("開発者（以下「管理者」）は、あなたに対し、個人的な非商用目的に限り、本OSを対応デバイス上で使用する限定的な権利を許諾します。")
            Text("2. 禁止事項").font(.headline)
            Text("あなたは、本OSおよび関連サーバー（Cloudflareネットワーク等）を利用して以下の行為を行ってはなりません。")
            Text("・法令または公序良俗に反する行為\n・本OSの通信中継・プロキシ機能を悪用した不正アクセスや攻撃行為\n・サーバーに過度な負荷をかける行為、または容量制限を回避する行為\n・アカウントの第三者への貸与、譲渡、または不正な解析（リバースエンジニアリング）")
            Text("3. アカウントとバックアップ").font(.headline)
            Text("本OSのクラウド機能およびバックアップ機能は、利便性向上のために提供されます。\n管理者は、通信障害やシステム変更によるデータの破損・消失について一切の責任を負いません。重要なデータは必ず各自で別途保管してください。")
            Text("4. サービスの変更および停止").font(.headline)
            Text("管理者は、事前の通知なく本OSの仕様変更、メンテナンス、またはアカウントの停止・削除を行うことができます。")
            Text("5. 保証の否認（現状有姿）").font(.headline)
            Text("本OSは「現状有姿（AS IS）」で提供されます。\nパスワード管理機能を含むすべての機能について、完全性・安全性・特定目的への適合性を保証するものではありません。本OSの使用により生じたあらゆる損害について、管理者は一切の賠償責任を負いません。")
        }
        .font(.subheadline)
        .foregroundStyle(Color(red: 0.17, green: 0.20, blue: 0.25))
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(Color(white: 0.965), in: RoundedRectangle(cornerRadius: 19))
        .textSelection(.enabled)
    }

    private func next() {
        localError = ""
        switch step {
        case 1:
            savedLanguage = language
            step = 2
        case 2:
            savedRegion = region
            step = 3
        case 3:
            browserPreferences.state.adGuardDNS = adGuard
            UserDefaults.standard.set(trackingProtection, forKey: "sgbit.network.trackingProtection")
            step = 4
        case 4:
            savedAutomatic = automaticAppearance
            // Keep preview choices staged until the final swipe.
            step = 5
        case 5:
            if account.signedIn { step = 6; break }
            guard !name.isEmpty, !password.isEmpty else {
                localError = "ユーザー名とパスワードを入力してください。"
                return
            }
            if registering && password != confirmation {
                localError = "確認用パスワードが一致しません。"
                return
            }
            Task {
                let ok = registering
                    ? await account.signUp(username: name, password: password)
                    : await account.signIn(username: name, password: password)
                if ok {
                    password = ""; confirmation = ""
                    withAnimation(.easeInOut(duration: 0.25)) { step = 6 }
                }
            }
        case 6:
            backup = backupEnabled
            frequency = backupFrequency
            Task { await account.updateBackup(enabled: backupEnabled, frequency: backupFrequency) }
            step = 7
        default: break
        }
    }
    private func finishSetup() {
        guard acceptedTermsVersion == termsVersion, account.signedIn else { return }
        // The final appearance is applied when the parent replaces setup with home.
        accent = accentDraft
        savedWallpaper = wallpaper
        dark = automaticAppearance ? UITraitCollection.current.userInterfaceStyle == .dark : selectedDark
        completed = true
    }
}

@available(iOS 17.0, *)
private struct SetupCardModifier: ViewModifier {
    func body(content: Content) -> some View {
        content.padding(17)
            .background(Color(white: 0.965), in: RoundedRectangle(cornerRadius: 19))
    }
}
@available(iOS 17.0, *)
private extension View {
    func setupCard() -> some View { modifier(SetupCardModifier()) }
}
