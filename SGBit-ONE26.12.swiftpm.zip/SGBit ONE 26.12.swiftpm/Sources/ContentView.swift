import SwiftUI
import UIKit

@available(iOS 17.0, *)
@MainActor
struct RelayBrowserHome: View {
    @ObservedObject var browser: RelayBrowserModel
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        GeometryReader { geometry in
            BrowserRoot(browser: browser, security: browser.security)
                .onAppear { browser.updateViewport(width: geometry.size.width); browser.start() }
                .onChange(of: geometry.size.width) { _, width in browser.updateViewport(width: width) }
                .onChange(of: scenePhase) { _, phase in browser.sceneChanged(phase) }
        }
    }
}

@available(iOS 17.0, *)
@MainActor
private struct BrowserRoot: View {
    @ObservedObject var browser: RelayBrowserModel
    @ObservedObject var security: BrowserSecurity
    @State private var settingsPresented = false
    @ObservedObject private var networkControl = ONENetworkControl.shared
    @ObservedObject private var account = ONEAccount.shared

    var body: some View {
        Group {
            if security.locked { BrowserLockView(browser: browser, security: security) }
            else if networkControl.blocked || account.blocked { ONENetworkBlockScreen() }
            else if let tab = browser.selectedTab {
                BrowserPage(browser: browser, tab: tab, settingsPresented: $settingsPresented)
            } else {
                VStack {
                    Text(browser.relayStatus).padding()
                    Button("中継を再接続", action: browser.restartRelay)
                }
            }
        }
        .onAppear { networkControl.start() }
        .environmentObject(browser.preferences)
        .environmentObject(browser.library)
        .environmentObject(security)
        .sheet(isPresented: $settingsPresented) {
            BrowserSettings(browser: browser).environmentObject(browser.preferences).environmentObject(security)
        }
        .onChange(of: security.locked) { _, locked in
            if locked { settingsPresented = false; browser.cancelDialogs() }
            else { browser.start() }
        }
        .task(id: security.wipePending) { if security.wipePending { await browser.performSecurityWipe() } }
    }
}

@MainActor
private struct BrowserTabButton: View {
    @ObservedObject var tab: BrowserTab
    @ObservedObject var browser: RelayBrowserModel
    let selected: Bool
    let darkTheme: Bool
    let compact: Bool
    let select: () -> Void
    let close: () -> Void

    var body: some View {
        HStack(spacing: 5) {
            Button(action: select) {
                HStack(spacing: 7) {
                    Group {
                        if let icon = tab.favicon { Image(uiImage: icon).resizable().scaledToFit() }
                        else { Image(systemName: tab.isPrivate ? "eye.slash" : "globe") }
                    }
                    .frame(width: 16, height: 16)
                    if !compact { Text(tab.title).lineLimit(1).frame(maxWidth: 135, alignment: .leading) }
                }
                .padding(.leading, 12)
                .frame(minHeight: 44)
                .contentShape(Rectangle())
            }
            .accessibilityLabel(tab.title)
            .accessibilityAddTraits(selected ? .isSelected : [])
            // Drag only the tab title, never the close button.
            .modifier(BrowserTabDrag(browser: browser, id: tab.id))
            Button(action: close) {
                Image(systemName: "xmark")
                    .font(.system(size: 12, weight: .semibold))
                    .frame(width: 44, height: 44)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("\(tab.title)を閉じる")
        }
        .buttonStyle(.plain)
        .padding(.trailing, 4)
        .foregroundStyle(darkTheme ? Color.white : Color(red: 0.17, green: 0.15, blue: 0.21))
        .background {
            UnevenRoundedRectangle(topLeadingRadius: 9, bottomLeadingRadius: 2,
                                   bottomTrailingRadius: 2, topTrailingRadius: 9)
                .fill(selected ? (darkTheme ? Color(red: 0.13, green: 0.13, blue: 0.17) : .white) : .clear)
                .shadow(color: selected ? .black.opacity(darkTheme ? 0.25 : 0.09) : .clear, radius: 3, y: 1)
        }
        .overlay(alignment: .top) {
            if selected && tab.isPrivate {
                Capsule().fill(Color(red: 0.58, green: 0.35, blue: 0.98))
                    .frame(height: 2).padding(.horizontal, 10)
            }
        }
    }
}

private enum BrowserTool: String, Identifiable { case library, downloads, monitor, connection; var id: String { rawValue } }

@available(iOS 17.0, *)
@MainActor
private struct BrowserPage: View {
    @Environment(\.colorScheme) private var colorScheme
    @AppStorage("bb.theme.dark") private var darkTheme = true
    @ObservedObject var browser: RelayBrowserModel
    @ObservedObject var tab: BrowserTab
    @EnvironmentObject private var preferences: BrowserPreferences
    @EnvironmentObject private var library: BrowserLibrary
    @Binding var settingsPresented: Bool
    @StateObject private var addressInput = BrowserTextInput()
    @State private var tool: BrowserTool?
    @State private var passwordFillPresented = false
    @AppStorage("bb.browser.customKeyboard") private var customKeyboardEnabled = false
    @State private var tabOverviewShown = false
    @State private var devToolsShown = false
    @State private var keyboardVisible = false
    @State private var keyboardTarget: BrowserKeyboardTarget = .address

    private var chrome: Color { darkTheme ? Color(red: 0.06, green: 0.06, blue: 0.09) : Color(red: 0.92, green: 0.91, blue: 0.95) }
    private var chromeRaised: Color { darkTheme ? Color(red: 0.13, green: 0.13, blue: 0.17) : .white }
    private var chromeURL: Color { darkTheme ? Color(red: 0.08, green: 0.08, blue: 0.11) : Color(red: 0.95, green: 0.95, blue: 0.97) }
    private var firefoxAccent: Color { Color(red: 0.58, green: 0.35, blue: 0.98) }
    private var chromeText: Color { darkTheme ? .white : Color(red: 0.12, green: 0.12, blue: 0.17) }

    @ViewBuilder
    private func glassCapsule<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        if #available(iOS 26.0, *) {
            content().glassEffect(.regular, in: .capsule)
        } else {
            content().background(.regularMaterial, in: Capsule())
        }
    }

    private var barsHidden: Bool { !keyboardVisible && (browser.fullScreen || (tab.barsHidden && !addressInput.isEditing && !tab.findVisible)) }
    private var pageSafeAreaEdges: Edge.Set {
        if browser.fullScreen { return .all }
        return .bottom
    }

    private var connectionStatusBar: some View {
        Text("\(tab.isPrivate ? "プライベート · " : "")\(browser.proxyPort == nil ? browser.relayStatus : tab.summaryStatus) · SOCKS \(browser.tunnelCount)")
            .font(.caption2).foregroundStyle(.secondary).lineLimit(1)
            .padding(.horizontal, 6).padding(.vertical, 2)
            .contextMenu {
                Button("詳細をコピー") {
                    UIPasteboard.general.string = "\(tab.status)\n\(browser.relayStatus)\n\(browser.proxyDiagnostic)\n\(browser.inputDiagnostic)\n\(addressInput.diagnostic)\nApp: \(Bundle.main.preferredLocalizations.joined(separator: ", ")) / Device: \(Locale.preferredLanguages.joined(separator: ", "))"
                }
            }
    }

    private func bottomStatus(width: CGFloat, leftInset: CGFloat) -> some View {
        let leading: CGFloat = max(28, leftInset + 8)
        let maximum: CGFloat = max(0, width / 2 - 80 - leading)
        return connectionStatusBar
            .frame(maxWidth: maximum, alignment: .leading)
            .background(.regularMaterial, in: Rectangle())
            .padding(.leading, leading)
    }

    private var pageViewport: some View {
        Group {
            if tab.isStartPage {
                BrowserStartPage(browser: browser, library: library, focusAddress: {
                    browser.fullScreen = false
                    tab.barsHidden = false
                    keyboardVisible = false
                    tab.pageInput.cancelPending()
                    keyboardTarget = .address
                    addressInput.focusAddress()
                }, open: { url in
                    browser.fullScreen = false
                    tab.barsHidden = false
                    keyboardVisible = false
                    endEditing()
                    browser.open(url)
                })
            } else {
                RelayWebView(webView: tab.webView)
            }
        }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .accessibilityAction(named: "ツールバーを表示") { browser.fullScreen = false; tab.barsHidden = false }
            .overlay(alignment: .topTrailing) {
                if browser.fullScreen && !keyboardVisible {
                    Button { browser.fullScreen = false; tab.barsHidden = false } label: {
                        Image(systemName: "chevron.down").frame(width: 44, height: 44).background(.regularMaterial, in: Circle())
                    }.padding(8).accessibilityLabel("全画面を終了・ツールバーを表示")
                }
            }
    }

    private func endEditing() { addressInput.resign() }
    private func newTab(isPrivate: Bool) {
        endEditing()
        if browser.newTab(isPrivate: isPrivate) != nil { addressInput.focusNextField() }
    }

    private var connectionButton: some View {
        Button { endEditing(); keyboardVisible = false; tab.pageInput.cancelPending(); tool = .connection } label: {
            Image(systemName: tab.connectionState.icon)
                .frame(width: 44, height: 44)
                .contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityLabel("接続情報：\(tab.connectionState.title)")
    }

    private var displayModeMenu: some View {
        Menu {
            ForEach(BrowserDisplayMode.allCases, id: \.self) { mode in
                Button { endEditing(); tab.setDisplayMode(mode) } label: {
                    if tab.displayMode == mode { Label(mode.title, systemImage: "checkmark") }
                    else { Text(mode.title) }
                }
            }
        } label: {
            Label("表示形式：\(tab.displayMode == .automatic ? "自動・" : "")\(tab.desktop ? "PC版" : "モバイル版")", systemImage: tab.desktop ? "desktopcomputer" : "iphone")
        }
    }

    private var mobileToolbar: some View {
        VStack(spacing: 5) {
            HStack(spacing: 8) {
                BrowserURLField(text: $tab.address, input: addressInput) { browser.openAddress(in: tab) }
                    .id(tab.id)
                    .frame(height: 38)
                    .padding(.horizontal, 12)
                    .background(chromeURL, in: RoundedRectangle(cornerRadius: 9))
                    .overlay {
                        RoundedRectangle(cornerRadius: 9)
                            .strokeBorder(addressInput.isEditing ? firefoxAccent : .clear, lineWidth: 2)
                    }
                Button { endEditing(); tabOverviewShown = true } label: {
                    Text("\(browser.tabs.count)")
                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                        .frame(width: 32, height: 32)
                        .overlay { RoundedRectangle(cornerRadius: 7).strokeBorder(chromeText) }
                }.accessibilityLabel("タブ一覧")
            }
            HStack {
                Button { endEditing(); tab.webView.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!tab.canGoBack)
                Spacer()
                Button { endEditing(); tab.webView.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!tab.canGoForward)
                Spacer()
                Button { endEditing(); browser.reload(tab) } label: { Image(systemName: "arrow.clockwise") }
                Spacer()
                Button { browser.addCurrentBookmark() } label: { Image(systemName: "star") }
                Spacer()
                Menu {
                    Button("ホーム", systemImage: "house") { endEditing(); browser.home(tab) }
                    Button("ブックマーク・履歴", systemImage: "book") { tool = .library }
                    Button("ダウンロード", systemImage: "arrow.down.circle") { tool = .downloads }
                    Button("通常タブを追加", systemImage: "plus") { newTab(isPrivate: false) }
                    Button("プライベートタブを追加", systemImage: "eye.slash") { newTab(isPrivate: true) }
                    Button("SGBit DevTools", systemImage: "chevron.left.forwardslash.chevron.right") { devToolsShown = true }
                    if customKeyboardEnabled {
                        Button("独自キーボード", systemImage: "keyboard") { keyboardVisible.toggle() }
                    }
                    Button("設定", systemImage: "gearshape") { settingsPresented = true }
                } label: { Image(systemName: "line.3.horizontal") }
            }
            .frame(height: 40)
            .buttonStyle(.plain)
            .font(.system(size: 17, weight: .medium))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .foregroundStyle(chromeText)
        .background(chromeRaised)
        .environment(\.colorScheme, darkTheme ? .dark : .light)
    }

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                VStack(spacing: 0) {
                    if geometry.size.width >= 600 && !keyboardVisible {
                        HStack(spacing: 6) {
                            ScrollViewReader { reader in
                                ScrollView(.horizontal, showsIndicators: false) {
                                    HStack(spacing: 6) {
                                        ForEach(browser.tabs) { item in
                                            BrowserTabButton(tab: item, browser: browser, selected: browser.selectedID == item.id, darkTheme: darkTheme,
                                                             compact: BrowserAdaptiveLayout.compactTabs(count: browser.tabs.count, width: geometry.size.width),
                                                             select: { endEditing(); browser.select(item.id) },
                                                             close: { endEditing(); browser.close(item.id) })
                                                .id(item.id)
                                        }
                                    }
                                }
                                .onChange(of: browser.selectedID) { _, id in
                                    if let id { reader.scrollTo(id, anchor: .trailing) }
                                }
                            }
                            Button { newTab(isPrivate: tab.isPrivate) } label: { Image(systemName: "plus") }
                                .frame(minWidth: 44, minHeight: 44).accessibilityLabel("新しいタブ")
                                .contextMenu {
                                    Button("通常タブを開く", systemImage: "plus") { newTab(isPrivate: false) }
                                    Button("プライベートタブを開く", systemImage: "eye.slash") { newTab(isPrivate: true) }
                                }
                                .disabled(browser.proxyPort == nil || browser.isClearingData)
                            Button { endEditing(); tabOverviewShown = true } label: {
                                Image(systemName: "square.grid.2x2").frame(minWidth: 40, minHeight: 44)
                            }.accessibilityLabel("すべてのタブ")
                        }
                        .padding(.horizontal, 10)
                        .padding(.top, 6)
                        .padding(.bottom, 6)
                        .background(chrome)
                        .environment(\.colorScheme, darkTheme ? .dark : .light)
                    }

                    if geometry.size.width >= 600 {
                    HStack(spacing: 8) {
                        Button { endEditing(); tab.webView.goBack() } label: { Image(systemName: "chevron.left") }
                            .frame(width: 44, height: 44).contentShape(Rectangle())
                            .accessibilityLabel("戻る").disabled(!tab.canGoBack || browser.proxyPort == nil)
                        if geometry.size.width >= 600 {
                        Button { endEditing(); tab.webView.goForward() } label: { Image(systemName: "chevron.right") }
                            .frame(width: 44, height: 44).contentShape(Rectangle())
                            .accessibilityLabel("進む").disabled(!tab.canGoForward || browser.proxyPort == nil)
                        }
                        Button { endEditing(); browser.reload(tab) } label: { Image(systemName: "arrow.clockwise") }
                            .frame(width: 44, height: 44).contentShape(Rectangle())
                            .accessibilityLabel("再読み込み・中継再接続")
                        if geometry.size.width >= 600 {
                        Button { endEditing(); browser.home(tab) } label: { Image(systemName: "house") }
                            .frame(width: 44, height: 44).contentShape(Rectangle())
                            .accessibilityLabel("ホーム").disabled(browser.proxyPort == nil)
                        }
                        connectionButton
                        BrowserURLField(text: $tab.address, input: addressInput) { browser.openAddress(in: tab) }
                            .id(tab.id).frame(height: 36).accessibilityLabel("URLまたは検索語")
                            .padding(.horizontal, 12)
                            .background(chromeURL, in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                            .overlay { RoundedRectangle(cornerRadius: 8).strokeBorder(addressInput.isEditing ? firefoxAccent : chromeText.opacity(0.10), lineWidth: addressInput.isEditing ? 2 : 1) }

                        if customKeyboardEnabled {
                            Button { keyboardVisible.toggle() } label: { Image(systemName: "keyboard").frame(minWidth: 44, minHeight: 44) }
                                .accessibilityLabel("アプリ内キーボードを開閉")
                        }
                        BrowserDownloadToolbarButton(downloads: browser.downloads) { endEditing(); tool = .downloads }
                        Menu {
                            if geometry.size.width < 600 {
                                Button("進む", systemImage: "chevron.right") { endEditing(); tab.webView.goForward() }
                                    .disabled(!tab.canGoForward || browser.proxyPort == nil)
                                Button("ホーム", systemImage: "house") { endEditing(); browser.home(tab) }.disabled(browser.proxyPort == nil)
                                Divider()
                            }
                            Button("ブックマークに追加", systemImage: "star") { browser.addCurrentBookmark() }
                            Button("ブックマーク・履歴", systemImage: "book") { endEditing(); tool = .library }
                            Button("ダウンロード", systemImage: "arrow.down.circle") { endEditing(); tool = .downloads }
                            Button("保存済みパスワードを入力", systemImage: "key.fill") {
                                endEditing(); passwordFillPresented = true
                            }
                            .disabled(tab.webView.url?.scheme != "https")
                            Button("ページ内検索", systemImage: "doc.text.magnifyingglass") { endEditing(); tab.findVisible = true }
                            Button("通信モニター", systemImage: "network") { endEditing(); tool = .monitor }
                            Button("SGBit DevTools", systemImage: "chevron.left.forwardslash.chevron.right") {
                                endEditing(); devToolsShown = true
                            }
                            Button("すべてのタブ", systemImage: "square.grid.2x2") {
                                endEditing(); tabOverviewShown = true
                            }
                            Divider()
                            displayModeMenu
                            Button("全画面モード", systemImage: "arrow.up.left.and.arrow.down.right") { endEditing(); browser.fullScreen = true }
                            Button("通常タブを開く", systemImage: "plus") { newTab(isPrivate: false) }
                            Button("プライベートタブを開く", systemImage: "eye.slash") { newTab(isPrivate: true) }
                            Divider()
                            Button("設定", systemImage: "gearshape") { endEditing(); settingsPresented = true }
                        } label: {
                            Image(systemName: "ellipsis.circle")
                                .frame(width: 44, height: 44)
                                .contentShape(Rectangle())
                        }
                        .menuOrder(.fixed)
                        .accessibilityLabel("ブラウザメニュー")
                    }
                    .buttonStyle(.plain)
                    .font(.system(size: 15, weight: .medium))
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    .foregroundStyle(chromeText)
                    .background(chrome)
                    .environment(\.colorScheme, darkTheme ? .dark : .light)
                    }
                    if preferences.state.showBookmarksBar && !keyboardVisible {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                Button { tool = .library } label: { Image(systemName: "book") }.accessibilityLabel("ブックマーク一覧")
                                ForEach(library.bookmarks) { entry in
                                    Button { endEditing(); browser.open(entry.url) } label: { Text(entry.title).lineLimit(1).frame(maxWidth: 180) }
                                }
                            }.padding(.horizontal, 12).padding(.vertical, 6)
                        }.font(.callout)
                         .foregroundStyle(chromeText)
                         .background(chrome)
                    }
                    if tab.findVisible && !keyboardVisible {
                        HStack {
                            TextField("ページ内を検索", text: $tab.findQuery).textFieldStyle(.roundedBorder)
                                .submitLabel(.search).onSubmit { tab.find() }
                            Text(tab.findMessage).font(.caption)
                            Button { tab.find(backwards: true) } label: { Image(systemName: "chevron.up") }.accessibilityLabel("前を検索")
                            Button { tab.find() } label: { Image(systemName: "chevron.down") }.accessibilityLabel("次を検索")
                            Button { tab.findVisible = false; tab.findQuery = ""; tab.find() } label: { Image(systemName: "xmark") }.accessibilityLabel("検索を閉じる")
                        }.padding(.horizontal, 10).padding(.bottom, 6)
                    }
                    ProgressView().progressViewStyle(.linear).opacity(tab.isLoading ? 1 : 0)
                }
                .frame(height: barsHidden ? 0 : nil).opacity(barsHidden ? 0 : 1)
                .clipped().allowsHitTesting(!barsHidden).accessibilityHidden(barsHidden)
                .background(chrome)

                pageViewport

                if geometry.size.width < 600 && !barsHidden {
                    mobileToolbar
                }

                if keyboardVisible && customKeyboardEnabled {
                    BrowserKeyboardHost(tab: tab, addressInput: addressInput, target: keyboardTarget) {
                        tab.pageInput.cancelPending(); keyboardVisible = false
                    }
                        .id(tab.id)
                        .frame(height: BrowserKeyboardLayout.height(available: max(0, geometry.size.height - geometry.safeAreaInsets.bottom), width: geometry.size.width, size: preferences.state.keyboardSize))
                        .padding(.bottom, geometry.safeAreaInsets.bottom)
                        .layoutPriority(1)
                }
            }
            .background(chrome)
            .overlay(alignment: .bottomLeading) {
                if preferences.state.debugStatusBar && !keyboardVisible && !barsHidden {
                    bottomStatus(width: geometry.size.width, leftInset: geometry.safeAreaInsets.leading)
                }
            }
            .background(alignment: .top) {
                if barsHidden && !browser.fullScreen {
                    (colorScheme == .dark ? Color.black : Color.white)
                        .ignoresSafeArea(.container, edges: .top).allowsHitTesting(false)
                }
            }
        }
        .onReceive(tab.pageInput.$focusSerial.dropFirst()) { _ in
            if tab.pageInput.pointerSelected || !addressInput.isEditing {
                keyboardTarget = tab.pageInput.hasTarget ? .page : .none
            }
        }
        .onChange(of: addressInput.isEditing) { _, editing in
            if editing { tab.pageInput.cancelPending(); keyboardTarget = .address }
        }
        .onChange(of: customKeyboardEnabled) { _, enabled in
            if !enabled { keyboardVisible = false }
        }
        .onChange(of: tab.id) { _, _ in keyboardTarget = .address }
        .animation(.easeInOut(duration: 0.18), value: barsHidden)
        .statusBarHidden(browser.fullScreen)
        .ignoresSafeArea(.container, edges: pageSafeAreaEdges)
        .overlay {
            BrowserDialogOverlay(dialogs: tab.dialogs) {
                endEditing(); keyboardVisible = false; tool = nil; settingsPresented = false
                tab.pageInput.cancelPending()
            }.id(tab.id)
        }
        .sheet(isPresented: $tabOverviewShown) {
            BrowserTabOverview(browser: browser)
        }
        .sheet(isPresented: $devToolsShown) {
            BrowserSimpleDevTools(tab: tab)
        }
        .sheet(isPresented: $passwordFillPresented) {
            ONEPasswordFillSheet(webView: tab.webView)
        }
        .sheet(item: $tool) { tool in
            switch tool {
            case .library: BrowserLibraryView(browser: browser, library: library)
            case .downloads: BrowserDownloadsView(downloads: browser.downloads)
            case .monitor: BrowserMonitorView(browser: browser, monitor: browser.monitor)
            case .connection: BrowserConnectionView(tab: tab)
            }
        }
        .background {
            BrowserShortcuts(browser: browser, dialogs: tab.dialogs, blocked: settingsPresented || tool != nil,
                             newTab: { newTab(isPrivate: $0) }, focusAddress: {
                browser.fullScreen = false; tab.barsHidden = false
                tab.pageInput.cancelPending(); keyboardTarget = .address; addressInput.focusAddress()
            })
        }
    }
}

@MainActor
private struct BrowserKeyboardHost: View {
    @EnvironmentObject private var preferences: BrowserPreferences
    @ObservedObject var tab: BrowserTab
    @ObservedObject var addressInput: BrowserTextInput
    @ObservedObject private var pageInput: BrowserPageInput
    let target: BrowserKeyboardTarget
    let close: () -> Void
    @State private var addressStatus = "URL欄へ入力（全選択で現在のURLを置換）"

    init(tab: BrowserTab, addressInput: BrowserTextInput, target: BrowserKeyboardTarget, close: @escaping () -> Void) {
        self.tab = tab; self.addressInput = addressInput
        _pageInput = ObservedObject(wrappedValue: tab.pageInput)
        self.target = target; self.close = close
    }

    var body: some View {
        BrowserKeyboardPanel(target: target, contextID: pageInput.focusSerial,
                                 status: target == .address ? addressStatus : pageInput.status,
                                 secure: target == .page && pageInput.secure,
                                 send: { operation, text, completion in
                if target == .address {
                    let success = addressInput.apply(operation, text: text)
                    addressStatus = success ? "URL欄へ入力しました" : "URL欄へ入力できません。変換中なら確定してから試してください"
                    completion(success)
                }
                else if target == .page { pageInput.send(operation, text: text, completion: completion) }
                else { completion(false) }
            }, close: close, keyboardSize: preferences.state.keyboardSize)
    }
}

