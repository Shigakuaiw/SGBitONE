import SwiftUI
import Foundation
import QuickLook

private struct ONECloudFolder: Decodable, Identifiable {
    let key: String
    let name: String
    var id: String { key }
}
private struct ONECloudFile: Decodable, Identifiable {
    let key: String
    let name: String
    let size: Int64
    let uploaded: String?
    var id: String { key }
}
private struct ONECloudPage: Decodable {
    let prefix: String
    let folders: [ONECloudFolder]
    let files: [ONECloudFile]
    let cursor: String?
}

@MainActor
private final class ONECloudFileModel: ObservableObject {
    @Published var prefix = ""
    @Published var folders: [ONECloudFolder] = []
    @Published var files: [ONECloudFile] = []
    @Published var cursor: String?
    @Published var loading = false
    @Published var message: String?
    @Published var previewURL: URL?
    @Published var search = ""
    private let account = ONEAccount.shared

    var shownFolders: [ONECloudFolder] {
        folders.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) }
    }
    var shownFiles: [ONECloudFile] {
        files.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) }
    }

    func refresh(_ folder: String? = nil, append: Bool = false) async {
        if loading { return }
        loading = true; message = nil
        defer { loading = false }
        let target = folder ?? prefix
        do {
            var query = [URLQueryItem(name: "prefix", value: target)]
            if append, let cursor { query.append(URLQueryItem(name: "cursor", value: cursor)) }
            let (data, _) = try await account.fileAPI("api/files", query: query)
            let page = try JSONDecoder().decode(ONECloudPage.self, from: data)
            prefix = target
            if append {
                folders += page.folders.filter { f in !folders.contains(where: { $0.key == f.key }) }
                files += page.files.filter { f in !files.contains(where: { $0.key == f.key }) }
            } else {
                folders = page.folders
                files = page.files
            }
            cursor = page.cursor
        } catch {
            message = "読み込み失敗: \(error.localizedDescription)"
        }
    }

    func up() async {
        let parts = prefix.split(separator: "/").dropLast()
        await refresh(parts.isEmpty ? "" : parts.joined(separator: "/") + "/")
    }

    func download(_ file: ONECloudFile) async {
        if loading { return }
        loading = true; message = nil
        defer { loading = false }
        do {
            // URLSession.data keeps data in memory, so bound the acceptable file size.
            guard file.size <= 50 * 1024 * 1024 else {
                message = "50MB超のファイルは未対応です。管理画面から保存してください。"
                return
            }
            let (data, _) = try await account.fileAPI("api/files/download", query: [URLQueryItem(name: "key", value: file.key)])
            guard data.count <= 50 * 1024 * 1024 else { throw CocoaError(.fileReadTooLarge) }
            let parent = Library.shared.folder.appendingPathComponent("Downloads", isDirectory: true)
            try FileManager.default.createDirectory(at: parent, withIntermediateDirectories: true)
            // Strip path components so a malicious object name cannot leave Downloads.
            let suggested = (file.key as NSString).lastPathComponent
            let safe = suggested.replacingOccurrences(of: ":", with: "_")
                .replacingOccurrences(of: "\\", with: "_")
            guard !safe.isEmpty && safe != "." && safe != ".." else { throw CocoaError(.fileWriteInvalidFileName) }
            var destination = parent.appendingPathComponent(safe, isDirectory: false)
            if FileManager.default.fileExists(atPath: destination.path) {
                destination = parent.appendingPathComponent(UUID().uuidString.prefix(8) + "-" + safe)
            }
            try data.write(to: destination, options: [.atomic])
            Library.shared.refresh()
            previewURL = destination
            message = "Downloadsに保存しました: \(safe)"
        } catch {
            message = "保存失敗: \(error.localizedDescription)"
        }
    }
}

@available(iOS 17.0, *)
struct ONECloudFilesView: View {
    @StateObject private var cloud = ONECloudFileModel()
    @ObservedObject private var account = ONEAccount.shared

    var body: some View {
        List {
            if !account.signedIn {
                ContentUnavailableView("ログインが必要です", systemImage: "person.crop.circle.badge.questionmark",
                                       description: Text("設定 → アカウントからログインしてください"))
            } else {
                Section {
                    HStack {
                        Text(cloud.prefix.isEmpty ? "/" : "/" + cloud.prefix)
                            .font(.footnote.monospaced()).lineLimit(2)
                        Spacer()
                        if cloud.loading { ProgressView() }
                    }
                    HStack {
                        Button("最上位") { Task { await cloud.refresh("") } }
                        Button("戻る") { Task { await cloud.up() } }.disabled(cloud.prefix.isEmpty)
                        Button("更新") { Task { await cloud.refresh() } }
                    }
                    .buttonStyle(.bordered)
                    TextField("このフォルダ内を検索", text: $cloud.search)
                        .textInputAutocapitalization(.never)
                }
                if let message = cloud.message {
                    Section { Text(message).font(.footnote).foregroundStyle(.secondary) }
                }
                Section("フォルダ") {
                    ForEach(cloud.shownFolders) { folder in
                        Button {
                            Task { await cloud.refresh(folder.key) }
                        } label: { Label(folder.name, systemImage: "folder.fill") }
                    }
                }
                Section("ファイル") {
                    ForEach(cloud.shownFiles) { file in
                        Button {
                            Task { await cloud.download(file) }
                        } label: {
                            HStack {
                                Label(file.name, systemImage: "doc.fill")
                                Spacer()
                                Text(ByteCountFormatter.string(fromByteCount: file.size, countStyle: .file))
                                    .font(.caption).foregroundStyle(.secondary)
                                Image(systemName: "arrow.down.circle")
                            }
                        }
                    }
                    if let _ = cloud.cursor {
                        Button("次の100件を読み込む") { Task { await cloud.refresh(append: true) } }
                            .disabled(cloud.loading)
                    }
                    if cloud.folders.isEmpty && cloud.files.isEmpty && !cloud.loading {
                        Text("R2にファイルがありません").foregroundStyle(.secondary)
                    }
                }
            }
        }
        .task(id: account.signedIn) {
            if account.signedIn { await cloud.refresh("") }
        }
        .quickLookPreview($cloud.previewURL)
    }
}
