import SwiftUI
import Foundation

// 7 taps only reveal this screen. Every privileged operation is authenticated by Cloudflare.
// ADMIN_TOKEN is user-defined in Worker Secrets and never stored in the app.
@available(iOS 17.0, *)
@MainActor
struct ONEAdminOptionsScreen: View {
    @AppStorage("sgbit.one.update.manifestURL") private var manifestURL = ""
    @Environment(\.dismiss) private var dismiss
    @State private var token = ""
    @State private var authenticated = false
    @State private var busy = false
    @State private var errorMessage = ""
    @State private var currentDetails = ""
    @State private var version = "26.7.2"
    @State private var title = "設定アップデート"
    @State private var notes = ""
    @State private var downloadURL = ""
    @State private var patchEnabled = false
    @State private var darkTheme = false
    @State private var confirmPublish = false
    @FocusState private var tokenFocused: Bool

    private func serverURL(_ path: String) -> URL? {
        let raw = manifestURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: raw),
              url.scheme == "https", url.host != nil,
              url.user == nil, url.password == nil,
              var parts = URLComponents(url: url, resolvingAgainstBaseURL: false) else { return nil }
        parts.path = path
        parts.query = nil
        parts.fragment = nil
        return parts.url
    }

    private func adminRequest(path: String, method: String = "GET", body: Data? = nil) async throws -> Data {
        guard let url = serverURL(path) else { throw AdminError.invalidURL }
        let secret = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !secret.isEmpty else { throw AdminError.noToken }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(secret)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 15
        if let body {
            request.httpBody = body
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw AdminError.unexpected }
        if http.statusCode == 401 || http.statusCode == 403 { throw AdminError.unauthorized }
        guard http.statusCode == 200 else { throw AdminError.server(http.statusCode) }
        guard data.count < 65536 else { throw AdminError.unexpected }
        return data
    }

    private func verify() async {
        busy = true
        defer { busy = false }
        errorMessage = ""
        do {
            let data = try await adminRequest(path: "/admin/current")
            guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  obj["schema"] as? Int == 1 else { throw AdminError.unexpected }
            currentDetails = String(data: data, encoding: .utf8) ?? ""
            authenticated = true
            tokenFocused = false
        } catch {
            authenticated = false
            errorMessage = error.localizedDescription
        }
    }

    private func publish() async {
        busy = true
        defer { busy = false }
        errorMessage = ""
        let v = version.trimmingCharacters(in: .whitespacesAndNewlines)
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let u = downloadURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard v.range(of: #"^\d+\.\d+(\.\d+)?$"#, options: .regularExpression) != nil,
              !t.isEmpty, t.count <= 100, notes.count <= 4000 else {
            errorMessage = "バージョン形式、タイトル、更新内容を確認してください。"
            return
        }
        if !u.isEmpty {
            guard let link = URL(string: u), link.scheme == "https", link.host != nil else {
                errorMessage = "配布URLには有効なHTTPS URLを指定してください。"
                return
            }
        }
        var obj: [String: Any] = ["schema": 1, "version": v, "title": t, "notes": notes]
        if !u.isEmpty { obj["downloadURL"] = u }
        if patchEnabled { obj["patch"] = ["darkTheme": darkTheme] }
        do {
            let data = try JSONSerialization.data(withJSONObject: obj)
            _ = try await adminRequest(path: "/admin/publish", method: "POST", body: data)
            currentDetails = String(data: data, encoding: .utf8) ?? ""
            errorMessage = "配信しました。利用者側の更新画面から確認できます。"
        } catch {
            errorMessage = error.localizedDescription
            if case AdminError.unauthorized = error { authenticated = false }
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                ONEControlSettings()
                Section("管理サーバー") {
                    TextField("https://example.workers.dev/updates", text: $manifestURL)
                        .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    Text("Cloudflare Workerの /updates URL を指定。管理者コードはWorker Secretの ADMIN_TOKEN と同じ文字列です。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                if !authenticated {
                    Section("管理者認証") {
                        SecureField("管理者コード", text: $token)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                            .focused($tokenFocused)
                            .onSubmit { Task { await verify() } }
                        Button { Task { await verify() } } label: {
                            Label("認証して管理者オプションを開く", systemImage: "lock.open")
                        }.disabled(busy || token.isEmpty)
                        Text("7回タップは入口を表示するだけ。管理権限はサーバーで照合します。コードは端末に保存しません。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                } else {
                    Section("管理者オプション") {
                        Label("管理者認証済み", systemImage: "checkmark.shield.fill").foregroundStyle(.green)
                        Button("現在の配信内容を取得") { Task { await verify() } }.disabled(busy)
                        Button("管理者モードを終了", role: .destructive) {
                            authenticated = false
                            token = ""
                            currentDetails = ""
                        }
                    }
                    Section("アップデートを作成") {
                        TextField("バージョン（例: 26.7.2）", text: $version)
                        TextField("タイトル", text: $title)
                        TextField("更新内容", text: $notes, axis: .vertical).lineLimit(3...7)
                        TextField("配布ページURL（任意）", text: $downloadURL)
                            .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                        Toggle("テーマ設定パッチを含める", isOn: $patchEnabled)
                        if patchEnabled { Toggle("ダークモードにする", isOn: $darkTheme) }
                        Button { confirmPublish = true } label: {
                            Label("更新を配信", systemImage: "paperplane.fill")
                        }.disabled(busy)
                    }
                    if !currentDetails.isEmpty {
                        Section("現在の配信 JSON") {
                            Text(currentDetails).font(.system(.caption, design: .monospaced))
                                .textSelection(.enabled)
                        }
                    }
                }
                if !errorMessage.isEmpty {
                    Section("状態") { Text(errorMessage).foregroundStyle(.secondary) }
                }
            }
            .navigationTitle("管理者オプション")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("閉じる") { dismiss() } } }
            .confirmationDialog("この更新を全利用者向けに配信しますか？", isPresented: $confirmPublish) {
                Button("配信する") { Task { await publish() } }
                Button("キャンセル", role: .cancel) { }
            } message: { Text("配信した設定パッチは利用者の確認後に適用されます。") }
            .onDisappear { token = ""; authenticated = false }
        }
    }
}

private enum AdminError: LocalizedError {
    case invalidURL, noToken, unauthorized, unexpected, server(Int)
    var errorDescription: String? {
        switch self {
        case .invalidURL: return "更新サーバーのHTTPS URLを設定してください。"
        case .noToken: return "管理者コードを入力してください。"
        case .unauthorized: return "管理者コードが違います。Cloudflareの ADMIN_TOKEN を確認してください。"
        case .unexpected: return "サーバーの応答を確認できませんでした。"
        case .server(let status): return "サーバーエラー: HTTP \(status)"
        }
    }
}
