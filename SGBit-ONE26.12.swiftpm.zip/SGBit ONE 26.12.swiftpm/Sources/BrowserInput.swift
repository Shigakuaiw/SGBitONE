import SwiftUI
import UIKit
import WebKit
import Combine

@MainActor
final class BrowserTextInput: ObservableObject {
    @Published private(set) var isEditing = false
    private(set) weak var field: UITextField?
    private var focusRequested = false
    private var focusGeneration = 0
    private(set) var starts = 0
    private(set) var ends = 0

    func attach(_ field: UITextField) {
        guard self.field !== field else { return }
        self.field = field
        if focusRequested {
            focusRequested = false
            scheduleFocus(field)
        }
    }

    func detach(_ field: UITextField) {
        guard self.field === field else { return }
        self.field = nil
        DispatchQueue.main.async { [weak self] in
            guard let self, self.field == nil else { return }
            self.isEditing = false
        }
    }

    func focusNextField() {
        focusGeneration += 1
        focusRequested = true
    }

    func focusAddress() {
        focusGeneration += 1
        focusRequested = false
        if let field { scheduleFocus(field, selectAll: true) }
    }

    private func scheduleFocus(_ field: UITextField, selectAll: Bool = false) {
        let generation = focusGeneration
        DispatchQueue.main.async { [weak self, weak field] in
            guard let self, let field, self.field === field,
                  self.focusGeneration == generation else { return }
            guard field.window != nil else { return }
            _ = field.becomeFirstResponder()
            if selectAll { field.selectAll(nil) }
        }
    }

    func resign() {
        focusGeneration += 1
        focusRequested = false
        field?.resignFirstResponder()
    }

    func apply(_ operation: String, text: String = "") -> Bool {
        guard let field, field.isEnabled, field.markedTextRange == nil, text.utf16.count <= 8192 else { return false }
        if operation == "enter" { field.sendActions(for: .editingDidEndOnExit); return true }
        let value = (field.text ?? "") as NSString
        let selection = field.selectedTextRange
        var start = selection.map { field.offset(from: field.beginningOfDocument, to: $0.start) } ?? value.length
        var end = selection.map { field.offset(from: field.beginningOfDocument, to: $0.end) } ?? start
        start = min(max(0, start), value.length); end = min(max(start, end), value.length)
        switch operation {
        case "selectAll": start = 0; end = value.length
        case "left":
            if start == end && start > 0 { start = value.rangeOfComposedCharacterSequence(at: start - 1).location }
            end = start
        case "right":
            if start == end && end < value.length { end = NSMaxRange(value.rangeOfComposedCharacterSequence(at: end)) }
            start = end
        case "insert", "delete":
            if operation == "delete" && start == end && start > 0 { start = value.rangeOfComposedCharacterSequence(at: start - 1).location }
            let addition = operation == "insert" ? text : ""
            field.text = value.replacingCharacters(in: NSRange(location: start, length: end - start), with: addition)
            start += addition.utf16.count; end = start
        default: return false
        }
        if let first = field.position(from: field.beginningOfDocument, offset: start),
           let last = field.position(from: field.beginningOfDocument, offset: end) {
            field.selectedTextRange = field.textRange(from: first, to: last)
        }
        if operation == "insert" || operation == "delete" { field.sendActions(for: .editingChanged) }
        return true
    }

    var diagnostic: String {
        guard let field else { return "URL input: detached" }
        let window = field.window
        return "URL input: first=\(field.isFirstResponder), editing=\(isEditing), enabled=\(field.isEnabled), key=\(window?.isKeyWindow.description ?? "none"), canKey=\(window?.canBecomeKey.description ?? "none"), begin/end=\(starts)/\(ends)"
    }

    func began(_ field: UITextField) {
        guard self.field === field else { return }
        focusGeneration += 1
        focusRequested = false; starts += 1; isEditing = true
    }
    func ended(_ field: UITextField) {
        guard self.field === field else { return }
        focusGeneration += 1
        ends += 1; isEditing = false
    }
}

@MainActor
struct BrowserURLField: UIViewRepresentable {
    @Binding var text: String
    @ObservedObject var input: BrowserTextInput
    var placeholder = "URLまたは検索語"
    var secure = false
    var onSubmit: () -> Void

    func makeUIView(context: Context) -> UITextField {
        let field = UITextField()
        field.delegate = context.coordinator
        field.borderStyle = .roundedRect
        field.placeholder = placeholder
        field.isSecureTextEntry = secure
        field.textContentType = secure ? .password : nil
        field.keyboardType = secure ? .default : .webSearch
        field.returnKeyType = .go
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.clearButtonMode = .whileEditing
        field.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        field.addTarget(context.coordinator, action: #selector(Coordinator.changed(_:)), for: .editingChanged)
        field.addTarget(context.coordinator, action: #selector(Coordinator.submitted(_:)), for: .editingDidEndOnExit)
        input.attach(field)
        return field
    }

    func updateUIView(_ field: UITextField, context: Context) { context.coordinator.update(field, parent: self) }
    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }
    static func dismantleUIView(_ field: UITextField, coordinator: Coordinator) {
        coordinator.parent.input.detach(field)
        field.removeTarget(coordinator, action: #selector(Coordinator.changed(_:)), for: .editingChanged)
        field.removeTarget(coordinator, action: #selector(Coordinator.submitted(_:)), for: .editingDidEndOnExit)
        field.delegate = nil
    }

    @MainActor
    final class Coordinator: NSObject, UITextFieldDelegate {
        var parent: BrowserURLField
        init(parent: BrowserURLField) { self.parent = parent; super.init() }
        func update(_ field: UITextField, parent: BrowserURLField) {
            self.parent = parent
            // UIKit owns editing; rendering never derives a resign command from a stale Bool.
            if !field.isFirstResponder && field.markedTextRange == nil && field.text != parent.text { field.text = parent.text }
        }
        @objc func changed(_ field: UITextField) {
            guard parent.input.field === field else { return }
            parent.text = field.text ?? ""
        }
        func textFieldDidBeginEditing(_ textField: UITextField) { parent.input.began(textField) }
        func textFieldDidEndEditing(_ textField: UITextField) { parent.input.ended(textField) }
        @objc func submitted(_ field: UITextField) { _ = textFieldShouldReturn(field) }
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            guard parent.input.field === textField, textField.markedTextRange == nil else { return false }
            parent.text = textField.text ?? ""
            parent.input.resign()
            parent.onSubmit()
            return false
        }
    }
}

@available(iOS 17.0, *)
@MainActor
struct BrowserInputDiagnostics: View {
    @StateObject private var nativeInput = BrowserTextInput()
    @StateObject private var probe = BrowserInputProbe()
    @State private var nativeText = ""
    @State private var swiftUIText = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("通信を使わない入力比較").font(.headline)
                Text("①〜③をそれぞれタップして入力してください。外付けキーボードを接続した場合と外した場合を比較します。入力内容・URL・Cookie・PINは診断へ記録しません。")
                    .font(.callout)
                Text("① SwiftUI標準TextField")
                TextField("テスト用の文字列", text: $swiftUIText).textFieldStyle(.roundedBorder)
                Text("② UIKit標準UITextField（URL欄と同じ実装）")
                BrowserURLField(text: $nativeText, input: nativeInput) {}.frame(height: 40)
                Text("③ ローカルHTMLのinput / textarea")
                InputProbeWebSurface(webView: probe.webView).frame(height: 240)
                HStack {
                    Button("状態を更新") { probe.capture(input: nativeInput) }
                    Button("診断をコピー") {
                        probe.capture(input: nativeInput)
                        UIPasteboard.general.string = probe.report
                    }
                }.buttonStyle(.bordered)
                Button("ページのフォーカスを確認") { probe.captureDOM(input: nativeInput) }.buttonStyle(.bordered)
                Text(probe.report).font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                Text("①〜③全部で失敗する場合はブラウザ共通処理以外も疑います。③だけ失敗ならWebKit側、通常のページだけ失敗ならそのページ固有の処理を分けて調べます。この画面は新しいウィンドウの作成やキーウィンドウの変更を行いません。")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding()
        }.navigationTitle("入力の診断").onAppear { probe.start(input: nativeInput) }
    }
}

@MainActor
final class BrowserInputProbe: NSObject, ObservableObject, WKNavigationDelegate {
    let webView: WKWebView
    @Published private(set) var report = "未取得"
    private var observations: [AnyCancellable] = []
    private var shows = 0
    private var hides = 0
    private var keyChanges = 0
    private var dom = "未取得"
    private weak var trackedInput: BrowserTextInput?
    private var history: [String] = []

    override init() {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        webView = WKWebView(frame: .zero, configuration: config)
        super.init()
        webView.navigationDelegate = self
        let content = webView.configuration.userContentController
        content.add(InputProbeMessageReceiver(owner: self), contentWorld: .defaultClient, name: "inputProbe")
        content.addUserScript(WKUserScript(source: """
        for (const event of ['focusin', 'focusout']) {
            document.addEventListener(event, () => {
                window.webkit.messageHandlers.inputProbe.postMessage({event, tag: document.activeElement?.tagName || '', focused: document.hasFocus()});
            }, true);
        }
        """, injectionTime: .atDocumentEnd, forMainFrameOnly: true, in: .defaultClient))
        for name in [UIResponder.keyboardDidShowNotification, UIResponder.keyboardDidHideNotification,
                     UIWindow.didBecomeKeyNotification, UIWindow.didResignKeyNotification,
                     UITextField.textDidBeginEditingNotification, UITextField.textDidEndEditingNotification] {
            observations.append(NotificationCenter.default.publisher(for: name).sink { [weak self] note in
                let name = note.name
                let source = note.object as? UIView
                Task { @MainActor [weak self] in
                    guard let self, let input = self.trackedInput,
                          let window = self.webView.window ?? input.field?.window else { return }
                    if let source, source !== window, source.window !== window { return }
                    if name == UIResponder.keyboardDidShowNotification { self.shows += 1 }
                    else if name == UIResponder.keyboardDidHideNotification { self.hides += 1 }
                    else if name == UIWindow.didBecomeKeyNotification || name == UIWindow.didResignKeyNotification { self.keyChanges += 1 }
                    self.capture(input: input, event: name.rawValue)
                }
            })
        }
        webView.loadHTMLString("""
        <!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'">
        <style>:root{color-scheme:light dark;font:16px system-ui}input,textarea{box-sizing:border-box;width:100%;font:inherit;padding:12px;margin:8px 0}</style>
        </head><body><input placeholder="HTML input"><textarea rows="3" placeholder="HTML textarea"></textarea></body></html>
        """, baseURL: nil)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(Self.allowsNavigation(navigationAction.request.url) ? .allow : .cancel)
    }

    static func allowsNavigation(_ url: URL?) -> Bool { url?.absoluteString == "about:blank" }

    func start(input: BrowserTextInput) {
        trackedInput = input
        capture(input: input, event: "open")
    }

    func pageFocus(_ body: Any) {
        guard let input = trackedInput, let data = body as? [String: Any],
              let event = data["event"] as? String, ["focusin", "focusout"].contains(event),
              let tag = data["tag"] as? String, tag.utf8.count <= 32,
              let focused = data["focused"] as? Bool else { return }
        dom = "tag=\(tag), documentFocus=\(focused)"
        capture(input: input, event: "HTML \(event)")
    }

    func capture(input: BrowserTextInput, event: String = "manual") {
        let window = input.field?.window ?? webView.window
        let responder = window.flatMap { Self.firstResponder(in: $0) }
        let scene = window?.windowScene
        let snapshot = [
            "RelayBrowser input r4 · \(event)",
            "OS: \(ProcessInfo.processInfo.operatingSystemVersionString)",
            "Bundle: \(Bundle.main.bundleIdentifier ?? "unknown")",
            "window: \(window.map { NSStringFromClass(type(of: $0)) } ?? "none")",
            "key: \(window?.isKeyWindow.description ?? "none"), canKey: \(window?.canBecomeKey.description ?? "none")",
            "scene: \(scene.map { String($0.activationState.rawValue) } ?? "none")",
            "firstResponder: \(responder.map { NSStringFromClass(type(of: $0)) } ?? "none")",
            "UIKit first: \(input.field?.isFirstResponder.description ?? "none"), editing: \(input.isEditing)",
            "UIKit begin/end: \(input.starts)/\(input.ends)",
            "WebKit window key: \(webView.window?.isKeyWindow.description ?? "none"), sameWindow: \(webView.window != nil && webView.window === window)",
            "WebKit responder: \(Self.firstResponder(in: webView) != nil)",
            "keyboard didShow/didHide: \(shows)/\(hides), key changes: \(keyChanges)",
            "DOM: \(dom)"
        ].joined(separator: "\n")
        if history.last != snapshot { history.append(snapshot) }
        history = Array(history.suffix(8))
        report = history.joined(separator: "\n\n---\n\n")
    }

    func captureDOM(input: BrowserTextInput) {
        Task { @MainActor [weak self] in
            guard let self else { return }
            let value = try? await webView.callAsyncJavaScript(
                "return {tag: document.activeElement?.tagName || '', focused: document.hasFocus()}",
                arguments: [:], in: nil, contentWorld: .defaultClient)
            if let result = value as? [String: Any] {
                dom = "tag=\(result["tag"] as? String ?? "unknown"), documentFocus=\(result["focused"] as? Bool ?? false)"
            } else { dom = "取得失敗" }
            capture(input: input)
        }
    }

    static func firstResponder(in view: UIView) -> UIView? {
        if view.isFirstResponder { return view }
        for child in view.subviews { if let found = firstResponder(in: child) { return found } }
        return nil
    }

}

@MainActor
private struct InputProbeWebSurface: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ view: WKWebView, context: Context) {}
}

@MainActor
private final class InputProbeMessageReceiver: NSObject, WKScriptMessageHandler {
    private weak var owner: BrowserInputProbe?
    init(owner: BrowserInputProbe) { self.owner = owner; super.init() }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "inputProbe", message.frameInfo.isMainFrame else { return }
        owner?.pageFocus(message.body)
    }
}
