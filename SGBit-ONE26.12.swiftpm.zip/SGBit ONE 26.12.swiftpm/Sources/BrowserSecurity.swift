import SwiftUI
import Security
import CryptoKit

protocol BrowserSecretStore {
    func read() throws -> Data?
    func write(_ data: Data) throws
    func remove() throws
}

struct KeychainPINStore: BrowserSecretStore {
    private var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: (Bundle.main.bundleIdentifier ?? "RelayBrowser") + ".PIN",
         kSecAttrAccount as String: "application-lock"]
    }
    func read() throws -> Data? {
        var query = query
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let code = SecItemCopyMatching(query as CFDictionary, &result)
        if code == errSecItemNotFound { return nil }
        guard code == errSecSuccess, let data = result as? Data else { throw keychainError(code) }
        return data
    }
    func write(_ data: Data) throws {
        let attributes = [kSecValueData as String: data] as [String: Any]
        var code = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if code == errSecItemNotFound {
            var item = query
            item[kSecValueData as String] = data
            item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            code = SecItemAdd(item as CFDictionary, nil)
        }
        guard code == errSecSuccess else { throw keychainError(code) }
    }
    func remove() throws {
        let code = SecItemDelete(query as CFDictionary)
        guard code == errSecSuccess || code == errSecItemNotFound else { throw keychainError(code) }
    }
    private func keychainError(_ code: OSStatus) -> NSError { NSError(domain: NSOSStatusErrorDomain, code: Int(code)) }
}

@MainActor
final class BrowserSecurity: ObservableObject {
    private struct Record: Codable {
        var salt: Data
        var hash: Data
        var failures = 0
        var wipePending = false
    }
    @Published private(set) var enabled = false
    @Published private(set) var locked = false
    @Published private(set) var wipePending = false
    @Published private(set) var message = ""
    private let store: BrowserSecretStore
    private var record: Record?

    init(store: BrowserSecretStore = KeychainPINStore()) {
        self.store = store
        do {
            if let data = try store.read() {
                let record = try JSONDecoder().decode(Record.self, from: data)
                guard record.salt.count == 16, record.hash.count == 32, (0...10).contains(record.failures) else {
                    throw CocoaError(.coderReadCorrupt)
                }
                self.record = record
                enabled = true
                locked = true
                wipePending = record.wipePending || record.failures >= 10
            }
        } catch { locked = true; message = "PINを読み込めません: \(error.localizedDescription)" }
    }

    static func valid(_ pin: String) -> Bool { pin.utf8.count == 4 && pin.utf8.allSatisfy { (48...57).contains($0) } }

    func configure(_ pin: String) -> Bool {
        guard !enabled, !locked, Self.valid(pin) else { message = "数字4桁を入力してください"; return false }
        var salt = Data(count: 16)
        let code = salt.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 16, $0.baseAddress!) }
        guard code == errSecSuccess else { message = "PINの生成に失敗しました"; return false }
        let record = Record(salt: salt, hash: Data(SHA256.hash(data: salt + Data(pin.utf8))))
        do {
            try store.write(JSONEncoder().encode(record))
            self.record = record
            enabled = true
            message = "PINロックを有効にしました"
            return true
        } catch { message = "PINを保存できません"; return false }
    }

    func lock() { if enabled { locked = true; message = "数字4桁のPINを入力してください" } }

    func unlock(_ pin: String) -> Bool {
        guard var record, !wipePending else { return false }
        guard Self.valid(pin) else { message = "数字4桁を入力してください"; return false }
        let hash = Data(SHA256.hash(data: record.salt + Data(pin.utf8)))
        let correct = zip(hash, record.hash).reduce(UInt8(0)) { $0 | ($1.0 ^ $1.1) } == 0
        record.failures = correct ? 0 : min(10, record.failures + 1)
        record.wipePending = record.failures >= 10
        do {
            try store.write(JSONEncoder().encode(record))
            self.record = record
            wipePending = record.wipePending
            if wipePending { locked = true }
            if correct { locked = false; message = ""; return true }
            message = wipePending ? "10回失敗したためデータを削除します" : "PINが違います（\(record.failures)/10）"
        } catch { locked = true; message = "試行回数を保存できません。ロックを継続します" }
        return false
    }

    func disable(using pin: String) -> Bool {
        guard unlock(pin) else { return false }
        do {
            try store.remove()
            record = nil
            enabled = false
            message = "PINロックを無効にしました"
            return true
        } catch { locked = true; message = "PINを削除できません"; return false }
    }

    func finishWipe() throws {
        guard var record else { return }
        record.failures = 0
        record.wipePending = false
        try store.write(JSONEncoder().encode(record))
        self.record = record
        wipePending = false
        locked = true
        message = "サイトデータと履歴を削除しました。PINを入力してください"
    }

    func reportWipeFailure(_ error: Error) { message = "削除未完了: \(error.localizedDescription)" }
}
