import SwiftUI

@MainActor
struct BrowserTabDrag: ViewModifier {
    static let typeIdentifier = "net.ogatomo.RelayBrowser.tab"
    let browser: RelayBrowserModel
    let id: UUID
    @State private var targeted = false

    private static func makeProvider(data: Data) -> NSItemProvider {
        NSItemProvider(item: data as NSData, typeIdentifier: Self.typeIdentifier)
    }

    func body(content: Content) -> some View {
        content
            .overlay { RoundedRectangle(cornerRadius: 10).stroke(targeted ? Color.accentColor : .clear, lineWidth: 2).allowsHitTesting(false) }
            .onDrag {
                Self.makeProvider(data: browser.tabDragData(for: id) ?? Data())
            }
            .onDrop(of: [Self.typeIdentifier], delegate: BrowserTabDrop(browser: browser, id: id, targeted: $targeted))
            .accessibilityHint("長押しして別のタブへ移動し、離すと並び替え")
            .accessibilityAction(named: "タブを左へ移動") { browser.moveTab(id, by: -1) }
            .accessibilityAction(named: "タブを右へ移動") { browser.moveTab(id, by: 1) }
    }
}

@MainActor
private struct BrowserTabDrop: DropDelegate {
    let browser: RelayBrowserModel
    let id: UUID
    @Binding var targeted: Bool

    func validateDrop(info: DropInfo) -> Bool {
        !browser.security.locked && !browser.isClearingData && browser.tabs.contains(where: { $0.id == id }) &&
            info.hasItemsConforming(to: [BrowserTabDrag.typeIdentifier])
    }
    func dropEntered(info: DropInfo) { targeted = true }
    func dropExited(info: DropInfo) { targeted = false }
    func dropUpdated(info: DropInfo) -> DropProposal? { DropProposal(operation: .move) }
    func performDrop(info: DropInfo) -> Bool {
        targeted = false
        guard validateDrop(info: info), let provider = info.itemProviders(for: [BrowserTabDrag.typeIdentifier]).first else { return false }
        let browser = browser, target = id
        provider.loadDataRepresentation(forTypeIdentifier: BrowserTabDrag.typeIdentifier) { data, error in
            guard error == nil, let data, data.count == 73 else { return }
            Task { @MainActor in
                withAnimation(.easeInOut(duration: 0.15)) { _ = browser.acceptTabDrop(data, onto: target) }
            }
        }
        return true
    }
}
