import SwiftUI
import WebKit

@available(iOS 17.0, *)
@MainActor
struct BrowserTabOverview: View {
    @ObservedObject var browser: RelayBrowserModel
    @Environment(\.dismiss) private var dismiss
    @State private var previews: [UUID: UIImage] = [:]
    @State private var privateOnly = false

    private var visibleTabs: [BrowserTab] {
        browser.tabs.filter { $0.isPrivate == privateOnly }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 190, maximum: 360), spacing: 14)], spacing: 14) {
                    ForEach(visibleTabs) { tab in
                        VStack(spacing: 0) {
                            Button {
                                browser.select(tab.id)
                                dismiss()
                            } label: {
                                Group {
                                    if let preview = previews[tab.id] {
                                        Image(uiImage: preview).resizable().scaledToFill()
                                    } else {
                                        ZStack {
                                            Color(uiColor: .secondarySystemGroupedBackground)
                                            Image(systemName: tab.isPrivate ? "eye.slash" : "globe")
                                                .font(.largeTitle).foregroundStyle(.secondary)
                                        }
                                    }
                                }
                                .frame(height: 150)
                                .frame(maxWidth: .infinity)
                                .clipped()
                            }
                            HStack(spacing: 8) {
                                Text(tab.title).lineLimit(1).font(.subheadline)
                                Spacer(minLength: 2)
                                Button {
                                    previews[tab.id] = nil
                                    browser.close(tab.id)
                                } label: { Image(systemName: "xmark.circle.fill").font(.title3) }
                                    .accessibilityLabel("\(tab.title)を閉じる")
                            }
                            .padding(10)
                        }
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .task(id: tab.id) {
                            // WKWebView snapshots can be unavailable before first page rendering.
                            guard !tab.isStartPage else { return }
                            if let snapshot = try? await tab.webView.takeSnapshot(configuration: nil) {
                                previews[tab.id] = snapshot
                            }
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("すべてのタブ")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Picker("タブの種類", selection: $privateOnly) {
                        Text("通常").tag(false)
                        Text("プライベート").tag(true)
                    }.pickerStyle(.segmented).frame(maxWidth: 230)
                }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { _ = browser.newTab(isPrivate: privateOnly); dismiss() } label: { Image(systemName: "plus") }
                    Button("完了") { dismiss() }
                }
            }
        }
    }
}

@available(iOS 17.0, *)
@MainActor
struct BrowserSimpleDevTools: View {
    @ObservedObject var tab: BrowserTab
    @State private var source = ""
    @State private var output = ""
    @State private var command = "document.title"
    @State private var selectedPanel = 0

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 12) {
                Picker("開発ツール", selection: $selectedPanel) {
                    Text("Console").tag(0)
                    Text("Elements").tag(1)
                }.pickerStyle(.segmented)
                if selectedPanel == 0 {
                    Text("現在のページのJavaScriptを評価します。信頼できるページでのみ使ってください。")
                        .font(.caption).foregroundStyle(.secondary)
                    HStack {
                        TextField("JavaScript式", text: $command)
                            .textFieldStyle(.roundedBorder).textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .onSubmit(evaluate)
                        Button("実行", action: evaluate)
                    }
                    ScrollView {
                        Text(output.isEmpty ? "実行結果がここに表示されます" : output)
                            .font(.system(.footnote, design: .monospaced))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .textSelection(.enabled)
                    }
                } else {
                    Button("現在のHTMLを読み込む", action: loadHTML)
                    ScrollView {
                        Text(source.isEmpty ? "HTMLを読み込んでください" : source)
                            .font(.system(.footnote, design: .monospaced))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .textSelection(.enabled)
                    }
                }
            }
            .padding()
            .navigationTitle("SGBit DevTools")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func evaluate() {
        guard !command.isEmpty else { return }
        tab.webView.evaluateJavaScript(command) { value, error in
            Task { @MainActor in
                if let error { output = "Error: \(error.localizedDescription)" }
                else { output = value.map { String(describing: $0) } ?? "undefined" }
            }
        }
    }

    private func loadHTML() {
        tab.webView.evaluateJavaScript("document.documentElement.outerHTML") { value, error in
            Task { @MainActor in
                if let error { source = "Error: \(error.localizedDescription)" }
                else { source = value as? String ?? "HTMLを取得できませんでした" }
            }
        }
    }
}
