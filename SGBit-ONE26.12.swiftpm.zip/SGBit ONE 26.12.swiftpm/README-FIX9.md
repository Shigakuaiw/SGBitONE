# Bit Browser Fix 9 — sidebar touch targets

- Based on BitBrowser-TabFix (includes Liquid Keyboard and previous fixes).
- Sidebar navigation rows now have a dedicated, full-width 56pt tap target.
- Icon, text and empty horizontal space all activate the same Button.
- Sidebar selection is changed only by its own button action.
- Browser, audio, files, recognition and vault implementations were not modified.
- Original bundle identifier is preserved for app data compatibility.
- Build and real-device interaction testing have not been performed here.
