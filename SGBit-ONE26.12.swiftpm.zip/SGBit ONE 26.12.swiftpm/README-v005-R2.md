# SGBit ONE 26.11.1119.005

- Cloudflare Worker endpoint selectable between sgbit-one-control and one-control from Settings → Account. Server switch clears the existing session and adjusts the status endpoint.
- Files tab now offers Local / Cloud (R2); cloud folder navigation, pagination, filtering and authenticated download to local Downloads (50 MB limit).
- Login/register and global state continue to use the selected Worker; Admin token is never shipped in the app.
- Existing manual local ZIP backup unchanged. Do NOT upload that unencrypted ZIP to the backup API; this build does not implement cloud backup restoration or encrypted upload.
- Cloudflare R2 bucket requires objects to be added in dashboard; in an empty bucket, the cloud files view will show no files.
- Run & build with Swift Playgrounds on iPad to confirm; no Apple Swift toolchain available in this environment.
