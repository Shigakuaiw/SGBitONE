# Liquid PIN UI

- 4桁PIN設定画面をダークブルーのフロストガラスUIに変更
- 入力フィールドは4つのドットとアクティブ枠表示
- テンキーは背景マテリアル、細い半透明の縁、48pt以上のタッチ領域
- PINの保存・検証・失敗時の削除処理は未変更
- iOS 17互換のMaterialで作成（iOS 26専用glassEffectは不使用）
- Swift Playgrounds実機でのビルドは未検証
