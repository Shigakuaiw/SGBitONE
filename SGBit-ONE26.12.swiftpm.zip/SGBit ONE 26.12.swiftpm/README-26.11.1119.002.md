# SGBit ONE 26.11.1119.002 (development build)

Added a first-run onboarding experience (account creation/login, accent color, dark/light appearance, and local backup opt-in) using the current Cloudflare Admin v4 APIs.

## Included
- `ONEAccount.swift`: `/api/register`, `/api/login`, `/api/me`, `/api/launch`, `/api/preferences`, session token stored in iOS Keychain, account settings/logout.
- `ONESetupView.swift`: first-launch setup UI. Setup completion is stored in UserDefaults.
- `ONEBackup.swift`: full local backup of app Documents and Application Support plus selected preferences into **ZIP64**, including music/playlist and the encrypted password vault file. Export to Files via document picker.
- Account and Backup entries added to app Settings.
- The app status endpoint now defaults to `https://sgbit-one-control.gakushisama.workers.dev/status` unless already overridden in device preferences.

## Important limitations
- Backup ZIP is **not encrypted**. The password vault is already encrypted separately, but browsing history and other private files in the ZIP are NOT encrypted. Handle privately.
- No automatic scheduled backup and no ZIP restore/import yet. Frequency preference is stored for future functionality.
- Keychain login tokens, WebKit cookies, and other system-private data are not included in ZIP.
- Remote individual blocks are supported by Admin v4's authenticated APIs. Current browser's general public website networking is NOT blocked at the network layer; existing app-level UI only displays a restriction while a user is marked blocked. The current Admin v4 deletes sessions on block, which may cause a LOGIN_REQUIRED response instead of a blocked-state response. This needs server-side adjustment for reliable real-time per-user restrictions.
- Registration is publicly accessible and lacks rate limits/invite codes; not production-safe as a public signup platform.
- Swift source was syntax parsed on Linux; iOS/iPadOS build and runtime tests require Swift Playgrounds / Xcode and were not available here.
- Export requires free space approximating the size of all included app data; ZIP64 uses store mode (no compression).
