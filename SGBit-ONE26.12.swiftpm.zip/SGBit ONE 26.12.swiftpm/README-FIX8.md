# Bit Browser Fix 8 — Sidebar toggle

- iPad/regular layout sidebar open/close uses a single permanently-mounted overlay Button, rather than two conditional buttons.
- Gives the control a distinct 44x44 hit area and high z-index over browser content.
- No change to password/keychain or browsing internals.
- Not compiled on Apple hardware; verify in Swift Playgrounds on the intended device.
- If tapping in Mac preview still fails, test the app in a standalone run window to distinguish preview interaction from app UI.
