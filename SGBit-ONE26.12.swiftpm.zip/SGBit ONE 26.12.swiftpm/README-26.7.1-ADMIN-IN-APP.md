# SGBit ONE 26.7.1 管理者オプション

設定 → 詳細設定 → ビルドコード「2671」を7回タップ → 管理者コードを入力。

管理者コードはCloudflare Workerに設定した `ADMIN_TOKEN` Secretと同じものです。端末のパスコードとは無関係です。認証は `/admin/current` へのHTTPS問い合わせで行い、配信は `/admin/publish` を使用します。アプリ内にはコードを保存しません。

現在の更新情報の取得、タイトル・更新内容・配布URLの編集、テーマ切り替えパッチの公開に対応。Workerを事前にデプロイし、KV `UPDATES_KV` と Secret `ADMIN_TOKEN` を設定してください。

本体のSwiftコードのリモート変更はできません。実機ビルドは未検証です。
