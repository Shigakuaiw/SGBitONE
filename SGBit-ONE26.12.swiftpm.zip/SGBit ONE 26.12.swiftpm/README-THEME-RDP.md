# Bit Browser — Theme + RDP

- Finder-style home and existing sidebar retained.
- Theme editor: dark/light, accent colors, sidebar opacity, home icon corner radius; persisted with AppStorage.
- RDP: HTTPS Apache Guacamole web client in WKWebView; saves only URL, not passwords. Requires an existing configured Guacamole server. Direct native RDP protocol is not implemented.
- Device/Playgrounds build was not verified; check with Swift Playgrounds on Apple hardware.
