# Bit Browser

Swift Playgroundsで `BitBrowser.swiftpm` を開いて実行します。ブラウザ、ファイル管理、音楽プレイヤー、ShazamKit音楽認識の統合版です。

アプリ表示名は Bit Browser に変更済みです。内部の RelayBrowserModel などの型名、保存キー、bundleIdentifier、タブUTIは既存データとの互換性維持のため変更していません。元のREADMEは旧版の開発資料です。

このプロジェクトはiPad実機でのビルド確認は未実施です。
