# Appホストへの設定

Swift PlaygroundsではInfo.plistは通常自動生成され、編集画面に存在しません。今回作成したRelayBrowser.swiftpmは、生成時に追加する設定ファイルConfig/HostInfo.plistと、それを参照するPackage.swiftを含みます。そのプロジェクトを開く場合、追加の手作業は不要です。

以下は既存の.swiftpmを維持して更新する場合の説明です。ユーザーの既存Package.swiftは未取得なので、この作業ではそのファイルを編集していません。

## Swift PlaygroundsのApp（.swiftpm）

1. 既存の.swiftpmをコピーしてバックアップします。同じbundleIdentifierを維持してください。
2. Package.swiftの隣へConfigフォルダをコピーします。
3. 既存のproducts内の.iOSApplication(...)に次の引数を追加します。既に指定されている場合は、その既存ファイルへHostInfo.plistのキーをマージします。

```swift
additionalInfoPlistContentFilePath: "Config/HostInfo.plist"
```

末尾の引数にする場合は、その直前の引数にカンマが必要です。bundleIdentifier・teamIdentifier・capabilities等を置き換えないでください。Package.swiftの既存形式は[ConsolePadの実装例](https://github.com/kkebo/ConsolePad.swiftpm/blob/main/Package.swift)でも確認できます。使用中のPlaygroundsに付属するAppleProductTypesでの受け入れは実機で確認してください。

## ファイルAppへの公開

r11はUIFileSharingEnabledとLSSupportsOpeningDocumentsInPlaceを両方YESにしています。iOSのローカルファイルプロバイダがAppのDocuments全体へアクセスできる設定で、Downloadsだけの公開権限ではありません。新規ダウンロードはDocuments/Downloads/UUID/filenameへ保存し、履歴や元URLを含む管理indexはApplication Supportへ保持します。公開する保存ファイルはAppのPINロック対象外です。

インストールしたAppでは、ファイルAppの「このiPad内／このiPhone内」→Appの表示名→Downloadsが対象です。Playgroundsの再生はホスト側Infoが使われる場合があるため、専用Appのフォルダが出るかは実機で確認してください。共有設定が反映されない場合も、一覧の共有ボタンからファイルAppへコピー保存できます。

参照：[Appleのファイル共有設定](https://developer.apple.com/library/archive/documentation/General/Reference/InfoPlistKeyReference/Articles/LaunchServicesKeys.html)。

## 各設定の目的

- NSLocalNetworkUsageDescription: ルーター等のLAN機器へ接続する理由をOSへ伝えます。http://10.0.1.1等への接続で、実行App/Playgroundsのローカルネットワーク許可も確認してください。これはi-FILTERの解除設定ではありません。

- NSAppTransportSecurity → NSAllowsArbitraryLoadsInWebContent = YES: WKWebViewのHTTPページを許可します。URLSession全体のATSを無効にせず、HTTPSの証明書検証も変更しません。設定されていないAppではHTTP読み込みがATSエラー（-1022等）になる場合があります。
- CFBundleLocalizations: OS標準の選択/編集メニューがAppの対応言語から端末の優先言語を選べるようにします。日本語・英語などを列挙しています。App独自の設定画面等の文言は引き続き日本語です。
- CFBundleAllowMixedLocalizations = YES: フレームワーク側のローカライズ利用を許可します。

Appごとの言語設定が端末言語より優先される場合があります。日本語/英語の両方で、URL欄とWebページ内の選択メニューを確認してください。Playgroundsの実行ホストの言語やInfoが適用される場合もあるため、設定画面のApp言語表示と、可能ならインストールしたAppで比較します。

参照: [Apple: WebViewのHTTP許可](https://developer.apple.com/documentation/bundleresources/information-property-list/nsapptransportsecurity/nsallowsarbitraryloadsinwebcontent)、[Apple: Appと標準UIの言語選択](https://developer.apple.com/library/archive/qa/qa1828/_index.html)。

## タブのドラッグ形式（r14）

UTExportedTypeDeclarationsでnet.ogatomo.RelayBrowser.tabをpublic.dataの派生型として宣言します。タブ並び替え専用の73バイトデータで、アプリ内プロセスだけに可視です。URLやタイトルは含めず、モデル所有トークンと現存UUIDを照合してから順序を変えます。既存の追加Infoファイルを使う場合は、この独自型宣言もマージしてください。CFBundleDocumentTypesやファイル拡張子は追加せず、外部文書を開く機能にはしません。

参照：[Appleの独自ドラッグ型の説明](https://developer.apple.com/documentation/swiftui/making-a-view-into-a-drag-source)。
